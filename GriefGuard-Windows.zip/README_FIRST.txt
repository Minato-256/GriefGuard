GriefGuard 配布物: 最初にお読みください

版: 2026.07.28.2

1. ZIPは必ず「すべて展開」してから操作します。ZIPを開いたまま実行しません。
2. すでにPaperが起動中なら、Paperコンソールで stop を実行して完全に停止します。session.lockは削除しません。
3. 使用するOSの開始ファイルだけを開きます。

Windows:
  Installers\Windows\Start-GriefGuard-Setup.bat
  このBATファイルをダブルクリックします。PS1を右クリックして直接実行する必要はありません。

macOS:
  Installers/macOS/GriefGuard-Installer.pkg
  PKGが完了してから、Installers/macOS/GriefGuard-Setup.command を開きます。

実行環境について:
  Node.jsとJavaはPCに互換版があれば再利用します。無い場合だけ公式配布元から取得し、SHA-256確認後にOSのGriefGuard共有キャッシュへ保存します。次回のStandard版・HighVersion版・別サーバーでは再ダウンロードしません。

既存Paperは、ファイル選択画面で paper.jar、server.properties、plugins、world が直接入る最上位フォルダーを選びます。cmdやターミナルにcdを入力しません。

重要: Setupは初回導入・修復用です。日常操作では管理ワークスペースの Agent-Manual-Controls.txt を開き、Open-GriefGuard-App、Start-GriefGuard-Agent、Stop-GriefGuard-Agent を使います。

詳しい手順: GriefGuard_Manual_JA.pdf（第3〜5章: 導入とTailscale、第6〜10章: アプリ、第11〜14章: 更新・復旧）

Tailscaleを後回しにした場合:
- GriefGuard-HomeServer内の Continue-Tailscale-Setup.bat または Continue-Tailscale-Setup.command を実行します。最初からセットアップをやり直す必要はありません。
- HTTPS URLはPaper親フォルダーの GriefGuard-Access.txt に保存されます。

Paperを更新する場合:
- Paperサーバーをstopで完全に停止します。
- Paperサーバー直下の Update-Paper.bat（Windows）または Update-Paper.command（macOS）を実行します。
- 公式安定版だけが表示されます。更新前のpaper.jarと起動ファイルは .griefguard/update-backups に保存されます。
