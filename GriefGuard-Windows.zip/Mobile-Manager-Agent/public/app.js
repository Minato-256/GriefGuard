let currentToken = null;
let socket = null;
let socketReconnectTimer = null;
let sessionRestoreTimer = null;
let currentAgent = null;
let agentStatusInterval = null;
let metricsInterval = null;
let sessionWarningCount = 0;
// Retains HighVersion's full per-profile policy while the shared controls are
// edited. A save must never collapse relaxed thresholds onto normal values.
let highProfileDraft = null;
const CLIENT_NAME_KEY = 'gg_client_name';

function clientName() {
    let value = localStorage.getItem(CLIENT_NAME_KEY);
    if (!value) {
        value = /iPhone|Android|Mobile/i.test(navigator.userAgent) ? 'モバイル端末' : 'PCブラウザー';
        localStorage.setItem(CLIENT_NAME_KEY, value);
    }
    return value.slice(0, 60);
}

const loginView = document.getElementById('login-view');
const dashboardView = document.getElementById('dashboard-view');
const loginForm = document.getElementById('login-form');
const loginPassword = document.getElementById('login-password');
const setupForm = document.getElementById('setup-form');
const setupCode = document.getElementById('setup-code');
const setupPassword = document.getElementById('setup-password');
const setupPasswordConfirm = document.getElementById('setup-password-confirm');
const passwordResetForm = document.getElementById('password-reset-form');
const passwordResetCode = document.getElementById('password-reset-code');
const passwordResetPassword = document.getElementById('password-reset-password');
const passwordResetPasswordConfirm = document.getElementById('password-reset-password-confirm');
const loginError = document.getElementById('login-error');
const connectionIndicator = document.getElementById('connection-indicator');
const btnLogout = document.getElementById('btn-logout');

const valPlayers = document.getElementById('val-players');
const valWarnings = document.getElementById('val-warnings');
const cpuPct = document.getElementById('cpu-pct');
const cpuFill = document.getElementById('cpu-fill');
const ramUsage = document.getElementById('ram-usage');
const ramFill = document.getElementById('ram-fill');
const ramConfigHint = document.getElementById('ram-config-hint');

const consoleOutput = document.getElementById('console-output');
const consoleInputForm = document.getElementById('console-input-form');
const consoleInput = document.getElementById('console-input');

const banCountBadge = document.getElementById('ban-count');
const banListContainer = document.getElementById('ban-list-container');
const warningLogsContainer = document.getElementById('warning-logs-container');
const warningLogCountBadge = document.getElementById('warning-log-count');
const MANAGEMENT_DISPLAY_LIMITS = Object.freeze({
    bannedIps: 5,
    warningLogs: 10,
    players: 20
});
const MANAGEMENT_WARNING_HISTORY_LIMIT = 500;
const managementPage = { bans: 1, warnings: 1, players: 1 };
let bannedIpsList = [];
let warningLogs = [];
const toast = document.getElementById('toast');
const operatorModal = document.getElementById('operator-modal');
const operatorForm = document.getElementById('operator-form');
const operatorModalTitle = document.getElementById('operator-modal-title');
const operatorModalWarning = document.getElementById('operator-modal-warning');
const operatorPlayerName = document.getElementById('operator-player-name');
const operatorConfirmation = document.getElementById('operator-confirmation');
const operatorCurrentPassword = document.getElementById('operator-current-password');
const operatorSubmit = document.getElementById('btn-submit-operator');
let operatorTarget = null;

function pageItems(items, pageKey, pageSize) {
    const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
    managementPage[pageKey] = Math.min(Math.max(1, managementPage[pageKey] || 1), totalPages);
    const page = managementPage[pageKey];
    return {
        page,
        totalPages,
        items: items.slice((page - 1) * pageSize, page * pageSize)
    };
}

function renderListPagination(containerId, pageKey, totalItems, pageSize, onPageChange) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const totalPages = Math.ceil(totalItems / pageSize);
    if (totalPages <= 1) {
        container.hidden = true;
        container.replaceChildren();
        return;
    }

    const current = Math.min(Math.max(1, managementPage[pageKey] || 1), totalPages);
    managementPage[pageKey] = current;
    container.hidden = false;
    container.replaceChildren();

    const addButton = (label, targetPage, options = {}) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `pagination-button${options.current ? ' is-current' : ''}`;
        button.textContent = label;
        button.disabled = Boolean(options.disabled);
        button.setAttribute('aria-label', options.ariaLabel || `${targetPage}ページへ`);
        if (options.current) button.setAttribute('aria-current', 'page');
        button.addEventListener('click', () => {
            if (targetPage === managementPage[pageKey]) return;
            managementPage[pageKey] = targetPage;
            onPageChange();
        });
        container.appendChild(button);
    };

    addButton('最初', 1, { disabled: current === 1, ariaLabel: '最初のページへ' });
    addButton('‹', current - 1, { disabled: current === 1, ariaLabel: '前のページへ' });

    const firstVisible = Math.max(1, current - 2);
    const lastVisible = Math.min(totalPages, current + 2);
    if (firstVisible > 1) {
        const gap = document.createElement('span');
        gap.className = 'pagination-gap';
        gap.textContent = '…';
        container.appendChild(gap);
    }
    for (let page = firstVisible; page <= lastVisible; page += 1) {
        addButton(String(page), page, { current: page === current });
    }
    if (lastVisible < totalPages) {
        const gap = document.createElement('span');
        gap.className = 'pagination-gap';
        gap.textContent = '…';
        container.appendChild(gap);
    }

    addButton('›', current + 1, { disabled: current === totalPages, ariaLabel: '次のページへ' });
    addButton('最後', totalPages, { disabled: current === totalPages, ariaLabel: '最後のページへ' });

    const status = document.createElement('span');
    status.className = 'pagination-status';
    status.textContent = `${current} / ${totalPages} ページ`;
    container.appendChild(status);
}

if (window.navigator.standalone === true) {
    document.body.classList.add('standalone');
}

function resetRootScroll() {
    if (document.documentElement.scrollTop) document.documentElement.scrollTop = 0;
    if (document.body.scrollTop) document.body.scrollTop = 0;
    if (window.scrollX !== 0 || window.scrollY !== 0) window.scrollTo(0, 0);
}

resetRootScroll();
window.addEventListener('resize', resetRootScroll);
document.addEventListener('scroll', () => {
    if (window.scrollY || document.documentElement.scrollTop || document.body.scrollTop) requestAnimationFrame(resetRootScroll);
}, true);

document.querySelectorAll('.segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        resetRootScroll();
        document.querySelectorAll('.segment-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        
        btn.classList.add('active');
        const target = btn.getAttribute('data-target');
        document.getElementById(target).classList.add('active');
        if (target === 'tab-map') {
            activateBlueMapView();
        }
    });
});

let blueMapRetryTimer = null;
let blueMapFetchController = null;
let blueMapLoadPromise = null;
let blueMapLoadSequence = 0;

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

function mapUi() {
    return {
        frame: document.getElementById('bluemap-frame'),
        unavailable: document.getElementById('map-unavailable'),
        external: document.getElementById('map-open-external'),
        loading: document.getElementById('map-loading'),
        loadingText: document.getElementById('map-loading-text'),
        reset: document.getElementById('map-reset-view'),
        unavailableTitle: document.getElementById('map-unavailable-title'),
        unavailableMessage: document.getElementById('map-unavailable-message')
    };
}

function setMapLoading(visible, message = 'BlueMapを確認しています…') {
    const { loading, loadingText } = mapUi();
    if (loadingText) loadingText.textContent = message;
    if (loading) loading.hidden = !visible;
}

function blueMapFrameReady(frame) {
    try {
        const doc = frame.contentDocument;
        const canvas = doc?.querySelector('canvas');
        const state = doc?.querySelector('.map-state-message');
        return Boolean(canvas && canvas.width > 0 && canvas.height > 0 && !state);
    } catch (_) {
        return false;
    }
}

async function waitForBlueMapReady(frame, sequence) {
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline && sequence === blueMapLoadSequence) {
        if (blueMapFrameReady(frame)) return true;
        await wait(150);
    }
    return false;
}

function resizeBlueMapFrame(frame) {
    try { frame?.contentWindow?.dispatchEvent(new Event('resize')); } catch (_) {}
}

async function loadBlueMap({ force = false } = {}) {
    if (blueMapLoadPromise && !force) return blueMapLoadPromise;
    if (force && blueMapFetchController) blueMapFetchController.abort();
    const sequence = ++blueMapLoadSequence;
    const task = (async () => {
    const frame = document.getElementById('bluemap-frame');
    const unavailable = document.getElementById('map-unavailable');
    const external = document.getElementById('map-open-external');
    const loading = document.getElementById('map-loading');
    const unavailableTitle = document.getElementById('map-unavailable-title');
    const unavailableMessage = document.getElementById('map-unavailable-message');
    const reset = document.getElementById('map-reset-view');
    if (!frame || !unavailable || !external || !loading || !unavailableTitle || !unavailableMessage) return;
    setMapLoading(true, 'BlueMapの接続状態を確認しています…');
    try {
        blueMapFetchController = new AbortController();
        const response = await fetch('/api/map-status', { headers: { Authorization: currentToken }, signal: blueMapFetchController.signal });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'BlueMapの状態を取得できませんでした。');
        if (data.ready && data.url) {
            const cacheKey = String(data.generation || Date.now());
            const mapUrlBase = `${data.url}${data.url.includes('?') ? '&' : '?'}gg=${encodeURIComponent(cacheKey)}`;
            // A forced reload must change the document URL as well. Browsers
            // are allowed to ignore assigning an iframe's current src again.
            const mapUrl = force ? `${mapUrlBase}&reload=${Date.now()}` : mapUrlBase;
            const needsDocumentLoad = force || frame.dataset.mapUrl !== mapUrl || frame.hidden;
            if (needsDocumentLoad) {
                clearTimeout(frame._blueMapLoadTimeout);
                frame.dataset.mapUrl = mapUrl;
                // Register load/error handlers before assigning src: loopback
                // BlueMap often loads quickly enough to otherwise win the race.
                frame.onload = () => {
                    clearTimeout(frame._blueMapLoadTimeout);
                };
                frame.onerror = () => {
                    setMapLoading(false);
                    unavailable.hidden = false;
                    unavailableTitle.textContent = 'BlueMapの画面を読み込めませんでした';
                    unavailableMessage.textContent = 'BlueMap WebAppまたはAgent経由の通信を確認してください。';
                };
                // Keep the iframe in layout while it boots. `hidden` is
                // cleared below before the browser starts fetching its page.
                frame.hidden = false;
                frame.src = mapUrl;
                frame._blueMapLoadTimeout = setTimeout(() => {
                    if (sequence !== blueMapLoadSequence) return;
                    setMapLoading(false);
                    unavailable.hidden = false;
                    unavailableTitle.textContent = 'BlueMapの画面読み込みが完了しません';
                    unavailableMessage.textContent = 'BlueMap WebAppの更新またはAgent経由の通信を確認してください。設定画面の診断結果とRepair-BlueMapを確認できます。';
                }, 15000);
            }
            frame.hidden = false;
            unavailable.hidden = true;
            external.href = data.url;
            external.hidden = false;
            if (reset) reset.hidden = false;
            setMapLoading(true, 'BlueMapの地図データを準備しています…');
            const ready = await waitForBlueMapReady(frame, sequence);
            if (sequence !== blueMapLoadSequence) return;
            if (ready) {
                clearTimeout(frame._blueMapLoadTimeout);
                setMapLoading(false);
                resizeBlueMapFrame(frame);
            } else {
                setMapLoading(false);
                unavailable.hidden = false;
                unavailableTitle.textContent = 'BlueMapの描画準備が完了しません';
                unavailableMessage.textContent = '地図の初回描画中、またはブラウザーのWebGL初期化に失敗しています。再読込か「別画面」を試し、改善しない場合は診断を実行してください。';
            }
        } else {
            frame.hidden = true;
            unavailable.hidden = false;
            external.hidden = true;
            if (reset) reset.hidden = true;
            const presentation = {
                'not-installed': ['BlueMapと連携するとワールド地図を確認できます', 'BlueMapは未導入です。インストーラーのBlueMap導入を実行してください。'],
                'awaiting-consent': ['BlueMapの利用同意を待っています', 'BlueMapの地図リソース取得への同意が必要です。Repair-BlueMapを実行してください。'],
                'awaiting-config': ['BlueMapの設定を作成しています', 'Paperの初回起動でBlueMap設定を生成してから、もう一度確認します。'],
                'config-invalid': ['BlueMapの設定を確認できません', 'webserver.confまたはWebApp設定が不足しています。Repair-BlueMapを実行してください。'],
                'paper-offline': ['Paperが停止しています', 'サーバーを起動するとBlueMapの地図を表示できます。'],
                'initial-rendering': ['BlueMapが初回描画を準備しています', 'Paperを起動したままにして、BlueMapの描画タスクが進むまで待機してください。'],
                'blank-render': ['BlueMapの地図データが空です', 'BlueMapは起動していますが、地形のない空タイルを検出しました。Paperを停止してから管理ワークスペースのRepair-BlueMapを実行してください。'],
                'mixed-generation': ['BlueMapの描画世代が混在しています', '古い3Dタイルと新しいテクスチャ定義が混ざっています。ズーム時に別の地形や誤ったブロック表示になるため、Paperを停止してRepair-BlueMapを実行してください。'],
                'partial-render': ['BlueMapの一部ワールドが未描画です', 'overworld以外を含む地形タイルが不足しています。Paperを停止してRepair-BlueMapを実行してください。'],
                'stale-render': ['BlueMapの地図データが古い状態です', 'ワールドより古い地図データを検出しました。Repair-BlueMapで安全に再描画できます。'],
                'webapp-stale': ['BlueMapのWeb画面を更新する必要があります', 'BlueMap本体とWebAppの版が一致していません。Repair-BlueMapで安全に更新できます。'],
                'webserver-offline': ['BlueMap Webサーバーが停止しています', 'Paperを起動し、BlueMapのログを確認してください。'],
                'tile-unavailable': ['BlueMapの地図データを取得できません', 'BlueMap WebAppまたは地図データの応答に失敗しています。Repair-BlueMapと診断結果を確認してください。'],
                'proxy-degraded': ['Agent経由のBlueMap通信に失敗しています', 'BlueMap本体またはAgentの代理配信でエラーが検出されました。再診断してください。']
            }[data.state] || ['BlueMapはまだ表示できません', data.message || 'BlueMapの状態を確認できませんでした。'];
            unavailableTitle.textContent = presentation[0];
            unavailableMessage.textContent = data.message || presentation[1];
        }
    } catch (error) {
        if (error.name === 'AbortError') return;
        unavailable.hidden = false;
        unavailableTitle.textContent = 'BlueMapとの連携を確認できません';
        unavailableMessage.textContent = error.message;
        frame.hidden = true;
        external.hidden = true;
    } finally {
        if (sequence === blueMapLoadSequence) blueMapFetchController = null;
    }
    })();
    blueMapLoadPromise = task;
    try { return await task; }
    finally { if (blueMapLoadPromise === task) blueMapLoadPromise = null; }
}

function scheduleBlueMapRefresh() {
    clearTimeout(blueMapRetryTimer);
    if (!document.getElementById('tab-map')?.classList.contains('active')) return;
    blueMapRetryTimer = setTimeout(async () => {
        await loadBlueMap();
        const frame = document.getElementById('bluemap-frame');
        if (frame?.hidden) scheduleBlueMapRefresh();
    }, 3500);
}

function activateBlueMapView() {
    clearTimeout(blueMapRetryTimer);
    requestAnimationFrame(() => {
        const frame = document.getElementById('bluemap-frame');
        resizeBlueMapFrame(frame);
        loadBlueMap();
    });
}

document.getElementById('map-reload')?.addEventListener('click', () => loadBlueMap({ force: true }));
document.getElementById('map-reset-view')?.addEventListener('click', () => {
    const frame = document.getElementById('bluemap-frame');
    if (!frame?.dataset.mapUrl) return;
    // A fresh URL clears the previous BlueMap camera fragment/state without
    // touching server-side rendered tiles.
    frame.dataset.mapUrl = '';
    loadBlueMap({ force: true });
});

window.addEventListener('resize', () => {
    if (document.getElementById('tab-map')?.classList.contains('active')) resizeBlueMapFrame(document.getElementById('bluemap-frame'));
});
window.addEventListener('orientationchange', () => setTimeout(() => resizeBlueMapFrame(document.getElementById('bluemap-frame')), 200));

async function runBlueMapDiagnostics() {
    const button = document.getElementById('map-diagnostics-button');
    const result = document.getElementById('map-diagnostics-result');
    if (!button || !result) return;
    button.disabled = true;
    result.hidden = false;
    result.textContent = 'BlueMapのWebApp・設定・Agent経由通信を確認しています…';
    try {
        const response = await fetch('/api/map-diagnostics', { headers: { Authorization: currentToken } });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || '診断を実行できませんでした。');
        const checks = data.checks || {};
        const lines = [
            `状態: ${data.state || 'unknown'}`,
            `内容: ${data.message || '情報なし'}`,
            `BlueMap本体: ${data.details?.jar || '未検出'}${data.details?.release ? ` (${data.details.release})` : ''}`,
            `WebApp: ${checks.webApp ? `HTTP ${checks.webApp.status} / ${checks.webApp.elapsedMs}ms` : '未確認'}`,
            `設定データ: ${checks.settings ? `HTTP ${checks.settings.status} / ${checks.settings.elapsedMs}ms` : '未確認'}`,
            `Agent経由: ${checks.proxySettings ? `HTTP ${checks.proxySettings.status} / ${checks.proxySettings.elapsedMs}ms` : '未確認'}`,
            `地図タイル: ${checks.tile?.status ? `HTTP ${checks.tile.status} / ${checks.tile.elapsedMs}ms` : checks.tile?.state === 'not-rendered' ? '初回描画前' : '未確認'}`,
            `Agent経由タイル: ${checks.proxyTile ? `HTTP ${checks.proxyTile.status} / ${checks.proxyTile.elapsedMs}ms` : '未確認'}`,
            `マップ数: ${checks.maps?.count ?? '未確認'}`
        ];
        if (checks.maps?.coverage?.length) {
            lines.push(`描画済み: ${checks.maps.coverage.map(map => {
                const visible = map.sample ? ` / 表示画素 ${(map.sample.visibleRatio * 100).toFixed(1)}%` : '';
                return `${map.id} ${map.tiles}枚${visible}`;
            }).join(' / ')}`);
        }
        if (checks.logs?.errors?.length) lines.push(`BlueMapログ: 警告/エラー ${checks.logs.errors.length}件`);
        result.textContent = lines.join('\n');
    } catch (error) {
        result.textContent = `診断に失敗しました: ${error.message}`;
    } finally {
        button.disabled = false;
    }
}
document.getElementById('map-diagnostics-button')?.addEventListener('click', runBlueMapDiagnostics);

function showToast(message) {
    toast.textContent = message;
    toast.classList.remove('hide');
    setTimeout(() => {
        toast.classList.add('hide');
    }, 2500);
}

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hide');
    
    const password = loginPassword.value;
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        });
        
        const data = await response.json();
        if (response.ok) {
            clearTimeout(sessionRestoreTimer);
            sessionRestoreTimer = null;
            currentToken = data.token;
            localStorage.setItem('gg_token', currentToken);
            // Do not retain the administrator password in a hidden login form
            // after the dashboard becomes active.
            loginPassword.value = '';
            showToast("セキュアログイン成功 🛡️");
            enterDashboard(data.config, data.agent);
        } else {
            showLoginError(data.error || "ログインに失敗しました。");
            if (data.setupRequired) initializeAuthView();
        }
    } catch (err) {
        showLoginError("GriefGuard Agentへ接続できません。Agentを起動してから再試行してください。");
    }
});

setupForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    loginError.classList.add('hide');
    if (setupPassword.value !== setupPasswordConfirm.value) {
        showLoginError('管理パスワードが一致しません。');
        return;
    }
    try {
        const response = await fetch('/api/setup/complete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code: setupCode.value.trim().toUpperCase(), password: setupPassword.value })
        });
        const data = await response.json();
        if (!response.ok) { showLoginError(data.error || '初回セットアップに失敗しました。'); return; }
        currentToken = data.token;
        localStorage.setItem('gg_token', currentToken);
        setupForm.reset();
        showToast('初回セットアップが完了しました');
        enterDashboard(data.config, data.agent);
    } catch (_) {
        showLoginError('Agentへ接続できません。起動状態を確認してください。');
    }
});

document.getElementById('btn-request-setup-code')?.addEventListener('click', () => {
    showToast('サーバーPCで Show-GriefGuard-Setup-Code.bat / .command を実行してください');
});

document.getElementById('btn-show-password-reset')?.addEventListener('click', async () => {
    loginForm.classList.add('hide');
    passwordResetForm.classList.remove('hide');
    loginError.classList.add('hide');
    const statusText = document.getElementById('password-reset-status');
    try {
        const response = await fetch('/api/setup/status');
        const status = await response.json();
        statusText.textContent = status.passwordResetAvailable
            ? '有効なリセットコードが発行されています。サーバーPCに表示されたコードを入力してください。'
            : 'まだコードは発行されていません。サーバーPCで Reset-GriefGuard-Admin-Password.bat / .command を実行してください。';
    } catch (_) {
        statusText.textContent = 'Agentへ接続できません。Agentの起動状態を確認してください。';
    }
});

document.getElementById('btn-cancel-password-reset')?.addEventListener('click', () => {
    passwordResetForm.reset();
    passwordResetForm.classList.add('hide');
    loginForm.classList.remove('hide');
    loginError.classList.add('hide');
});

passwordResetForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    loginError.classList.add('hide');
    if (passwordResetPassword.value !== passwordResetPasswordConfirm.value) {
        showLoginError('新しい管理パスワードが一致しません。');
        return;
    }
    try {
        const response = await fetch('/api/security/password-reset', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                code: passwordResetCode.value.trim().toUpperCase(),
                newPassword: passwordResetPassword.value
            })
        });
        const data = await response.json();
        if (!response.ok) { showLoginError(data.error || '管理パスワードをリセットできませんでした。'); return; }
        currentToken = data.token;
        localStorage.setItem('gg_token', currentToken);
        passwordResetForm.reset();
        passwordResetForm.classList.add('hide');
        loginForm.classList.remove('hide');
        showToast('管理パスワードをリセットしました');
        enterDashboard(data.config, data.agent);
    } catch (_) {
        showLoginError('Agentへ接続できません。起動状態を確認してください。');
    }
});

function showLoginError(msg) {
    loginError.textContent = msg;
    loginError.classList.remove('hide');
}

async function loadAccessInfo() {
    const target = document.getElementById('access-url-info');
    if (!target) return;
    try {
        const response = await fetch('/api/access-info');
        const info = await response.json();
        target.innerHTML = '';
        const current = document.createElement('div');
        current.className = 'access-url-row';
        current.innerHTML = `<span>ローカルテスト</span><code></code>`;
        current.querySelector('code').textContent = info.currentUrl;
        target.appendChild(current);
        const tailscale = document.createElement('div');
        tailscale.className = 'access-url-row';
        tailscale.innerHTML = `<span>Tailscale本番URL</span><code></code>`;
        tailscale.querySelector('code').textContent = info.tailscaleUrl || '設定画面でMagicDNS名を登録してください';
        target.appendChild(tailscale);
        const command = document.createElement('small');
        command.textContent = `Agent側の公開コマンド: ${info.serveCommand}`;
        target.appendChild(command);
    } catch (_) {
        target.textContent = '接続情報を取得できませんでした';
    }
}

loadAccessInfo();

async function initializeAuthView() {
    try {
        const response = await fetch('/api/setup/status');
        const status = await response.json();
        if (status.required) {
            currentToken = null;
            localStorage.removeItem('gg_token');
            loginForm.classList.add('hide');
            passwordResetForm.classList.add('hide');
            setupForm.classList.remove('hide');
            loginError.classList.add('hide');
            return;
        }
        setupForm.classList.add('hide');
        passwordResetForm.classList.add('hide');
        loginForm.classList.remove('hide');
        restoreSavedSession();
    } catch (_) {
        clearTimeout(sessionRestoreTimer);
        sessionRestoreTimer = setTimeout(initializeAuthView, 5000);
    }
}

async function restoreSavedSession() {
    const savedToken = localStorage.getItem('gg_token');
    if (!savedToken || currentToken) return;
    try {
        const response = await fetch('/api/agent/status', { headers: { Authorization: savedToken } });
        if (response.ok) {
            clearTimeout(sessionRestoreTimer);
            sessionRestoreTimer = null;
            currentToken = savedToken;
            enterDashboard({}, await response.json());
            showToast('Agentへ自動再接続しました');
            return;
        }
        if (response.status === 403) {
            localStorage.removeItem('gg_token');
            return;
        }
    } catch (_) {
        // Agent may be restarting. Keep the saved session and retry below.
    }
    clearTimeout(sessionRestoreTimer);
    sessionRestoreTimer = setTimeout(restoreSavedSession, 5000);
}

initializeAuthView();

function enterDashboard(config, agentInfo = null) {
    resetRootScroll();
    loginView.classList.remove('active');
    dashboardView.classList.add('active');
    
    connectionIndicator.className = "status-indicator loading";
    connectionIndicator.querySelector('.status-text').textContent = "AGENT CONNECTING...";
    if (agentInfo) applyAgentInfo(agentInfo);
    clearTimeout(socketReconnectTimer);
    socketReconnectTimer = null;
    if (socket) {
        socket.onclose = null;
        socket.close();
        socket = null;
    }
    connectRealServer(config);
    refreshAgentStatus();
    loadCommandHistory();
    clearInterval(agentStatusInterval);
    agentStatusInterval = setInterval(refreshAgentStatus, 10000);
    loadMetrics();
    clearInterval(metricsInterval);
    metricsInterval = setInterval(loadMetrics, 5000);
}

function agentModeLabel(mode) {
    return ({ windows: 'WINDOWS', linux: 'LINUX', panel: 'RENTAL PANEL', 'plugin-only': 'PLUGIN ONLY' })[mode] || String(mode || 'AGENT').toUpperCase();
}

function applyAgentInfo(agent) {
    currentAgent = agent;
    const pluginOnline = Boolean(agent.plugin?.connected);
    const overall = agent.health?.overall || (pluginOnline ? 'healthy' : 'unknown');
    const style = overall === 'healthy' ? 'online' : overall === 'bridge-disconnected' ? 'offline' : 'loading';
    connectionIndicator.className = `status-indicator ${style}`;
    connectionIndicator.querySelector('.status-text').textContent = overall === 'healthy'
        ? `${agentModeLabel(agent.mode)} • PAPER / PLUGIN ONLINE`
        : overall === 'paper-stopped' ? `${agentModeLabel(agent.mode)} • PAPER STOPPED`
        : overall === 'bridge-disconnected' ? `${agentModeLabel(agent.mode)} • PLUGIN OFFLINE`
        : `${agentModeLabel(agent.mode)} • STATUS CHECKING`;
    connectionIndicator.title = agent.health?.reason || '状態を確認中です。';
    const capabilityByCommand = { '/start': 'startServer', '/stop': 'stopServer', '/restart': 'restartServer', '/reload': 'reloadServer' };
    document.querySelectorAll('.action-btn').forEach(button => {
        const capability = capabilityByCommand[button.dataset.cmd];
        const supported = !capability || agent.capabilities?.[capability] !== false;
        button.disabled = !supported;
        button.classList.toggle('unsupported', !supported);
        if (!supported) button.title = '現在の接続方式では利用できません';
    });
    consoleInput.disabled = agent.capabilities?.console === false;
}

async function refreshAgentStatus() {
    if (!currentToken) return;
    try {
        const response = await fetch('/api/agent/status', { headers: { Authorization: currentToken } });
        if (response.ok) applyAgentInfo(await response.json());
    } catch (error) {
        connectionIndicator.className = 'status-indicator offline';
        connectionIndicator.querySelector('.status-text').textContent = 'AGENT OFFLINE';
    }
}

btnLogout.addEventListener('click', () => {
    const tokenToRevoke = currentToken;
    if (tokenToRevoke) {
        fetch('/api/logout', { method: 'POST', headers: { Authorization: tokenToRevoke }, keepalive: true }).catch(() => {});
    }
    currentToken = null;
    localStorage.removeItem('gg_token');
    clearInterval(agentStatusInterval);
    clearInterval(metricsInterval);
    clearTimeout(socketReconnectTimer);
    socketReconnectTimer = null;
    clearTimeout(sessionRestoreTimer);
    sessionRestoreTimer = null;
    if (socket) {
        socket.onclose = null;
        socket.close();
        socket = null;
    }
    dashboardView.classList.remove('active');
    loginView.classList.add('active');
    showToast("ログアウトしました");
});

function connectRealServer(config) {
    if (socket && (socket.readyState === WebSocket.CONNECTING || socket.readyState === WebSocket.OPEN)) return;

    clearTimeout(socketReconnectTimer);
    socketReconnectTimer = null;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;

    const activeSocket = new WebSocket(wsUrl);
    socket = activeSocket;
    
    activeSocket.onopen = () => {
        if (socket !== activeSocket) return;
        console.log("WebSocket connected.");
        activeSocket.send(JSON.stringify({ type: 'auth', token: currentToken }));
        // Operations can finish while a phone is backgrounded. Reloading the
        // persisted journal makes their final result visible after reconnect.
        loadCommandHistory();
    };
    
    activeSocket.onmessage = (event) => {
        if (socket !== activeSocket) return;
        try {
            const data = JSON.parse(event.data);
            if (data.type === 'status') {
                showToast("サーバー中継通信を確立しました");
                logLine("system", `[GriefGuard Mobile] Connected to server bridge.`);
            } else if (data.type === 'log') {
                logLine(data.level || "info", data.message);
                if (/\[GG-WARN\]|\[POTENTIAL-DANGER\]/.test(data.message || '')) {
                    sessionWarningCount += 1;
                    valWarnings.textContent = String(sessionWarningCount);
                    addWarningAlert(data.message);
                }
            } else if (data.type === 'metrics') {
                updateMetrics(data);
            } else if (data.type === 'server_status') {
                updateMetrics({ minecraft: data });
                if (data.playerList) loadPlayers();
            } else if (data.type === 'players_changed') {
                loadPlayers();
            } else if (data.type === 'player_updated' && data.player) {
                applyPlayerUpdate(data.player);
            } else if (data.type === 'ban_sync') {
                renderBanList(data.ips);
            } else if (data.type === 'ban_changed') {
                loadBans();
            } else if (data.type === 'plugin_status') {
                if (currentAgent) {
                    const paperOnline = Boolean(currentAgent.health?.paperOnline);
                    applyAgentInfo({
                        ...currentAgent,
                        plugin: data,
                        health: {
                            ...currentAgent.health,
                            bridgeOnline: Boolean(data.connected),
                            overall: data.connected ? 'healthy' : paperOnline ? 'bridge-disconnected' : 'paper-stopped',
                            reason: data.connected ? 'Agent・Paper・GriefGuard Pluginは接続済みです。' : paperOnline ? 'Paperは起動中ですが、GriefGuard PluginがAgentへ接続していません。' : 'Paperは停止中です。'
                        }
                    });
                }
            } else if (data.type === 'command_event' && data.event) {
                renderCommandEvent(data.event);
            } else if (data.type === 'error' && /Unauthorized/i.test(data.message || '')) {
                currentToken = null;
                localStorage.removeItem('gg_token');
                activeSocket.onclose = null;
                activeSocket.close();
                socket = null;
                dashboardView.classList.remove('active');
                loginView.classList.add('active');
                showLoginError('認証セッションが無効になりました。再ログインしてください。');
                initializeAuthView();
            }
        } catch (e) {
            console.error("WS error parsing message:", e);
        }
    };
    
    activeSocket.onclose = () => {
        if (socket !== activeSocket) return;
        socket = null;
        connectionIndicator.className = "status-indicator offline";
        connectionIndicator.querySelector('.status-text').textContent = "DISCONNECTED";
        logLine("error", `[GriefGuard Mobile] Disconnected from server bridge.`);
        clearTimeout(socketReconnectTimer);
        socketReconnectTimer = setTimeout(() => {
            socketReconnectTimer = null;
            if (currentToken) connectRealServer(config);
        }, 5000);
    };
}

document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const cmd = btn.getAttribute('data-cmd');
        const reasonCode = cmd === '/stop' ? 'manual-stop' : (cmd === '/restart' ? 'manual-restart' : undefined);
        const actionName = btn.querySelector('.action-title')?.textContent?.trim() || 'クイック操作';
        logLine('info', `[Quick Control] ${actionName}: ${cmd}`);
        showToast(reasonCode ? 'ゲーム内へ通知後、約5秒で実行します' : `コマンド送信中: ${cmd}`);
        
        btn.disabled = true;
        try {
            const { response, data } = await sendControlCommand(cmd, reasonCode);
            if (data.commandEvent) renderCommandEvent(data.commandEvent);
            if (response.ok) {
                const message = data.message || '操作を受け付けました。';
                logLine('system', `[Agent] ${message}`);
                showToast(message);
            } else {
                const message = data.error || '操作に失敗しました。';
                logLine('error', `[Quick Control Error] ${message}`);
                showToast(`エラー: ${message}`);
            }
        } catch (e) {
            logLine('error', `[Quick Control Error] ${e.message || 'Agentとの通信に失敗しました。'}`);
            showToast(e.message || '通信エラーが発生しました。');
        } finally {
            btn.disabled = false;
        }
    });
});

consoleInputForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const cmd = consoleInput.value.trim();
    if (!cmd) return;
    
    hideSuggestions();
    // A submitted command must never remain over the mobile keyboard or keep
    // autocomplete visible, including when Paper is offline or the request
    // fails before the Agent can create a journal event.
    consoleInput.value = '';
    try {
        const { response, data } = await sendControlCommand(cmd);
        if (data.commandEvent) {
            // The Agent has accepted and journaled this request even when the
            // later Paper/Bridge execution reports a failure (HTTP 503). Do
            // not leave an already-sent command in the input field.
            renderCommandEvent(data.commandEvent);
        } else if (!response.ok) {
            logLine('error', `[System Error] ${data.error || 'コマンドを送信できませんでした。'}`);
        }
    } catch (err) {
        logLine('error', `[Connection Error] ${err.message || 'コマンドを送信できませんでした。'}`);
    }
});

function returnToLoginForExpiredSession() {
    currentToken = null;
    localStorage.removeItem('gg_token');
    clearTimeout(socketReconnectTimer);
    socketReconnectTimer = null;
    if (socket) {
        socket.onclose = null;
        socket.close();
        socket = null;
    }
    dashboardView.classList.remove('active');
    loginView.classList.add('active');
    showLoginError('認証セッションの有効期限が切れました。管理パスワードで再ログインしてください。');
    initializeAuthView();
}

async function sendControlCommand(command, reasonCode) {
    const controller = new AbortController();
    // /api/control now returns as soon as the Agent journals the operation.
    // Keep this short only for connection failure; Paper startup itself is
    // reported asynchronously via command_event and is never cut off here.
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
        const response = await fetch('/api/control', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': currentToken
            },
            // HTTP headers are limited to Latin-1 in several browsers. Keep
            // the Japanese device name in the UTF-8 JSON payload instead.
            body: JSON.stringify({ command, clientName: clientName(), ...(reasonCode ? { reasonCode } : {}) }),
            signal: controller.signal
        });
        const data = await response.json().catch(() => ({}));
        if (response.status === 401 || response.status === 403) {
            returnToLoginForExpiredSession();
            throw new Error('認証が無効です。再ログインしてください。');
        }
        return { response, data };
    } catch (error) {
        if (error.name === 'AbortError') throw new Error('Agentへ操作を受け付けさせられませんでした。接続状態を確認してください。');
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

function logLine(level, message) {
    const p = document.createElement('div');
    p.className = `console-line ${level}`;
    
    const now = new Date();
    const timeStr = `[${now.toTimeString().split(' ')[0]}]`;
    p.textContent = `${timeStr} ${message}`;
    
    consoleOutput.appendChild(p);
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
    
    while (consoleOutput.childNodes.length > 150) {
        consoleOutput.removeChild(consoleOutput.firstChild);
    }
}

function updateMetrics(data) {
    const minecraft = data.minecraft || data || {};
    const host = data.host || null;
    if (minecraft.players !== undefined) valPlayers.textContent = `${minecraft.players}/${minecraft.maxPlayers ?? '?'}`;
    if (minecraft.warnings !== undefined) valWarnings.textContent = minecraft.warnings;
    if (host?.cpu !== null && host?.cpu !== undefined) {
        cpuPct.textContent = `${host.cpu}%`;
        cpuFill.style.width = `${host.cpu}%`;
    }
    const configured = data.configuredMemory || currentAgent?.local?.memory || {};
    if (configured.min || configured.max) {
        ramConfigHint.textContent = `設定済み: Xms ${configured.min || '未設定'} / Xmx ${configured.max || '未設定'}${configured.source ? `（${configured.source}）` : ''}`;
    } else {
        ramConfigHint.textContent = '設定値を取得できません。Agent設定を確認してください。';
    }
    const used = minecraft.heapUsedBytes;
    const maximum = minecraft.heapMaxBytes;
    if (used !== undefined && maximum) {
        const pct = Math.round(used / maximum * 100);
        ramUsage.textContent = `${(used / 1024 / 1024 / 1024).toFixed(1)} / ${(maximum / 1024 / 1024 / 1024).toFixed(1)} GB`;
        ramFill.style.width = `${pct}%`;
    }
}

function renderCommandEvent(event) {
    if (!event?.id) return;
    const escaped = window.CSS?.escape ? CSS.escape(event.id) : event.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const existing = consoleOutput.querySelector(`[data-command-id="${escaped}"]`);
    const time = event.time ? new Date(event.time).toLocaleTimeString('ja-JP') : new Date().toLocaleTimeString('ja-JP');
    const state = event.status === 'failed' ? `失敗: ${event.message}`
        : event.status === 'success' ? `完了: ${event.message}`
            : event.status === 'running' ? `処理中: ${event.message || 'Paperの応答を待っています。'}`
                : `受付: ${event.message || 'Agentが操作を受け付けました。'}`;
    const message = `> ${event.command}  [${event.device} / ${event.channel}] ${state}`;
    const level = event.status === 'failed' ? 'error' : event.status === 'success' ? 'system' : 'info';
    if (existing) {
        existing.className = `console-line ${level}`;
        existing.textContent = `[${time}] ${message}`;
        return;
    }
    const line = document.createElement('div');
    line.dataset.commandId = event.id;
    line.className = `console-line ${level}`;
    line.textContent = `[${time}] ${message}`;
    consoleOutput.appendChild(line);
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
    while (consoleOutput.childNodes.length > 150) consoleOutput.removeChild(consoleOutput.firstChild);
}

async function loadCommandHistory() {
    if (!currentToken) return;
    try {
        const response = await fetch('/api/console/history?limit=100', { headers: { Authorization: currentToken } });
        if (!response.ok) return;
        const data = await response.json();
        (data.entries || []).forEach(renderCommandEvent);
    } catch (_) {}
}

async function loadMetrics() {
    if (!currentToken) return;
    try {
        const response = await fetch('/api/metrics', { headers: { Authorization: currentToken } });
        if (response.ok) updateMetrics(await response.json());
    } catch (_) {}
}

async function loadBans() {
    try {
        const response = await fetch('/api/bans', { headers: { Authorization: currentToken } });
        if (!response.ok) throw new Error('BANリストを取得できませんでした');
        const data = await response.json();
        bannedIpsList = Array.isArray(data.ips) ? data.ips : [];
        renderBanList();
    } catch (error) {
        banCountBadge.textContent = '--';
        banListContainer.innerHTML = '<div class="empty-state">BANリストを読み込めませんでした。</div>';
        renderListPagination('ban-pagination', 'bans', 0, MANAGEMENT_DISPLAY_LIMITS.bannedIps, renderBanList);
    }
}

function renderBanList() {
    const ips = bannedIpsList;
    banListContainer.innerHTML = '';
    const pageData = pageItems(ips, 'bans', MANAGEMENT_DISPLAY_LIMITS.bannedIps);
    banCountBadge.textContent = ips.length > pageData.items.length
        ? `${pageData.items.length} / ${ips.length} IPs`
        : `${ips.length} IPs`;
    
    if (ips.length === 0) {
        banListContainer.innerHTML = '<div class="empty-state">BANされたIPアドレスはありません。</div>';
        renderListPagination('ban-pagination', 'bans', 0, MANAGEMENT_DISPLAY_LIMITS.bannedIps, renderBanList);
        return;
    }
    
    pageData.items.forEach(ip => {
        const item = document.createElement('div');
        item.className = 'list-item';
        
        item.innerHTML = `
            <div class="item-info">
                <span class="item-title">${ip}</span>
                <span class="item-subtitle">Paper banned-ips.json</span>
            </div>
            <button class="btn-small-danger btn-unban" data-ip="${ip}">解除</button>
        `;
        
        item.querySelector('.btn-unban').addEventListener('click', async () => {
            const response = await fetch(`/api/bans/ip/${encodeURIComponent(ip)}`, { method: 'DELETE', headers: { Authorization: currentToken } });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) { showToast(data.error || 'BAN解除に失敗しました'); return; }
            showToast(`${ip} のBAN解除コマンドを送信しました`);
            setTimeout(loadBans, 500);
        });
        
        banListContainer.appendChild(item);
    });
    renderListPagination('ban-pagination', 'bans', ips.length, MANAGEMENT_DISPLAY_LIMITS.bannedIps, renderBanList);
}

function addWarningAlert(desc) {
    warningLogs.unshift({ description: String(desc || '警告を受信しました。'), at: new Date() });
    if (warningLogs.length > MANAGEMENT_WARNING_HISTORY_LIMIT) warningLogs = warningLogs.slice(0, MANAGEMENT_WARNING_HISTORY_LIMIT);
    managementPage.warnings = 1;
    renderWarningLogs();
}

function renderWarningLogs() {
    warningLogsContainer.replaceChildren();
    const pageData = pageItems(warningLogs, 'warnings', MANAGEMENT_DISPLAY_LIMITS.warningLogs);
    if (warningLogCountBadge) {
        warningLogCountBadge.textContent = warningLogs.length > pageData.items.length
            ? `${pageData.items.length} / ${warningLogs.length}`
            : `${warningLogs.length} / ${warningLogs.length}`;
    }
    if (warningLogs.length === 0) {
        warningLogsContainer.innerHTML = '<div class="empty-state">この接続中に受信した警告はありません。</div>';
        renderListPagination('warning-pagination', 'warnings', 0, MANAGEMENT_DISPLAY_LIMITS.warningLogs, renderWarningLogs);
        return;
    }

    pageData.items.forEach(entry => {
        const item = document.createElement('div');
        item.className = 'alert-item';
        const icon = document.createElement('span');
        icon.className = 'alert-icon';
        icon.textContent = '⚠️';
        const info = document.createElement('div');
        info.className = 'alert-info';
        const message = document.createElement('span');
        message.className = 'alert-desc';
        message.textContent = entry.description;
        const time = document.createElement('span');
        time.className = 'alert-time';
        time.textContent = new Date(entry.at).toLocaleTimeString('ja-JP');
        info.append(message, time);
        item.append(icon, info);
        warningLogsContainer.appendChild(item);
    });
    renderListPagination('warning-pagination', 'warnings', warningLogs.length, MANAGEMENT_DISPLAY_LIMITS.warningLogs, renderWarningLogs);
}

// ----------------------------------------------------
// AUTO-RESTART SCHEDULER CONTROLLER
// ----------------------------------------------------
const scheduleEnabled = document.getElementById('restart-schedule-enabled');
const scheduleTime = document.getElementById('restart-schedule-time');
const scheduleSettingsGroup = document.getElementById('scheduler-settings-group');
const btnSaveSchedule = document.getElementById('btn-save-schedule');

scheduleEnabled.addEventListener('change', () => {
    if (scheduleEnabled.checked) {
        scheduleSettingsGroup.classList.remove('disabled');
    } else {
        scheduleSettingsGroup.classList.add('disabled');
    }
});

async function loadRestartSchedule() {
    try {
        const response = await fetch('/api/restart-schedule', {
            headers: { 'Authorization': currentToken }
        });
        if (response.ok) {
            const data = await response.json();
            scheduleEnabled.checked = data.enabled;
            scheduleTime.value = data.time || "04:00";
            if (data.enabled) {
                scheduleSettingsGroup.classList.remove('disabled');
            } else {
                scheduleSettingsGroup.classList.add('disabled');
            }
        }
    } catch (e) {
        console.error("Failed to load restart schedule:", e);
    }
}

btnSaveSchedule.addEventListener('click', async () => {
    const enabled = scheduleEnabled.checked;
    const time = scheduleTime.value;
    
    showToast("再起動スケジュールを保存中...");
    
    try {
        const response = await fetch('/api/restart-schedule', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': currentToken
            },
            body: JSON.stringify({ enabled, time })
        });
        
        if (response.ok) {
            showToast("スケジュールを保存しました 🔄");
            logLine("system", `[GriefGuard Mobile] Auto-restart settings updated successfully.`);
        } else {
            showToast("保存に失敗しました。");
        }
    } catch (e) {
        showToast("通信エラーが発生しました。");
    }
});

const originalEnterDashboard = enterDashboard;
enterDashboard = function(config, agentInfo) {
    originalEnterDashboard(config, agentInfo);
    loadRestartSchedule();
    loadCommands();
    loadConfig();
    loadBans();
    loadPlayers();
};

// ----------------------------------------------------
// COMMAND AUTOCOMPLETE ENGINE
// ----------------------------------------------------
let commandsList = [];
let filteredSuggestions = [];
let selectedSuggestionIndex = -1;

const suggestionsBox = document.getElementById('autocomplete-suggestions');

async function loadCommands() {
    try {
        const response = await fetch('/api/commands', {
            headers: { 'Authorization': currentToken }
        });
        if (response.ok) {
            commandsList = await response.json();
        }
    } catch (e) {
        console.error("Failed to load commands for autocomplete:", e);
    }
}

consoleInput.addEventListener('input', () => {
    const val = consoleInput.value;
    if (!val.startsWith('/')) {
        hideSuggestions();
        return;
    }
    
    filteredSuggestions = commandsList.filter(item => 
        item.command.toLowerCase().includes(val.toLowerCase())
    );
    
    if (filteredSuggestions.length > 0 && val !== '') {
        renderSuggestions();
    } else {
        hideSuggestions();
    }
});

consoleInput.addEventListener('keydown', (e) => {
    if (suggestionsBox.classList.contains('hide')) {
        if (e.key === 'Enter') {
            e.preventDefault();
            consoleInputForm.requestSubmit();
        }
        return;
    }
    
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        selectedSuggestionIndex = (selectedSuggestionIndex + 1) % filteredSuggestions.length;
        highlightSuggestion();
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        selectedSuggestionIndex = (selectedSuggestionIndex - 1 + filteredSuggestions.length) % filteredSuggestions.length;
        highlightSuggestion();
    } else if (e.key === 'Enter') {
        if (selectedSuggestionIndex > -1) {
            e.preventDefault();
            selectSuggestion(filteredSuggestions[selectedSuggestionIndex].command);
        } else {
            // Mobile and some desktop IMEs do not always synthesize a native
            // form submit while the autocomplete panel is open.
            e.preventDefault();
            consoleInputForm.requestSubmit();
        }
    } else if (e.key === 'Tab' && selectedSuggestionIndex > -1) {
        e.preventDefault();
        selectSuggestion(filteredSuggestions[selectedSuggestionIndex].command);
    } else if (e.key === 'Escape') {
        hideSuggestions();
    }
});

function renderSuggestions() {
    suggestionsBox.innerHTML = '';
    selectedSuggestionIndex = -1;
    
    filteredSuggestions.forEach((item, idx) => {
        const div = document.createElement('div');
        div.className = 'suggestion-item';
        div.innerHTML = `
            <span class="suggestion-cmd">${item.command}</span>
            <span class="suggestion-desc">${item.description}</span>
        `;
        
        div.addEventListener('click', () => {
            selectSuggestion(item.command);
        });
        
        suggestionsBox.appendChild(div);
    });
    
    suggestionsBox.classList.remove('hide');
}

function highlightSuggestion() {
    const items = suggestionsBox.querySelectorAll('.suggestion-item');
    items.forEach(el => el.classList.remove('selected'));
    
    if (selectedSuggestionIndex > -1 && items[selectedSuggestionIndex]) {
        const activeItem = items[selectedSuggestionIndex];
        activeItem.classList.add('selected');
        activeItem.scrollIntoView({ block: 'nearest' });
    }
}

function selectSuggestion(cmd) {
    consoleInput.value = cmd + ' ';
    consoleInput.focus();
    hideSuggestions();
}

function hideSuggestions() {
    suggestionsBox.classList.add('hide');
    suggestionsBox.innerHTML = '';
    selectedSuggestionIndex = -1;
}

// ----------------------------------------------------
// SECURITY PLAYER MANAGER (SEARCH / SORT / ACTION)
// ----------------------------------------------------
let playersList = [];

const playerSearch = document.getElementById('player-search');
const playerSort = document.getElementById('player-sort');
const playerListContainer = document.getElementById('player-list-container');
const playerCountBadge = document.getElementById('player-count');
const editionIndicator = document.getElementById('edition-indicator');
let highEditionActive = false;

function escapeMarkup(value) {
    return String(value ?? '').replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}

async function refreshEditionIndicator() {
    try {
        const response = await fetch('/api/edition', { headers: { Authorization: currentToken } });
        const edition = await response.json();
        if (!response.ok || edition.edition === 'unknown') { highEditionActive = false; editionIndicator.hidden = true; return false; }
        editionIndicator.hidden = false;
        editionIndicator.textContent = edition.edition === 'high' ? 'HIGH VERSION' : 'STANDARD';
        editionIndicator.classList.toggle('high', edition.edition === 'high');
        highEditionActive = edition.edition === 'high';
        return highEditionActive;
    } catch (_) { highEditionActive = false; editionIndicator.hidden = true; return false; }
}

async function showHighSecuritySummary(player) {
    try {
        const response = await fetch(`/api/players/${encodeURIComponent(player.uuid)}/security-summary`, { headers: { Authorization: currentToken } });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || '接続履歴を取得できませんでした。');
        const history = (data.history || []).map(item => `${item.result === 'rejected' ? '拒否' : '許可'}  ${new Date(item.timestamp).toLocaleString('ja-JP')}  ${item.address}  ${item.clientBrand || ''}`).join('\n') || '履歴はありません。';
        const related = (data.correlations || []).map(item => `${item.name}  (${item.reason === 'same-address' ? '同一接続元候補' : item.reason})`).join('\n') || '関連候補はありません。';
        const panel = document.createElement('div');
        panel.className = 'high-security-dialog';
        panel.innerHTML = `<div class="high-security-dialog-card glass"><button type="button" class="btn-icon high-security-close" aria-label="閉じる">×</button><h3>${escapeMarkup(player.name)} の接続保護</h3><p>ログイン ${Number(data.loginCount || 0)}回 / 拒否 ${Number(data.rejectedCount || 0)}回 / 接続元 ${Number(data.uniqueAddressCount || 0)}件</p><h4>接続履歴</h4><pre></pre><h4>関連アカウント候補</h4><pre></pre><small>${escapeMarkup(data.notice || '候補情報は自動処罰に使用されません。')}</small></div>`;
        panel.querySelectorAll('pre')[0].textContent = history;
        panel.querySelectorAll('pre')[1].textContent = related;
        const close = () => panel.remove();
        panel.querySelector('.high-security-close').addEventListener('click', close);
        panel.addEventListener('click', event => { if (event.target === panel) close(); });
        document.body.appendChild(panel);
    } catch (error) { showToast(error.message); }
}

async function loadPlayers() {
    try {
        const response = await fetch('/api/players', {
            headers: { 'Authorization': currentToken }
        });
        if (response.ok) {
            playersList = await response.json();
            await refreshEditionIndicator();
            renderPlayers();
        }
    } catch (e) {
        console.error("Failed to load players list:", e);
    }
}

function resetPlayersPageAndRender() {
    managementPage.players = 1;
    renderPlayers();
}

playerSearch.addEventListener('input', resetPlayersPageAndRender);
playerSort.addEventListener('change', resetPlayersPageAndRender);

function renderPlayers() {
    const searchVal = playerSearch.value.trim().toLowerCase();
    const sortVal = playerSort.value;
    
    let filtered = playersList.filter(p => 
        p.name.toLowerCase().includes(searchVal) || String(p.ip || '').toLowerCase().includes(searchVal)
    );
    
    filtered.sort((a, b) => {
        if (sortVal === 'last-login') {
            return (b.lastLogin ? new Date(b.lastLogin).getTime() : 0) - (a.lastLogin ? new Date(a.lastLogin).getTime() : 0);
        } else if (sortVal === 'warnings') {
            return (b.warnings ?? -1) - (a.warnings ?? -1);
        } else if (sortVal === 'login-count') {
            return (b.loginCount ?? 0) - (a.loginCount ?? 0);
        } else if (sortVal === 'name') {
            return a.name.localeCompare(b.name);
        }
        return 0;
    });
    
    playerListContainer.innerHTML = '';
    const pageData = pageItems(filtered, 'players', MANAGEMENT_DISPLAY_LIMITS.players);
    playerCountBadge.textContent = filtered.length > pageData.items.length
        ? `${pageData.items.length} / ${filtered.length} Players`
        : `${filtered.length} Players`;
    
    if (filtered.length === 0) {
        playerListContainer.innerHTML = '<div class="empty-state">該当するプレイヤーは見つかりませんでした。</div>';
        renderListPagination('player-pagination', 'players', 0, MANAGEMENT_DISPLAY_LIMITS.players, renderPlayers);
        return;
    }
    
    pageData.items.forEach(p => {
        const item = document.createElement('div');
        item.className = `list-item ${p.status === 'BANNED' ? 'banned' : ''}`;
        
        const dateStr = p.status === 'ONLINE' ? '現在オンライン' : (p.lastLogin ? new Date(p.lastLogin).toLocaleString('ja-JP', { timeZone: 'Asia/Tokyo' }) : '履歴のみ');
        const warningText = p.warnings === null || p.warnings === undefined ? '警告: オフライン時は未取得' : `警告: ${p.warnings}回`;
        const warningBadgeClass = p.warnings === null || p.warnings === undefined ? '' : (p.warnings >= 3 ? 'badge-danger' : (p.warnings > 0 ? 'badge-warning' : 'badge-success'));
        const ipText = p.ip || '取得なし';
        const loginText = `ログイン: ${p.loginCount ?? 0}回`;
        const profileControl = p.uuid && !p.op ? `
            <div class="player-profile-control" role="group" aria-label="${p.name} の検知プロフィール">
                <span>検知</span><button type="button" class="player-profile-btn ${p.relaxed ? '' : 'active'}" data-profile="normal">通常</button>
                <button type="button" class="player-profile-btn ${p.relaxed ? 'active' : ''}" data-profile="relaxed">緩和</button>
            </div>` : (p.op ? '<span class="player-op-note">OP（検知対象外）</span>' : '');
        const operatorControl = p.uuid ? `<button class="btn-small ${p.op ? 'btn-small-danger' : ''} player-operator" data-uuid="${p.uuid}">${p.op ? 'OPを解除' : 'OPにする'}</button>` : '';
        const highControl = highEditionActive && p.uuid ? `<button class="btn-small player-high-security" data-uuid="${p.uuid}">接続保護</button>` : '';
        
        item.innerHTML = `
            <div class="item-info">
                <span class="item-title">${p.name} <span class="badge ${warningBadgeClass}">${warningText}</span></span>
                <span class="item-subtitle">${p.status} ${p.profile ? `| ${p.profile}` : ''} | ${loginText} | IP: ${ipText} | ${dateStr}</span>
            </div>
            <div class="player-actions">
                ${profileControl}
                ${operatorControl}
                ${highControl}
                ${!p.whitelisted && p.status !== 'BANNED' ? `<button class="btn-small whitelist-from-player" data-name="${p.name}">許可</button>` : (p.whitelisted ? '<span class="player-whitelisted">許可済み</span>' : '')}
                ${p.status === 'BANNED' ? 
                    `<button class="btn-small-danger btn-pardon-player" style="background: rgba(0,255,102,0.1); border-color: rgba(0,255,102,0.25); color: #00ff66;" data-name="${p.name}">解除</button>` : 
                    `<button class="btn-small-danger btn-ban-player" data-name="${p.name}" data-ip="${p.ip}">緊急BAN</button>`
                }
            </div>
        `;
        
        const btnBan = item.querySelector('.btn-ban-player');
        if (btnBan) {
            btnBan.addEventListener('click', () => {
                triggerPlayerBan(p.name, p.ip);
            });
        }
        
        const btnPardon = item.querySelector('.btn-pardon-player');
        if (btnPardon) {
            btnPardon.addEventListener('click', () => {
                triggerPlayerPardon(p.name, p.ip);
            });
        }
        item.querySelectorAll('.player-profile-btn').forEach(profileButton => {
            profileButton.addEventListener('click', async () => {
                const requestedProfile = profileButton.dataset.profile;
                if ((p.relaxed ? 'relaxed' : 'normal') === requestedProfile) return;
                const previous = p.relaxed ? 'relaxed' : 'normal';
                item.querySelectorAll('.player-profile-btn').forEach(button => { button.disabled = true; });
                try {
                    const response = await fetch(`/api/players/${encodeURIComponent(p.uuid)}/profile`, {
                        method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: currentToken },
                        body: JSON.stringify({ profile: requestedProfile })
                    });
                    const data = await response.json().catch(() => ({}));
                    if (!response.ok) throw new Error(data.error || 'プロフィールを変更できませんでした');
                    p.relaxed = (data.profile || requestedProfile).toLowerCase() === 'relaxed';
                    p.profile = p.relaxed ? 'RELAXED' : 'NORMAL';
                    showToast(data.message || '検知プロフィールを変更しました');
                    renderPlayers();
                } catch (error) {
                    p.relaxed = previous === 'relaxed';
                    showToast(error.message);
                } finally { item.querySelectorAll('.player-profile-btn').forEach(button => { button.disabled = false; }); }
            });
        });
        const operatorButton = item.querySelector('.player-operator');
        if (operatorButton) operatorButton.addEventListener('click', () => openOperatorModal(p));
        const highSecurityButton = item.querySelector('.player-high-security');
        if (highSecurityButton) highSecurityButton.addEventListener('click', () => showHighSecuritySummary(p));
        const whitelistButton = item.querySelector('.whitelist-from-player');
        if (whitelistButton) {
            whitelistButton.addEventListener('click', async () => {
                whitelistButton.disabled = true;
                try {
                    const response = await fetch('/api/whitelist/bulk', {
                        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken },
                        body: JSON.stringify({ names: [p.name] })
                    });
                    const data = await response.json().catch(() => ({}));
                    if (!response.ok || !data.results?.[0]?.ok) throw new Error(data.error || data.results?.[0]?.error || '追加に失敗しました');
                    showToast(`${p.name} の参加を許可しました`);
                    setTimeout(loadPlayers, 500);
                } catch (error) { showToast(error.message); }
                finally { whitelistButton.disabled = false; }
            });
        }
        
        playerListContainer.appendChild(item);
    });
    renderListPagination('player-pagination', 'players', filtered.length, MANAGEMENT_DISPLAY_LIMITS.players, renderPlayers);
}

function applyPlayerUpdate(update) {
    const index = playersList.findIndex(player => String(player.uuid || '').toLowerCase() === String(update.uuid || '').toLowerCase());
    if (index < 0) return loadPlayers();
    playersList[index] = { ...playersList[index], ...update, status: update.online ? 'ONLINE' : playersList[index].status };
    renderPlayers();
}

function closeOperatorModal() {
    operatorModal.classList.add('hide');
    document.body.classList.remove('modal-open');
    operatorCurrentPassword.value = '';
    operatorConfirmation.value = '';
    operatorTarget = null;
}

function openOperatorModal(player) {
    if (!player?.uuid) return;
    operatorTarget = player;
    const granting = !player.op;
    operatorModalTitle.textContent = granting ? 'OP権限を付与' : 'OP権限を解除';
    operatorModalWarning.textContent = granting
        ? 'OPはサーバー全体を操作でき、GriefGuardの検知対象外になります。付与すると検知プロフィールは通常へ戻ります。'
        : 'このプレイヤーのOP権限を解除します。解除後は通常プレイヤーとして扱われます。';
    operatorPlayerName.value = player.name;
    operatorSubmit.textContent = granting ? 'OPを付与する' : 'OPを解除する';
    operatorModal.classList.remove('hide');
    document.body.classList.add('modal-open');
    setTimeout(() => operatorConfirmation.focus(), 0);
}

operatorForm?.addEventListener('submit', async event => {
    event.preventDefault();
    if (!operatorTarget) return;
    const operator = !operatorTarget.op;
    operatorSubmit.disabled = true;
    try {
        const response = await fetch(`/api/players/${encodeURIComponent(operatorTarget.uuid)}/operator`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: currentToken },
            body: JSON.stringify({ operator, confirmation: operatorConfirmation.value.trim(), currentPassword: operatorCurrentPassword.value })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'OP権限を変更できませんでした');
        applyPlayerUpdate({ uuid: operatorTarget.uuid, name: operatorTarget.name, op: operator, relaxed: false, profile: operator ? 'OP' : 'NORMAL' });
        showToast(data.message || '権限を変更しました');
        closeOperatorModal();
    } catch (error) {
        showToast(error.message || 'OP権限を変更できませんでした');
    } finally { operatorSubmit.disabled = false; }
});

document.querySelectorAll('[data-close-operator-modal], #btn-close-operator-modal, #btn-cancel-operator').forEach(button => button.addEventListener('click', closeOperatorModal));

function triggerPlayerBan(name, ip) {
    showToast(`緊急BANコマンドを送信します: ${name}`);
    sendRemoteConsoleCommand(`/ban ${name}`);
    if (ip) sendRemoteConsoleCommand(`/ban-ip ${ip}`);
    setTimeout(loadPlayers, 500);
}

function triggerPlayerPardon(name, ip) {
    showToast(`BAN解除コマンドを送信します: ${name}`);
    sendRemoteConsoleCommand(`/pardon ${name}`);
    sendRemoteConsoleCommand(`/griefguard unban ${name}`);
    if (ip) sendRemoteConsoleCommand(`/pardon-ip ${ip}`);
    setTimeout(loadPlayers, 500);
}

async function sendRemoteConsoleCommand(cmd) {
    try {
        const { response, data } = await sendControlCommand(cmd);
        if (data.commandEvent) renderCommandEvent(data.commandEvent);
        if (!response.ok) throw new Error(data.error || 'コマンドを送信できませんでした。');
    } catch (e) {
        logLine('error', `[Player Control Error] ${e.message || 'コマンドを送信できませんでした。'}`);
        showToast(e.message || 'プレイヤー操作を送信できませんでした。');
    }
}

document.querySelectorAll('.segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        if (target === 'tab-management') {
            loadPlayers();
        } else if (target === 'tab-settings') {
            loadConfig();
            loadServerProperties();
            loadPluginConfigFiles();
            loadInstalledPlugins();
            loadAgentAccessConfig();
        }
    });
});

// ----------------------------------------------------
// INTERACTIVE CONFIG.YML & SERVER.PROPERTIES SETTINGS ENGINE
// ----------------------------------------------------
const cfgAutoBan = document.getElementById('cfg-auto-ban');
const cfgAutoRollback = document.getElementById('cfg-auto-rollback');
const cfgBackupStorage = document.getElementById('cfg-backup-storage');
const cfgBackupCustomDirectory = document.getElementById('cfg-backup-custom-directory');
const cfgBackupCustomRow = document.getElementById('cfg-backup-custom-row');
const cfgBackupRetentionSummary = document.getElementById('cfg-backup-retention-summary');
const cfgMaxWarnings = document.getElementById('cfg-max-warnings');
const cfgMaxWarningsVal = document.getElementById('cfg-max-warnings-val');
const cfgMobKills = document.getElementById('cfg-mob-kills');
const cfgTntPlacements = document.getElementById('cfg-tnt-placements');
const cfgLiquidPlacements = document.getElementById('cfg-liquid-placements');
const cfgDdosLimit = document.getElementById('cfg-ddos-limit');
const cfgBanReason = document.getElementById('cfg-ban-reason');
const cfgDiscordEnabled = document.getElementById('cfg-discord-enabled');
const cfgDiscordToken = document.getElementById('cfg-discord-token');
const cfgDiscordBridgeMode = document.getElementById('cfg-discord-bridge-mode');
const cfgDiscordVpsIp = document.getElementById('cfg-discord-vps-ip');
const cfgDiscordBridgePort = document.getElementById('cfg-discord-bridge-port');
const cfgDiscordWindowsIp = document.getElementById('cfg-discord-windows-ip');
const cfgDiscordLauncherPort = document.getElementById('cfg-discord-launcher-port');
const cfgDiscordProxyPort = document.getElementById('cfg-discord-proxy-port');
const cfgDiscordMinecraftPort = document.getElementById('cfg-discord-minecraft-port');
const cfgDiscordRestartScript = document.getElementById('cfg-discord-restart-script');

cfgBackupStorage.addEventListener('change', () => {
    cfgBackupCustomRow.hidden = cfgBackupStorage.value !== 'custom';
});
const cfgNormalWindow = document.getElementById('cfg-normal-window');
const cfgNormalMaxWarnings = document.getElementById('cfg-normal-max-warnings');
const cfgRelaxedWindow = document.getElementById('cfg-relaxed-window');
const cfgRelaxedMaxWarnings = document.getElementById('cfg-relaxed-max-warnings');
const cfgNormalNotify = document.getElementById('cfg-normal-notify');
const cfgNormalNotifyEnabled = document.getElementById('cfg-normal-notify-enabled');
const cfgNormalNotifyValue = document.getElementById('cfg-normal-notify-value');
const cfgNormalMark = document.getElementById('cfg-normal-mark');
const cfgRelaxedNotify = document.getElementById('cfg-relaxed-notify');
const cfgRelaxedNotifyEnabled = document.getElementById('cfg-relaxed-notify-enabled');
const cfgRelaxedNotifyValue = document.getElementById('cfg-relaxed-notify-value');
const cfgRelaxedMark = document.getElementById('cfg-relaxed-mark');
const cfgFastBanEnabled = document.getElementById('cfg-fast-ban-enabled');
const cfgFastBanWindow = document.getElementById('cfg-fast-ban-window');
const cfgNormalFastBan = document.getElementById('cfg-normal-fast-ban');
const cfgRelaxedFastBan = document.getElementById('cfg-relaxed-fast-ban');
const cfgFastBanRequireMark = document.getElementById('cfg-fast-ban-require-mark');
const highVersionSettings = document.getElementById('high-version-settings');
const cfgHighHistory = document.getElementById('cfg-high-history');
const cfgHighCorrelation = document.getElementById('cfg-high-correlation');
const cfgHighDefense = document.getElementById('cfg-high-defense');
const cfgHighAutoRelax = document.getElementById('cfg-high-auto-relax');
const cfgHighRequiredDays = document.getElementById('cfg-high-required-days');
const cfgHighActiveMinutes = document.getElementById('cfg-high-active-minutes');
const cfgHighWarningFreeDays = document.getElementById('cfg-high-warning-free-days');
const cfgHighCountExisting = document.getElementById('cfg-high-count-existing');
const cfgHighNotifyPlayer = document.getElementById('cfg-high-notify-player');
const highProfileOverrides = document.getElementById('high-profile-overrides');
const HIGH_PROFILE_THRESHOLDS = [
    ['mobKills', 'モブ殺害'], ['itemDrops', 'アイテム投棄'], ['advancements', '進捗獲得'],
    ['liquidPlacements', '液体設置'], ['tntPlacements', 'TNT設置'], ['explodedContainers', 'コンテナ破壊'],
    ['arsonAttempts', '放火'], ['entityGriefing', '額縁等破壊'], ['signPlacements', '看板設置']
];
const HIGH_PROFILE_CATEGORIES = [
    ['MOB_KILL','モブ殺害'], ['ITEM_DROP','アイテム投棄'], ['ADVANCEMENT','進捗'], ['CONTAINER_BREAK','コンテナ'], ['LIQUID_PLACE','液体'], ['TNT_PLACE','TNT'], ['END_CRYSTAL_EXPLODE','エンドクリスタル'], ['ARSON','放火'], ['ENTITY_GRIEF','エンティティ'], ['TAMED_MOB_KILL','ペット殺害'], ['TAMED_MOB_DAMAGE','ペット攻撃'], ['RARE_BLOCK','希少ブロック'], ['SIGN_PLACE','看板'], ['PVP_KILL','PvP'], ['BED_TRAP','ベッド罠']
];

function renderHighProfileOverrides() {
    if (!highProfileOverrides) return;
    if (!highProfileDraft) { highProfileOverrides.innerHTML = ''; return; }
    highProfileOverrides.innerHTML = ['normal', 'relaxed'].map(name => {
        const profile = highProfileDraft[name] || {};
        const thresholds = profile.thresholds || {};
        const categories = profile.categories || {};
        const trust = profile.trust || {};
        const title = name === 'normal' ? '通常プレイヤー' : '緩和プレイヤー';
        return `<section class="high-profile-editor"><h4>${title}<small>このプロフィールだけに保存</small></h4><div class="high-profile-thresholds"><label class="detection-field"><span>1日の最低プレイ</span><input type="number" min="1" max="1440" inputmode="numeric" data-high-profile="${name}" data-high-trust="minimumActiveMinutesPerDay" value="${Number(trust.minimumActiveMinutesPerDay || 1)}"></label><label class="detection-field"><span>緩和までの日数</span><input type="number" min="1" max="365" inputmode="numeric" data-high-profile="${name}" data-high-trust="requiredEligibleDays" value="${Number(trust.requiredEligibleDays || 14)}"></label><label class="detection-field"><span>警告なし日数</span><input type="number" min="0" max="365" inputmode="numeric" data-high-profile="${name}" data-high-trust="warningFreeDays" value="${Number.isInteger(Number(trust.warningFreeDays)) ? Number(trust.warningFreeDays) : 7}"></label>${HIGH_PROFILE_THRESHOLDS.map(([key, label]) => `<label class="detection-field"><span>${label}</span><input type="number" min="1" max="1000000" inputmode="numeric" data-high-profile="${name}" data-high-threshold="${key}" value="${Number(thresholds[key] || 1)}"></label>`).join('')}</div><div class="high-profile-categories">${HIGH_PROFILE_CATEGORIES.map(([key, label]) => `<label><input type="checkbox" data-high-profile="${name}" data-high-category="${key}" ${categories[key] !== false ? 'checked' : ''}><span>${label}</span></label>`).join('')}</div></section>`;
    }).join('');
}

highProfileOverrides?.addEventListener('input', event => {
    const input = event.target;
    const profile = highProfileDraft?.[input.dataset.highProfile];
    if (!profile) return;
    const value = Number(input.value);
    if (input.dataset.highThreshold) {
        if (!Number.isInteger(value) || value < 1 || value > 1000000) return;
        profile.thresholds = { ...(profile.thresholds || {}), [input.dataset.highThreshold]: value };
    } else if (input.dataset.highTrust) {
        const range = input.dataset.highTrust === 'warningFreeDays' ? [0, 365] : input.dataset.highTrust === 'minimumActiveMinutesPerDay' ? [1, 1440] : [1, 365];
        if (!Number.isInteger(value) || value < range[0] || value > range[1]) return;
        profile.trust = { ...(profile.trust || {}), [input.dataset.highTrust]: value };
    }
});
highProfileOverrides?.addEventListener('change', event => {
    const input = event.target;
    const profile = highProfileDraft?.[input.dataset.highProfile];
    if (!profile || !input.dataset.highCategory) return;
    profile.categories = { ...(profile.categories || {}), [input.dataset.highCategory]: Boolean(input.checked) };
});
const highAutoRelaxOptions = document.getElementById('high-auto-relax-options');
const highVersionDependencyNote = document.getElementById('high-version-dependency-note');

function syncHighVersionControls() {
    const historyEnabled = cfgHighHistory.checked;
    cfgHighCorrelation.disabled = !historyEnabled;
    if (!historyEnabled) cfgHighCorrelation.checked = false;
    highVersionDependencyNote.hidden = historyEnabled;
    highAutoRelaxOptions.classList.toggle('is-disabled', !cfgHighAutoRelax.checked);
}
cfgHighHistory.addEventListener('change', syncHighVersionControls);
cfgHighAutoRelax.addEventListener('change', syncHighVersionControls);

function syncNotifyControl(enabledInput, valueInput, valueContainer) {
    const enabled = enabledInput.checked;
    valueInput.disabled = !enabled;
    valueContainer.classList.toggle('is-disabled', !enabled);
    if (enabled && (!Number.isInteger(Number(valueInput.value)) || Number(valueInput.value) < 1)) valueInput.value = '1';
}

function syncNotifyControls() {
    syncNotifyControl(cfgNormalNotifyEnabled, cfgNormalNotify, cfgNormalNotifyValue);
    syncNotifyControl(cfgRelaxedNotifyEnabled, cfgRelaxedNotify, cfgRelaxedNotifyValue);
}

cfgNormalNotifyEnabled.addEventListener('change', syncNotifyControls);
cfgRelaxedNotifyEnabled.addEventListener('change', syncNotifyControls);

const btnSaveConfig = document.getElementById('btn-save-config');
const btnSaveAndRestart = document.getElementById('btn-save-and-restart');
const propertiesForm = document.getElementById('server-properties-form');
const propertiesStatus = document.getElementById('server-properties-status');
const pluginConfigFileSelect = document.getElementById('plugin-config-file-select');
const pluginConfigEditor = document.getElementById('plugin-config-editor');
const btnSavePluginFile = document.getElementById('btn-save-plugin-file');
const pluginStructuredToolbar = document.getElementById('plugin-structured-toolbar');
const pluginStructuredCount = document.getElementById('plugin-structured-count');
const pluginStructuredEditor = document.getElementById('plugin-structured-editor');
const pluginRawEditorPanel = document.getElementById('plugin-raw-editor-panel');
const pluginConfigEditStatus = document.getElementById('plugin-config-edit-status');
const installedPluginList = document.getElementById('installed-plugin-list');
const pluginInventoryStatus = document.getElementById('plugin-inventory-status');
const pluginUploadPanel = document.getElementById('plugin-upload-panel');
const pluginUploadInput = document.getElementById('plugin-upload-input');
const pluginUploadDropzone = document.getElementById('plugin-upload-dropzone');
const pluginUploadStatus = document.getElementById('plugin-upload-status');
let pluginStructuredState = null;
let pluginRawDirty = false;
const cfgTailscaleDns = document.getElementById('cfg-tailscale-dns');
const tailscaleUrlPreview = document.getElementById('tailscale-url-preview');
const btnCopyTailscaleUrl = document.getElementById('btn-copy-tailscale-url');

function tailscaleHttpsUrl() {
    const name = cfgTailscaleDns?.value.trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '');
    return name ? `https://${name}` : '';
}

function updateTailscalePreview() {
    const url = tailscaleHttpsUrl();
    tailscaleUrlPreview.textContent = url || '未設定（ローカルテストは http://localhost:3000）';
    if (btnCopyTailscaleUrl) btnCopyTailscaleUrl.disabled = !url;
}

btnCopyTailscaleUrl?.addEventListener('click', async () => {
    const url = tailscaleHttpsUrl();
    if (!url) { showToast('先にMagicDNS名を入力してください'); return; }
    try {
        if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(url);
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = url;
            textarea.setAttribute('readonly', '');
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            if (!document.execCommand('copy')) throw new Error('copy failed');
            textarea.remove();
        }
        showToast('HTTPS専用URLをコピーしました');
    } catch (_) {
        showToast('コピーできませんでした。URLを長押ししてコピーしてください');
    }
});

async function loadAgentAccessConfig() {
    if (!cfgTailscaleDns || !currentToken) return;
    const response = await fetch('/api/agent/config', { headers: { Authorization: currentToken } });
    if (!response.ok) return;
    const data = await response.json();
    cfgTailscaleDns.value = data.access?.tailscaleDnsName || '';
    updateTailscalePreview();
}

cfgTailscaleDns?.addEventListener('input', updateTailscalePreview);
document.getElementById('btn-save-tailscale')?.addEventListener('click', async () => {
    const name = cfgTailscaleDns.value.trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
    if (name && !/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/i.test(name)) { showToast('MagicDNS名の形式を確認してください'); return; }
    const response = await fetch('/api/agent/config', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken }, body: JSON.stringify({ access: { tailscaleDnsName: name, https: true } }) });
    showToast(response.ok ? 'Tailscale専用URLを保存しました' : '専用URLを保存できませんでした');
    if (response.ok) loadAccessInfo();
});

const passwordChangeForm = document.getElementById('password-change-form');
const securityCurrentPassword = document.getElementById('security-current-password');
const securityChangeCode = document.getElementById('security-change-code');
const securityNewPassword = document.getElementById('security-new-password');
const securityNewPasswordConfirm = document.getElementById('security-new-password-confirm');

document.getElementById('btn-issue-password-code')?.addEventListener('click', async () => {
    if (!securityCurrentPassword.value) { showToast('現在の管理パスワードを入力してください'); securityCurrentPassword.focus(); return; }
    try {
        const response = await fetch('/api/security/password-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: currentToken },
            body: JSON.stringify({ currentPassword: securityCurrentPassword.value })
        });
        const data = await response.json();
        showToast(response.ok ? '確認コードをAgentコンソールへ表示しました' : (data.error || '確認コードを発行できませんでした'));
        if (response.ok) securityChangeCode.focus();
    } catch (_) {
        showToast('Agentへ接続できません');
    }
});

passwordChangeForm?.addEventListener('submit', async event => {
    event.preventDefault();
    if (securityNewPassword.value !== securityNewPasswordConfirm.value) {
        showToast('新しい管理パスワードが一致しません');
        securityNewPasswordConfirm.focus();
        return;
    }
    try {
        const response = await fetch('/api/security/password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: currentToken },
            body: JSON.stringify({
                currentPassword: securityCurrentPassword.value,
                code: securityChangeCode.value.trim().toUpperCase(),
                newPassword: securityNewPassword.value
            })
        });
        const data = await response.json();
        if (!response.ok) { showToast(data.error || '管理パスワードを変更できませんでした'); return; }
        currentToken = data.token;
        localStorage.setItem('gg_token', currentToken);
        passwordChangeForm.reset();
        if (socket) {
            socket.onclose = null;
            socket.close();
            socket = null;
        }
        connectRealServer({});
        showToast('管理パスワードを変更し、ほかの端末をログアウトしました');
    } catch (_) {
        showToast('Agentへ接続できません');
    }
});

async function loadPluginConfigFiles() {
    if (!pluginConfigFileSelect || !currentToken) return;
    try {
        const response = await fetch('/api/plugin-config-files', { headers: { Authorization: currentToken } });
        if (!response.ok) return;
        const data = await response.json();
        const selected = pluginConfigFileSelect.value;
        pluginConfigFileSelect.innerHTML = '<option value="">ファイルを選択</option>';
        data.files.forEach(file => {
            const option = document.createElement('option'); option.value = file; option.textContent = file; pluginConfigFileSelect.appendChild(option);
        });
        if (data.files.includes(selected)) pluginConfigFileSelect.value = selected;
    } catch (_) {}
}

function splitYamlScalar(rawValue) {
    let quote = '';
    for (let index = 0; index < rawValue.length; index++) {
        const char = rawValue[index];
        if ((char === '"' || char === "'") && rawValue[index - 1] !== '\\') quote = quote === char ? '' : (quote || char);
        if (char === '#' && !quote && (index === 0 || /\s/.test(rawValue[index - 1]))) {
            return { value: rawValue.slice(0, index).trim(), comment: rawValue.slice(index).trim() };
        }
    }
    return { value: rawValue.trim(), comment: '' };
}

function parseEditableValue(rawValue) {
    const trimmed = String(rawValue || '').trim();
    const quote = (trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")) ? trimmed[0] : '';
    const unquoted = quote ? trimmed.slice(1, -1) : trimmed;
    if (/^(true|false)$/i.test(unquoted)) return { type: 'boolean', value: unquoted.toLowerCase() === 'true', quote: '' };
    if (/^-?(?:\d+\.?\d*|\.\d+)$/.test(unquoted)) return { type: 'number', value: Number(unquoted), quote: '' };
    return { type: 'string', value: unquoted.replace(/\\n/g, '\n'), quote };
}

function parseYamlEditor(content) {
    const lines = content.split(/\r?\n/);
    const fields = [];
    const stack = [];
    for (let index = 0; index < lines.length; index++) {
        const match = lines[index].match(/^(\s*)([^#][^:]*?):(?:\s*(.*))?$/);
        if (!match) continue;
        const indent = match[1].length;
        const key = match[2].trim();
        if (!key) continue;
        while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
        const path = [...stack.map(item => item.key), key];
        const raw = match[3] ?? '';
        const split = splitYamlScalar(raw);
        if (!split.value) {
            let cursor = index + 1;
            while (cursor < lines.length && /^\s*(?:#.*)?$/.test(lines[cursor])) cursor++;
            const firstItem = lines[cursor]?.match(/^(\s*)-\s*(.*)$/);
            if (firstItem && firstItem[1].length > indent) {
                const items = [];
                let end = cursor - 1;
                let itemQuote = '';
                for (; cursor < lines.length; cursor++) {
                    const itemMatch = lines[cursor].match(/^(\s*)-\s*(.*)$/);
                    if (!itemMatch || itemMatch[1].length <= indent) break;
                    const parsed = parseEditableValue(splitYamlScalar(itemMatch[2]).value);
                    if (!itemQuote) itemQuote = parsed.quote;
                    items.push(String(parsed.value));
                    end = cursor;
                }
                fields.push({ format: 'yaml', type: 'list', key, path, start: index, end, indent, itemIndent: firstItem[1], value: items, quote: itemQuote, comment: split.comment });
                index = end;
            } else {
                stack.push({ indent, key });
            }
            continue;
        }
        const parsed = parseEditableValue(split.value);
        let help = '';
        for (let cursor = index - 1; cursor >= 0; cursor--) {
            const comment = lines[cursor].match(/^\s*#\s?(.*)$/);
            if (comment) { help = `${comment[1]} ${help}`.trim(); continue; }
            if (!lines[cursor].trim()) continue;
            break;
        }
        fields.push({ format: 'yaml', ...parsed, key, path, start: index, end: index, indent, comment: split.comment, help });
    }
    return { format: 'yaml', lines, fields };
}

function flattenJsonEditor(value, path = [], fields = []) {
    if (Array.isArray(value)) {
        fields.push({ format: 'json', type: 'list', key: path.at(-1) || 'items', path, value: value.map(item => String(item)) });
    } else if (value && typeof value === 'object') {
        Object.entries(value).forEach(([key, child]) => flattenJsonEditor(child, [...path, key], fields));
    } else {
        fields.push({ format: 'json', type: typeof value === 'boolean' ? 'boolean' : (typeof value === 'number' ? 'number' : 'string'), key: path.at(-1) || 'value', path, value });
    }
    return fields;
}

function setJsonPath(root, path, value) {
    let target = root;
    for (let index = 0; index < path.length - 1; index++) target = target[path[index]];
    target[path.at(-1)] = value;
}

function formatYamlString(value, quote = '') {
    const text = String(value ?? '').replace(/\n/g, '\\n');
    if (quote === "'") return `'${text.replace(/'/g, "''")}'`;
    if (quote === '"' || !text || /[:#\[\]{},&*!|>'"%@`]|^[-?]\s/.test(text)) return JSON.stringify(text);
    return text;
}

function serializePluginStructuredState() {
    if (!pluginStructuredState) return pluginConfigEditor.value;
    if (pluginStructuredState.format === 'json') {
        pluginStructuredState.fields.forEach(field => setJsonPath(pluginStructuredState.data, field.path, field.type === 'list' ? field.value : field.value));
        return JSON.stringify(pluginStructuredState.data, null, 2) + '\n';
    }
    const lines = [...pluginStructuredState.lines];
    [...pluginStructuredState.fields].sort((left, right) => right.start - left.start).forEach(field => {
        const indent = ' '.repeat(field.indent);
        if (field.type === 'list') {
            const replacement = [`${indent}${field.key}:`];
            field.value.forEach(item => replacement.push(`${field.itemIndent}- ${formatYamlString(item, field.quote)}`));
            lines.splice(field.start, field.end - field.start + 1, ...replacement);
            return;
        }
        const value = field.type === 'boolean' ? String(field.value) : (field.type === 'number' ? String(field.value) : formatYamlString(field.value, field.quote));
        lines[field.start] = `${indent}${field.key}: ${value}${field.comment ? ` ${field.comment}` : ''}`;
    });
    return lines.join('\n');
}

function syncStructuredPluginContent() {
    pluginRawDirty = false;
    pluginConfigEditor.value = serializePluginStructuredState();
    pluginConfigEditStatus.textContent = '変更内容はまだ保存されていません';
    pluginConfigEditStatus.classList.add('changed');
}

function fieldGroupName(field) {
    if (field.path.length <= 1) return '基本設定';
    if (field.path[0] === 'recipes' && field.path.length >= 3) return `レシピ: ${field.path[1]}`;
    return field.path.slice(0, -1).join(' › ');
}

function structuredFieldLabel(key) {
    return ({
        'plugin-enabled': 'プラグイン全体', 'join-message-enabled': '参加メッセージ',
        'join-message': '参加時の文章', 'limit-message': '制限時の文章',
        enabled: '有効', 'max-blocks': '最大ブロック数', 'reset-seconds': 'リセット時間（秒）',
        'experience-per-ore': '鉱石経験値', 'affected-materials': '対象ブロック',
        type: 'レシピ形式', shape: '配置パターン', material: 'アイテム', amount: '個数',
        'display-name': '表示名', ingredients: '材料'
    })[key] || key;
}

function createStructuredField(field) {
    const row = document.createElement('label');
    row.className = `plugin-structured-field field-${field.type}`;
    const copy = document.createElement('span');
    copy.className = 'plugin-structured-copy';
    const title = document.createElement('strong');
    title.textContent = structuredFieldLabel(field.key);
    const path = document.createElement('small');
    path.textContent = field.path.join('.');
    copy.append(title, path);
    if (field.help) {
        const help = document.createElement('small');
        help.className = 'plugin-structured-help';
        help.textContent = field.help;
        copy.appendChild(help);
    }
    row.appendChild(copy);
    let input;
    if (field.type === 'boolean') {
        const switchLabel = document.createElement('span');
        switchLabel.className = 'switch';
        input = document.createElement('input');
        input.type = 'checkbox';
        input.checked = Boolean(field.value);
        const slider = document.createElement('span');
        slider.className = 'slider round';
        switchLabel.append(input, slider);
        row.appendChild(switchLabel);
        input.addEventListener('change', () => { field.value = input.checked; syncStructuredPluginContent(); });
        return row;
    }
    if (field.type === 'list' || (field.type === 'string' && String(field.value).length > 90)) {
        input = document.createElement('textarea');
        input.rows = field.type === 'list' ? Math.min(8, Math.max(3, field.value.length)) : 3;
        input.value = field.type === 'list' ? field.value.join('\n') : field.value;
    } else {
        input = document.createElement('input');
        input.type = field.type === 'number' ? 'number' : 'text';
        if (field.type === 'number') input.step = 'any';
        input.value = field.value ?? '';
    }
    row.appendChild(input);
    input.addEventListener('input', () => {
        field.value = field.type === 'list' ? input.value.split(/\r?\n/).filter(value => value.length > 0) : (field.type === 'number' ? Number(input.value) : input.value);
        syncStructuredPluginContent();
    });
    return row;
}

function renderPluginStructuredEditor(file, content) {
    pluginStructuredEditor.innerHTML = '';
    pluginStructuredToolbar.classList.add('hide');
    pluginRawEditorPanel.open = false;
    pluginRawDirty = false;
    try {
        if (/\.json$/i.test(file)) {
            const data = JSON.parse(content);
            pluginStructuredState = { format: 'json', data, fields: flattenJsonEditor(data) };
        } else if (/\.ya?ml$/i.test(file)) {
            pluginStructuredState = parseYamlEditor(content);
        } else {
            pluginStructuredState = null;
        }
    } catch (error) {
        pluginStructuredState = null;
        pluginConfigEditStatus.textContent = `かんたん編集を作成できません: ${error.message}`;
    }
    if (!pluginStructuredState || !pluginStructuredState.fields.length) {
        pluginRawEditorPanel.open = true;
        pluginConfigEditStatus.textContent = 'この形式は直接編集モードで編集できます';
        return;
    }
    const groups = new Map();
    pluginStructuredState.fields.forEach(field => {
        const group = fieldGroupName(field);
        if (!groups.has(group)) groups.set(group, []);
        groups.get(group).push(field);
    });
    groups.forEach((fields, name) => {
        const section = document.createElement('details');
        section.className = 'plugin-structured-group';
        section.open = pluginStructuredEditor.children.length === 0;
        const summary = document.createElement('summary');
        summary.innerHTML = `<span>${name}</span><small>${fields.length}項目</small>`;
        summary.addEventListener('click', event => {
            event.preventDefault();
            section.open = !section.open;
        });
        const body = document.createElement('div');
        body.className = 'plugin-structured-fields';
        fields.forEach(field => body.appendChild(createStructuredField(field)));
        section.append(summary, body);
        pluginStructuredEditor.appendChild(section);
    });
    pluginStructuredCount.textContent = `${pluginStructuredState.fields.length}項目`;
    pluginStructuredToolbar.classList.remove('hide');
    pluginConfigEditStatus.textContent = '項目を変更して「このファイルを保存」を押してください';
}

async function openPluginConfigFile(file) {
    if (!file) return;
    if (![...pluginConfigFileSelect.options].some(option => option.value === file)) await loadPluginConfigFiles();
    pluginConfigFileSelect.value = file;
    pluginConfigFileSelect.dispatchEvent(new Event('change'));
    const editorCard = document.getElementById('plugin-config-editor-card');
    const trigger = editorCard?.querySelector('.plugin-accordion-trigger');
    const content = editorCard?.querySelector('.plugin-accordion-content');
    if (trigger && content) setAccordionState(trigger, content, true);
    if (editorCard) {
        requestAnimationFrame(() => {
            const settingsPane = document.getElementById('tab-settings');
            if (settingsPane) {
                const paneRect = settingsPane.getBoundingClientRect();
                const editorRect = editorCard.getBoundingClientRect();
                settingsPane.scrollTop += editorRect.top - paneRect.top - 8;
            }
            resetRootScroll();
        });
    }
}

function createInstalledPluginCard(plugin) {
    const card = document.createElement('article');
    card.className = 'installed-plugin-card glass';

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'installed-plugin-trigger';
    trigger.setAttribute('aria-expanded', 'false');

    const icon = document.createElement('span');
    icon.className = 'installed-plugin-icon';
    icon.textContent = plugin.source === 'jar' ? '🧩' : '⚙️';
    const copy = document.createElement('span');
    copy.className = 'installed-plugin-copy';
    const name = document.createElement('strong');
    name.textContent = plugin.name;
    const meta = document.createElement('small');
    meta.textContent = [plugin.version ? `v${plugin.version}` : '', plugin.apiVersion ? `API ${plugin.apiVersion}` : '', plugin.jar || '設定フォルダー'].filter(Boolean).join(' • ');
    copy.append(name, meta);
    const badge = document.createElement('span');
    badge.className = `plugin-recognition-badge ${plugin.configFiles.length ? 'recognized' : 'jar-only'}`;
    badge.textContent = plugin.configFiles.length ? `設定 ${plugin.configFiles.length}` : 'JAR検出';
    const chevron = document.createElement('span');
    chevron.className = 'accordion-chevron';
    chevron.textContent = '⌄';
    trigger.append(icon, copy, badge, chevron);

    const content = document.createElement('div');
    content.className = 'installed-plugin-content';
    content.hidden = true;
    const description = document.createElement('p');
    description.textContent = plugin.description || '説明はplugin.ymlに登録されていません。';
    content.appendChild(description);

    if (plugin.configFiles.length) {
        const fileList = document.createElement('div');
        fileList.className = 'installed-plugin-files';
        plugin.configFiles.forEach(file => {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = file.split('/').pop();
            button.title = file;
            button.addEventListener('click', () => openPluginConfigFile(file));
            fileList.appendChild(button);
        });
        content.appendChild(fileList);
    } else {
        const notice = document.createElement('small');
        notice.className = 'installed-plugin-notice';
        notice.textContent = 'JARは認識済みですが、編集可能な設定ファイルはまだ生成されていません。サーバーを一度起動すると作成される場合があります。';
        content.appendChild(notice);
    }

    trigger.addEventListener('click', () => {
        const expanded = trigger.getAttribute('aria-expanded') === 'true';
        trigger.setAttribute('aria-expanded', String(!expanded));
        content.hidden = expanded;
        card.classList.toggle('expanded', !expanded);
    });
    card.append(trigger, content);
    return card;
}

async function loadInstalledPlugins() {
    if (!installedPluginList || !currentToken) return;
    pluginInventoryStatus.textContent = 'pluginsフォルダーを確認中…';
    try {
        const response = await fetch('/api/plugins', { headers: { Authorization: currentToken } });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || '導入プラグインを確認できませんでした');
        const griefGuard = data.plugins.find(plugin => plugin.specialized);
        const griefMeta = document.getElementById('griefguard-plugin-meta');
        const griefStatus = document.getElementById('griefguard-recognition-status');
        if (griefGuard) {
            griefMeta.textContent = [`v${griefGuard.version || '?'}`, '専用UI', `${griefGuard.configFiles.length}設定ファイル`].join(' • ');
            griefStatus.textContent = '認識済み';
            griefStatus.classList.add('recognized');
        } else {
            griefMeta.textContent = 'JARを確認できません';
            griefStatus.textContent = '未検出';
            griefStatus.classList.remove('recognized');
        }
        const others = data.plugins.filter(plugin => !plugin.specialized);
        installedPluginList.innerHTML = '';
        if (others.length) others.forEach(plugin => installedPluginList.appendChild(createInstalledPluginCard(plugin)));
        else {
            const empty = document.createElement('div');
            empty.className = 'installed-plugin-empty';
            empty.textContent = 'GriefGuard以外のプラグインは検出されていません。';
            installedPluginList.appendChild(empty);
        }
        pluginInventoryStatus.textContent = `${data.count}個を認識 • ${data.editableCount}個に編集可能な設定あり`;
    } catch (error) {
        pluginInventoryStatus.textContent = error.message;
        installedPluginList.innerHTML = '<div class="installed-plugin-empty error">pluginsフォルダーを読み取れませんでした。</div>';
    }
}

function setPluginUploadStatus(message, state = '') {
    if (!pluginUploadStatus) return;
    pluginUploadStatus.textContent = message;
    pluginUploadStatus.className = `plugin-upload-status ${state}`.trim();
}

async function uploadPluginJar(file) {
    if (!file) return;
    if (!/\.jar$/i.test(file.name)) {
        setPluginUploadStatus('JARファイル（.jar）のみ追加できます。', 'error');
        return;
    }
    if (file.size <= 0 || file.size > 50 * 1024 * 1024) {
        setPluginUploadStatus('プラグインJARは1B〜50MBにしてください。', 'error');
        return;
    }
    if (!currentToken) {
        returnToLoginForExpiredSession();
        return;
    }
    pluginUploadDropzone.disabled = true;
    setPluginUploadStatus(`「${file.name}」を検証して追加しています…`);
    try {
        const response = await fetch(`/api/plugins/upload?filename=${encodeURIComponent(file.name)}`, {
            method: 'POST',
            headers: { 'Authorization': currentToken, 'Content-Type': 'application/java-archive' },
            body: await file.arrayBuffer()
        });
        const data = await response.json().catch(() => ({}));
        if (response.status === 401 || response.status === 403) {
            returnToLoginForExpiredSession();
            throw new Error('認証が無効です。再ログインしてください。');
        }
        if (!response.ok) throw new Error(data.error || 'プラグインを追加できませんでした。');
        setPluginUploadStatus(`追加しました: ${data.plugin.name || data.file}。Paperを再起動すると有効になります。`, 'success');
        showToast('プラグインを追加しました。再起動後に有効になります。');
        await loadInstalledPlugins();
    } catch (error) {
        setPluginUploadStatus(error.message || 'プラグインを追加できませんでした。', 'error');
    } finally {
        pluginUploadDropzone.disabled = false;
        pluginUploadInput.value = '';
    }
}

pluginUploadDropzone?.addEventListener('click', () => pluginUploadInput?.click());
pluginUploadInput?.addEventListener('change', () => uploadPluginJar(pluginUploadInput.files?.[0]));
pluginUploadDropzone?.addEventListener('dragover', event => {
    event.preventDefault();
    pluginUploadDropzone.classList.add('dragging');
});
pluginUploadDropzone?.addEventListener('dragleave', () => pluginUploadDropzone.classList.remove('dragging'));
pluginUploadDropzone?.addEventListener('drop', event => {
    event.preventDefault();
    pluginUploadDropzone.classList.remove('dragging');
    uploadPluginJar(event.dataTransfer?.files?.[0]);
});

pluginConfigFileSelect?.addEventListener('change', async () => {
    const file = pluginConfigFileSelect.value;
    pluginConfigEditor.value = '';
    pluginStructuredEditor.innerHTML = '';
    pluginStructuredToolbar.classList.add('hide');
    pluginStructuredState = null;
    pluginRawDirty = false;
    pluginConfigEditor.disabled = !file;
    btnSavePluginFile.disabled = !file;
    pluginConfigEditStatus.textContent = file ? '設定を読み込んでいます…' : '設定ファイルを選択してください';
    if (!file) return;
    const response = await fetch(`/api/plugin-config-file?path=${encodeURIComponent(file)}`, { headers: { Authorization: currentToken } });
    const data = await response.json();
    if (!response.ok) { showToast(data.error || '設定ファイルを読み込めませんでした'); return; }
    pluginConfigEditor.value = data.content;
    renderPluginStructuredEditor(file, data.content);
});

pluginConfigEditor?.addEventListener('input', () => {
    pluginRawDirty = true;
    pluginConfigEditStatus.textContent = '直接編集した内容はまだ保存されていません';
    pluginConfigEditStatus.classList.add('changed');
});

btnSavePluginFile?.addEventListener('click', async () => {
    if (!pluginRawDirty && pluginStructuredState) pluginConfigEditor.value = serializePluginStructuredState();
    const response = await fetch('/api/plugin-config-file', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken }, body: JSON.stringify({ path: pluginConfigFileSelect.value, content: pluginConfigEditor.value }) });
    const data = await response.json();
    if (response.ok) {
        pluginRawDirty = false;
        pluginConfigEditStatus.classList.remove('changed');
        pluginConfigEditStatus.textContent = '保存しました。プラグインの再読み込みまたはサーバー再起動後に反映されます';
        showToast(`${data.backup} を作成して保存しました`);
    } else {
        showToast(data.error || '保存できませんでした');
    }
});

function setAccordionState(trigger, content, expanded) {
    trigger.setAttribute('aria-expanded', String(expanded));
    content.hidden = !expanded;
    const accordion = trigger.closest('.property-card, [data-plugin-card], .plugin-profile-card');
    if (accordion) accordion.classList.toggle('expanded', expanded);
    const status = trigger.querySelector('.plugin-profile-status');
    if (status) status.textContent = expanded ? '設定を閉じる' : '設定を見る';
}

function initializePluginGroup() {
    const profile = document.querySelector('.plugin-profile-card');
    const trigger = document.getElementById('btn-toggle-griefguard');
    const cards = Array.from(document.querySelectorAll('[data-griefguard-card]'));
    if (!profile || !trigger || cards.length === 0 || document.getElementById('griefguard-settings-groups')) return;

    const container = document.createElement('div');
    container.id = 'griefguard-settings-groups';
    container.className = 'plugin-settings-groups';
    profile.insertAdjacentElement('afterend', container);
    const overview = document.createElement('div');
    overview.className = 'griefguard-ui-overview';
    overview.innerHTML = '<strong>GriefGuard設定</strong><span>① 保護アクション</span><span>② 検知ルール</span><span>③ Discord連携</span><small>ここではGriefGuardだけを保存できます。サーバー再起動は設定画面の一番下から実行します。</small>';
    container.appendChild(overview);
    cards.forEach(card => container.appendChild(card));
    const actions = document.createElement('div');
    actions.className = 'griefguard-save-actions';
    actions.innerHTML = '<button type="button" class="btn-secondary-save" id="btn-save-griefguard-only">GriefGuard設定を保存</button><small>再起動せず、GriefGuardのconfig.ymlへ保存します</small>';
    actions.querySelector('#btn-save-griefguard-only').addEventListener('click', saveGriefGuardSettings);
    container.appendChild(actions);
    trigger.addEventListener('click', () => setAccordionState(trigger, container, trigger.getAttribute('aria-expanded') !== 'true'));
    setAccordionState(trigger, container, false);
}

function initializePluginAccordions() {
    document.querySelectorAll('[data-plugin-card]').forEach((card, index) => {
        if (card.dataset.accordionReady === 'true') return;
        const oldHeader = card.querySelector('.card-header');
        const title = oldHeader?.querySelector('h3')?.textContent || 'プラグイン設定';
        const body = document.createElement('div');
        body.className = 'accordion-content plugin-accordion-content';
        Array.from(card.children).forEach(child => {
            if (child !== oldHeader) body.appendChild(child);
        });

        const trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'accordion-trigger plugin-accordion-trigger';
        trigger.innerHTML = `
            <span class="accordion-icon">${card.dataset.icon}</span>
            <span class="accordion-label"><strong>${title}</strong><small>${card.dataset.summary}</small></span>
            <span class="accordion-chevron">⌄</span>`;
        oldHeader.replaceWith(trigger);
        card.appendChild(body);
        trigger.addEventListener('click', () => setAccordionState(trigger, body, trigger.getAttribute('aria-expanded') !== 'true'));
        setAccordionState(trigger, body, false);
        card.dataset.accordionReady = 'true';
    });
}

initializePluginGroup();
initializePluginAccordions();

function initializeStaticSettingInfo() {
    document.querySelectorAll('[data-setting-info]').forEach(label => {
        if (label.dataset.infoReady === 'true') return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'property-info-button inline-setting-info';
        button.textContent = 'i';
        button.setAttribute('aria-label', `${label.textContent.trim()}の注意事項を表示`);
        button.setAttribute('aria-expanded', 'false');
        const note = document.createElement('small');
        note.className = 'property-info-note inline-setting-note';
        note.textContent = label.dataset.settingInfo;
        note.hidden = true;
        button.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            const expanded = button.getAttribute('aria-expanded') === 'true';
            button.setAttribute('aria-expanded', String(!expanded));
            button.classList.toggle('active', !expanded);
            note.hidden = expanded;
        });
        label.appendChild(button);
        label.insertAdjacentElement('afterend', note);
        label.dataset.infoReady = 'true';
    });
}

initializeStaticSettingInfo();

cfgMaxWarnings.addEventListener('input', () => {
    cfgMaxWarningsVal.textContent = cfgMaxWarnings.value;
    cfgNormalMaxWarnings.value = cfgMaxWarnings.value;
});

const GRIEFGUARD_DEFAULT_CONFIG = Object.freeze({
    autoBan: true,
    autoRollback: true,
    backupStorageLocation: 'server-root',
    backupCustomDirectory: 'Backups',
    backupWorldCount: 3,
    backupRetentionLimit: 20,
    profiles: { normal: { timeWindowMinutes: 15, maxWarnings: 5, notifyAt: 0, markAtWarnings: 2, fastBanWarningsPerMinute: 3 }, relaxed: { timeWindowMinutes: 5, maxWarnings: 9, notifyAt: 7, markAtWarnings: 4, fastBanWarningsPerMinute: 4 } },
    fastBan: { enabled: false, windowSeconds: 60, requirePotentialDanger: true },
    banReason: "Suspicious behavior detected (Anti-Grief). If this is a mistake, contact the administrator.",
    discordEnabled: false,
    discordToken: "",
    discordFeatures: {},
    discordBridgeMode: false,
    discordVpsIp: "10.8.0.1",
    discordBridgePort: 25501,
    discordWindowsIp: "10.8.0.2",
    discordLauncherPort: 25500,
    discordProxyPort: 25565,
    discordMinecraftPort: 25565,
    discordRestartScript: "start.bat",
    thresholds: { mobKills: 10, itemDrops: 64, advancements: 5, liquidPlacements: 5, tntPlacements: 5, explodedContainers: 8, arsonAttempts: 10, entityGriefing: 10, signPlacements: 10, playerKills: 1, tamedMobKills: 1, tamedMobDamage: 1, endCrystalExplosions: 1, rareBlockBreaks: 1, bedTraps: 1 },
    categories: {}, ddosLimit: 5, rateLimitEnabled: true
});

document.getElementById('btn-reset-griefguard').addEventListener('click', () => {
    bindConfigUi(GRIEFGUARD_DEFAULT_CONFIG);
    showToast('標準値を入力しました。保存するまで反映されません');
});

let propertiesSchema = [];
let whitelistEntries = [];
let worldExists = false;

function createWhitelistManager(whitelistToggle) {
    const panel = document.createElement('section');
    panel.className = 'whitelist-manager';
    panel.innerHTML = `
        <div class="whitelist-manager-heading">
            <div><strong>参加を許可するプレイヤー</strong><small>プレイヤー名を登録すると、その人だけ参加できます</small></div>
            <span id="whitelist-player-count" class="whitelist-count"></span>
        </div>
        <div class="whitelist-disabled-guide">先に上の「ホワイトリスト」をONにしてください</div>
        <form id="whitelist-add-form" class="whitelist-add-form">
            <input id="whitelist-player-input" type="text" maxlength="17" placeholder="例: Steve / .BedrockPlayer" autocomplete="off">
            <button type="submit">追加</button>
        </form>
        <details class="whitelist-candidates" id="whitelist-candidates">
            <summary>過去の参加プレイヤーから選ぶ</summary>
            <small>ホワイトリスト未登録の参加履歴を表示します。複数選択できます。</small>
            <div id="whitelist-candidate-list" class="whitelist-candidate-list">読み込み中…</div>
            <button type="button" id="whitelist-add-selected" class="whitelist-add-selected">選択したプレイヤーを追加</button>
        </details>
        <div class="whitelist-search-row">
            <input id="whitelist-search" type="search" placeholder="登録済みプレイヤーを検索" autocomplete="off">
        </div>
        <div id="whitelist-player-list" class="whitelist-player-list"></div>`;

    const addForm = panel.querySelector('#whitelist-add-form');
    const playerInput = panel.querySelector('#whitelist-player-input');
    const searchInput = panel.querySelector('#whitelist-search');
    const list = panel.querySelector('#whitelist-player-list');
    const count = panel.querySelector('#whitelist-player-count');
    const candidatesDetails = panel.querySelector('#whitelist-candidates');
    const candidatesList = panel.querySelector('#whitelist-candidate-list');
    const addSelected = panel.querySelector('#whitelist-add-selected');
    let candidates = [];

    function renderWhitelist() {
        const query = searchInput.value.trim().toLowerCase();
        const filtered = whitelistEntries.filter(name => name.toLowerCase().includes(query));
        list.innerHTML = '';
        count.textContent = `${whitelistEntries.length}人`;
        if (filtered.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'whitelist-empty';
            empty.textContent = query ? '一致するプレイヤーはいません' : '許可プレイヤーが登録されていません';
            list.appendChild(empty);
            return;
        }
        filtered.forEach(name => {
            const item = document.createElement('div');
            item.className = 'whitelist-player';
            const playerName = document.createElement('span');
            playerName.innerHTML = `<span class="player-head">👤</span><strong></strong>`;
            playerName.querySelector('strong').textContent = name;
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'whitelist-remove';
            remove.textContent = '削除';
            remove.setAttribute('aria-label', `${name}をホワイトリストから削除`);
            remove.addEventListener('click', async () => {
                const response = await fetch(`/api/whitelist/${encodeURIComponent(name)}`, { method: 'DELETE', headers: { Authorization: currentToken } });
                const data = await response.json().catch(() => ({}));
                if (!response.ok) { showToast(data.error || '削除に失敗しました'); return; }
                whitelistEntries = whitelistEntries.filter(player => player !== name);
                renderWhitelist();
                showToast(`${name} を許可リストから削除しました`);
            });
            item.append(playerName, remove);
            list.appendChild(item);
        });
    }

    function syncEnabledState() {
        const enabled = whitelistToggle.checked;
        panel.classList.toggle('disabled', !enabled);
        playerInput.disabled = !enabled;
        searchInput.disabled = !enabled;
        addForm.querySelector('button').disabled = !enabled;
        candidatesDetails.open = enabled && candidatesDetails.open;
        addSelected.disabled = !enabled;
    }

    function renderCandidates() {
        candidatesList.innerHTML = '';
        if (!candidates.length) { candidatesList.textContent = '追加できる参加履歴はありません'; return; }
        candidates.forEach(player => {
            const label = document.createElement('label');
            label.className = 'whitelist-candidate';
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox'; checkbox.value = player.name;
            const text = document.createElement('span');
            text.textContent = `${player.name}（ログイン ${player.loginCount || 0}回）`;
            label.append(checkbox, text); candidatesList.appendChild(label);
        });
    }

    async function loadCandidates() {
        try {
            const response = await fetch('/api/whitelist/candidates', { headers: { Authorization: currentToken } });
            candidates = response.ok ? await response.json() : [];
        } catch (_) { candidates = []; }
        renderCandidates();
    }

    addForm.addEventListener('submit', async event => {
        event.preventDefault();
        const name = playerInput.value.trim();
        if (!/^\.?[A-Za-z0-9_]{3,16}$/.test(name)) {
            showToast('英数字・_、または統合版用の先頭「.」を使用できます');
            return;
        }
        if (whitelistEntries.some(player => player.toLowerCase() === name.toLowerCase())) {
            showToast('そのプレイヤーは登録済みです');
            return;
        }
        const response = await fetch('/api/whitelist', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken }, body: JSON.stringify({ name }) });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) { showToast(data.error || '追加に失敗しました'); return; }
        whitelistEntries.push(name);
        playerInput.value = '';
        searchInput.value = '';
        renderWhitelist();
        loadCandidates();
        showToast(`${name} の参加を許可しました`);
    });
    searchInput.addEventListener('input', renderWhitelist);
    candidatesDetails.addEventListener('toggle', () => { if (candidatesDetails.open) loadCandidates(); });
    addSelected.addEventListener('click', async () => {
        const names = [...candidatesList.querySelectorAll('input:checked')].map(input => input.value);
        if (!names.length) { showToast('追加するプレイヤーを選択してください'); return; }
        addSelected.disabled = true;
        try {
            const response = await fetch('/api/whitelist/bulk', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken }, body: JSON.stringify({ names }) });
            const data = await response.json().catch(() => ({}));
            const added = (data.results || []).filter(result => result.ok).map(result => result.name);
            if (!response.ok || !added.length) throw new Error(data.error || '追加に失敗しました');
            whitelistEntries.push(...added.filter(name => !whitelistEntries.some(current => current.toLowerCase() === name.toLowerCase())));
            renderWhitelist(); loadCandidates(); showToast(`${added.length}人の参加を許可しました`);
        } catch (error) { showToast(error.message); }
        finally { addSelected.disabled = !whitelistToggle.checked; }
    });
    whitelistToggle.addEventListener('change', syncEnabledState);
    renderWhitelist();
    syncEnabledState();
    fetch('/api/whitelist', { headers: { Authorization: currentToken } })
        .then(response => response.ok ? response.json() : [])
        .then(players => { whitelistEntries = players; renderWhitelist(); })
        .catch(() => {});
    return panel;
}

async function loadConfig() {
    try {
        const response = await fetch('/api/config', {
            headers: { 'Authorization': currentToken }
        });
        if (response.ok) {
            const config = await response.json();
            bindConfigUi(config);
        } else {
            showToast("設定ファイルの読み込みに失敗しました。");
        }
    } catch (e) {
        console.error("Failed to load config.yml details:", e);
        showToast("通信エラーが発生しました。");
    }
}

function bindConfigUi(config) {
    cfgAutoBan.checked = config.autoBan;
    cfgAutoRollback.checked = config.autoRollback;
    cfgBackupStorage.value = config.backupStorageLocation || 'server-root';
    cfgBackupCustomDirectory.value = config.backupCustomDirectory || 'Backups';
    cfgBackupCustomRow.hidden = cfgBackupStorage.value !== 'custom';
    const worldCount = Number(config.backupWorldCount || 0);
    const limit = Number(config.backupRetentionLimit || 20);
    cfgBackupRetentionSummary.textContent = worldCount > 0
        ? `${worldCount}ワールド → 各${limit}世代`
        : `検出後に自動決定（最大${limit}世代）`;
    const normal = config.profiles?.normal || GRIEFGUARD_DEFAULT_CONFIG.profiles.normal;
    const relaxed = config.profiles?.relaxed || GRIEFGUARD_DEFAULT_CONFIG.profiles.relaxed;
    cfgMaxWarnings.value = normal.maxWarnings;
    cfgMaxWarningsVal.textContent = normal.maxWarnings;
    cfgNormalWindow.value = normal.timeWindowMinutes;
    cfgNormalMaxWarnings.value = normal.maxWarnings;
    cfgRelaxedWindow.value = relaxed.timeWindowMinutes;
    cfgRelaxedMaxWarnings.value = relaxed.maxWarnings;
    cfgNormalNotifyEnabled.checked = Number(normal.notifyAt) > 0;
    cfgNormalNotify.value = Number(normal.notifyAt) > 0 ? normal.notifyAt : 1;
    cfgNormalMark.value = normal.markAtWarnings;
    cfgRelaxedNotifyEnabled.checked = Number(relaxed.notifyAt) > 0;
    cfgRelaxedNotify.value = Number(relaxed.notifyAt) > 0 ? relaxed.notifyAt : 1;
    cfgRelaxedMark.value = relaxed.markAtWarnings;
    cfgNormalFastBan.value = normal.fastBanWarningsPerMinute;
    cfgRelaxedFastBan.value = relaxed.fastBanWarningsPerMinute;
    cfgFastBanEnabled.checked = Boolean(config.fastBan?.enabled);
    cfgFastBanWindow.value = config.fastBan?.windowSeconds || 60;
    cfgFastBanRequireMark.checked = config.fastBan?.requirePotentialDanger !== false;
    const high = config.highVersion || {};
    highProfileDraft = high.playerProfiles ? JSON.parse(JSON.stringify(high.playerProfiles)) : null;
    renderHighProfileOverrides();
    highVersionSettings.hidden = !high.available;
    cfgHighHistory.checked = high.connectionHistory !== false;
    cfgHighCorrelation.checked = Boolean(high.accountCorrelation);
    cfgHighDefense.checked = high.connectionDefense !== false;
    cfgHighAutoRelax.checked = Boolean(high.autoRelaxation);
    cfgHighRequiredDays.value = high.requiredEligibleDays || 14;
    cfgHighActiveMinutes.value = high.minimumActiveMinutesPerDay || 30;
    cfgHighWarningFreeDays.value = Number.isInteger(Number(high.warningFreeDays)) ? high.warningFreeDays : 7;
    cfgHighCountExisting.checked = Boolean(high.countExistingHistory);
    cfgHighNotifyPlayer.checked = high.notifyPlayer !== false;
    syncHighVersionControls();
    syncNotifyControls();
    cfgMobKills.value = config.thresholds?.mobKills || 10;
    cfgTntPlacements.value = config.thresholds?.tntPlacements || 5;
    cfgLiquidPlacements.value = config.thresholds?.liquidPlacements || 5;
    cfgDdosLimit.value = config.ddosLimit || 5;
    cfgBanReason.value = config.banReason || "";
    cfgDiscordEnabled.checked = config.discordEnabled;
    cfgDiscordToken.value = '';
    cfgDiscordToken.dataset.configured = String(Boolean(config.discordTokenConfigured));
    cfgDiscordBridgeMode.checked = Boolean(config.discordBridgeMode);
    cfgDiscordVpsIp.value = config.discordVpsIp || "10.8.0.1";
    cfgDiscordBridgePort.value = config.discordBridgePort || 25501;
    cfgDiscordWindowsIp.value = config.discordWindowsIp || "10.8.0.2";
    cfgDiscordLauncherPort.value = config.discordLauncherPort || 25500;
    cfgDiscordProxyPort.value = config.discordProxyPort || 25565;
    cfgDiscordMinecraftPort.value = config.discordMinecraftPort || 25565;
    cfgDiscordRestartScript.value = config.discordRestartScript || "start.bat";
    bindDiscordFeatures(config.discordFeatures || {});
    renderDetectionAdvanced(config.thresholds || {}, config.categories || {});
    updateDiscordSetupStatus();
}

function getDiscordRequiredFields() {
    if (!cfgDiscordEnabled.checked) return [];
    return [{ input: cfgDiscordToken, label: 'Botトークン', configured: cfgDiscordToken.dataset.configured === 'true' }];
}

function bindDiscordFeatures(features) {
    document.querySelectorAll('[data-discord-feature]').forEach(row => {
        const value = features[row.dataset.discordFeature] || {};
        row.querySelector('[data-feature-enabled]').checked = Boolean(value.enabled);
        if (value.channel) row.querySelector('[data-feature-channel]').value = value.channel;
        if (value.access) row.querySelector('[data-feature-access]').value = value.access;
    });
}

function collectDiscordFeatures() {
    const features = {};
    document.querySelectorAll('[data-discord-feature]').forEach(row => {
        features[row.dataset.discordFeature] = {
            enabled: row.querySelector('[data-feature-enabled]').checked,
            channel: row.querySelector('[data-feature-channel]').value.trim().replace(/^#/, ''),
            access: row.querySelector('[data-feature-access]').value
        };
    });
    return features;
}

function updateDiscordSetupStatus() {
    const missing = getDiscordRequiredFields().filter(field => !field.input.value.trim() && !field.configured);
    const dot = document.getElementById('discord-status-dot');
    const title = document.getElementById('discord-status-title');
    const description = document.getElementById('discord-status-description');
    const enabledCount = [...document.querySelectorAll('[data-feature-enabled]')].filter(input => input.checked).length;
    const ready = missing.length === 0;
    dot.classList.toggle('ready', ready);
    title.textContent = !cfgDiscordEnabled.checked ? 'Discord Bot OFF' : (ready ? `${enabledCount}機能を有効化` : `未設定項目 ${missing.length}件`);
    description.textContent = ready
        ? (cfgDiscordEnabled.checked ? '保存後にBotを有効化できます' : '確認後、BotをONにしてください')
        : `${missing.map(field => field.label).slice(0, 2).join('・')}${missing.length > 2 ? ' ほか' : ''}`;
}

cfgDiscordToken.addEventListener('input', updateDiscordSetupStatus);
cfgDiscordEnabled.addEventListener('change', updateDiscordSetupStatus);
cfgDiscordBridgeMode.addEventListener('change', updateDiscordSetupStatus);
document.querySelectorAll('[data-feature-enabled], [data-feature-channel], [data-feature-access]').forEach(input => input.addEventListener('change', updateDiscordSetupStatus));

document.getElementById('btn-test-discord').addEventListener('click', () => {
    const missing = getDiscordRequiredFields().filter(field => !field.input.value.trim() && !field.configured);
    if (missing.length > 0) {
        showToast(`${missing[0].label}を入力してください`);
        missing[0].input.focus();
        return;
    }
    const invalidChannel = [...document.querySelectorAll('[data-feature-channel]')].find(input => !/^[a-z0-9_-]{1,100}$/.test(input.value.replace(/^#/, '')));
    if (invalidChannel) { showToast('チャンネル名は英小文字・数字・_・-で入力してください'); invalidChannel.focus(); return; }
    document.getElementById('discord-status-dot').classList.add('ready');
    document.getElementById('discord-status-title').textContent = '入力チェック完了';
    document.getElementById('discord-status-description').textContent = cfgDiscordBridgeMode.checked
        ? 'Bridge接続設定を保存できます'
        : 'Bot設定を保存できます';
    showToast('入力内容を確認しました。保存して反映してください');
});

function renderDetectionAdvanced(thresholds, categories) {
    const container = document.getElementById('detection-advanced-fields');
    const names = {
        itemDrops: 'アイテム投棄（スタック）', advancements: '進捗解除', explodedContainers: 'コンテナ破壊', arsonAttempts: '放火', entityGriefing: 'エンティティ荒らし', signPlacements: '看板設置',
        playerKills: 'PvPキル', tamedMobKills: 'ペット殺害', tamedMobDamage: 'ペット攻撃', endCrystalExplosions: 'エンドクリスタル破壊', rareBlockBreaks: '希少ブロック破壊', bedTraps: 'ベッド罠'
    };
    const categoryNames = { MOB_KILL:'モブ殺害', ITEM_DROP:'アイテム投棄', ADVANCEMENT:'進捗', CONTAINER_BREAK:'コンテナ破壊', LIQUID_PLACE:'液体設置', TNT_PLACE:'TNT設置', END_CRYSTAL_EXPLODE:'エンドクリスタル', ARSON:'放火', ENTITY_GRIEF:'エンティティ荒らし', TAMED_MOB_KILL:'ペット殺害', TAMED_MOB_DAMAGE:'ペット攻撃', RARE_BLOCK:'希少ブロック', SIGN_PLACE:'看板', PVP_KILL:'PvPキル', BED_TRAP:'ベッド罠' };
    container.innerHTML = '';
    const thresholdGroup = document.createElement('div');
    thresholdGroup.className = 'detection-dynamic-group';
    thresholdGroup.innerHTML = '<div class="detection-dynamic-heading"><strong>個別のしきい値</strong><small>すべての有効な検知項目で、監視時間内に警告を発生させる回数を変更できます</small></div><div class="detection-field-grid"></div>';
    const thresholdGrid = thresholdGroup.querySelector('.detection-field-grid');
    Object.entries(names).forEach(([key, label]) => {
        const field = document.createElement('label'); field.className = 'detection-field'; field.innerHTML = `<span>${label}</span><input type="number" min="1" inputmode="numeric" data-threshold="${key}">`;
        field.querySelector('input').value = thresholds[key] ?? GRIEFGUARD_DEFAULT_CONFIG.thresholds[key]; thresholdGrid.appendChild(field);
    });
    container.appendChild(thresholdGroup);
    const categoryGroup = document.createElement('div');
    categoryGroup.className = 'detection-dynamic-group';
    categoryGroup.innerHTML = '<div class="detection-dynamic-heading"><strong>検知する行動</strong><small>不要な項目だけOFFにできます</small></div><div class="detection-category-grid"></div>';
    const categoryGrid = categoryGroup.querySelector('.detection-category-grid');
    Object.entries(categoryNames).forEach(([key, label]) => {
        const field = document.createElement('div'); field.className = 'detection-toggle-field'; field.innerHTML = `<div><strong>${label}</strong><small>この行動を警告対象にする</small></div><label class="switch"><input type="checkbox" data-category="${key}"><span class="slider round"></span></label>`;
        field.querySelector('input').checked = categories[key] !== false; categoryGrid.appendChild(field);
    });
    container.appendChild(categoryGroup);
}

const discordGuideModal = document.getElementById('discord-guide-modal');
function openDiscordGuide() {
    discordGuideModal.classList.remove('hide');
    document.body.classList.add('modal-open');
}
function closeDiscordGuide() {
    discordGuideModal.classList.add('hide');
    document.body.classList.remove('modal-open');
}
document.getElementById('btn-discord-guide').addEventListener('click', openDiscordGuide);
document.getElementById('btn-close-discord-guide').addEventListener('click', closeDiscordGuide);
document.querySelector('[data-close-discord-guide]').addEventListener('click', closeDiscordGuide);
document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !discordGuideModal.classList.contains('hide')) closeDiscordGuide();
});

async function loadServerProperties() {
    try {
        const response = await fetch('/api/server-properties', {
            headers: { 'Authorization': currentToken }
        });
        if (response.ok) {
            const data = await response.json();
            propertiesSchema = data.schema;
            worldExists = Boolean(data.worldExists);
            renderPropertiesUi(data.values);
            document.getElementById('properties-mode-badge').textContent = '再起動で反映';
        } else {
            showToast("server.properties の読み込みに失敗しました。");
        }
    } catch (e) {
        console.error("Failed to load server.properties details:", e);
    }
}

function renderPropertiesUi(values) {
    const groups = new Map();
    propertiesSchema.forEach(field => {
        if (!groups.has(field.group)) groups.set(field.group, []);
        groups.get(field.group).push(field);
    });

    propertiesForm.innerHTML = '';
    groups.forEach((fields, groupName) => {
        const card = document.createElement('section');
        card.className = 'property-card glass';
        const heading = document.createElement('button');
        heading.type = 'button';
        heading.className = 'property-card-heading accordion-trigger';
        const groupStatus = groupName === 'ワールド' && worldExists ? '作成済み・変更不可' : `${fields.length}項目`;
        heading.innerHTML = `<span class="accordion-icon">${fields[0].icon}</span><span class="accordion-label"><strong>${groupName}</strong><small>${fields[0].groupDescription}・${groupStatus}</small></span>${groupName === 'ワールド' && worldExists ? '<span class="locked-badge">🔒 ロック中</span>' : ''}<span class="accordion-chevron">⌄</span>`;
        card.appendChild(heading);

        const content = document.createElement('div');
        content.className = 'accordion-content';
        if (groupName === 'ワールド' && worldExists) {
            const notice = document.createElement('div');
            notice.className = 'world-lock-notice';
            notice.innerHTML = '<span>🔒</span><div><strong>作成済みワールドを保護しています</strong><small>ワールド破損や意図しない再生成を防ぐため、この画面からは変更できません。</small></div>';
            content.appendChild(notice);
        }

        fields.forEach(field => {
            const row = document.createElement('div');
            row.className = `property-row property-${field.type}`;
            const copy = document.createElement('div');
            copy.className = 'property-copy';
            const labelRow = document.createElement('div');
            labelRow.className = 'property-label-row';
            const label = document.createElement('label');
            label.htmlFor = `prop-${field.key}`;
            label.textContent = field.label;
            labelRow.appendChild(label);
            if (field.info) {
                const infoButton = document.createElement('button');
                infoButton.type = 'button';
                infoButton.className = 'property-info-button';
                infoButton.textContent = 'i';
                infoButton.setAttribute('aria-label', `${field.label}の注意事項を表示`);
                infoButton.setAttribute('aria-expanded', 'false');
                const info = document.createElement('small');
                info.className = 'property-info-note';
                info.textContent = field.info;
                info.hidden = true;
                infoButton.addEventListener('click', () => {
                    const expanded = infoButton.getAttribute('aria-expanded') === 'true';
                    infoButton.setAttribute('aria-expanded', String(!expanded));
                    infoButton.classList.toggle('active', !expanded);
                    info.hidden = expanded;
                });
                labelRow.appendChild(infoButton);
                copy.append(labelRow, info);
            } else {
                copy.appendChild(labelRow);
            }
            const description = document.createElement('small');
            description.textContent = field.description;
            copy.appendChild(description);
            row.appendChild(copy);

            let input;
            if (field.type === 'boolean') {
                const switchLabel = document.createElement('label');
                switchLabel.className = 'switch';
                input = document.createElement('input');
                input.type = 'checkbox';
                input.checked = Boolean(values[field.key]);
                switchLabel.append(input);
                const slider = document.createElement('span');
                slider.className = 'slider round';
                switchLabel.append(slider);
                row.append(switchLabel);
            } else if (field.type === 'select') {
                input = document.createElement('select');
                field.options.forEach(option => {
                    const el = document.createElement('option');
                    el.value = option.value;
                    el.textContent = option.label;
                    input.appendChild(el);
                });
                input.value = values[field.key];
                row.append(input);
            } else {
                input = document.createElement('input');
                input.type = field.type === 'number' ? 'number' : 'text';
                input.value = values[field.key] ?? field.default;
                if (field.min !== undefined) input.min = field.min;
                if (field.max !== undefined) input.max = field.max;
                row.append(input);
            }
            input.id = `prop-${field.key}`;
            input.dataset.propertyKey = field.key;
            if (groupName === 'ワールド' && worldExists) {
                input.disabled = true;
                row.classList.add('property-locked');
            }
            content.appendChild(row);
        });
        if (groupName === '参加・ホワイトリスト' || groupName === '接続とアクセス') {
            const whitelistToggle = content.querySelector('#prop-whitelist');
            if (whitelistToggle) content.appendChild(createWhitelistManager(whitelistToggle));
        }
        card.appendChild(content);
        const expandedByDefault = groupName === 'ゲームプレイ';
        heading.addEventListener('click', () => setAccordionState(heading, content, heading.getAttribute('aria-expanded') !== 'true'));
        setAccordionState(heading, content, expandedByDefault);
        propertiesForm.appendChild(card);
    });
    propertiesStatus.textContent = `${propertiesSchema.length} 項目を編集中`;
    propertiesStatus.classList.add('ready');
}

function collectProperties() {
    const values = {};
    propertiesSchema.forEach(field => {
        const input = document.getElementById(`prop-${field.key}`);
        values[field.key] = field.type === 'boolean' ? input.checked :
            field.type === 'number' ? Number(input.value) : input.value.trim();
    });
    return values;
}

function positiveIntegerFromInput(input, label, min = 1, max = 1000000) {
    const value = Number(input.value);
    const valid = Number.isInteger(value) && value >= min && value <= max;
    input.classList.toggle('input-invalid', !valid);
    input.setAttribute('aria-invalid', String(!valid));
    input.setCustomValidity(valid ? '' : `${label}は${min}〜${max}の整数で入力してください`);
    if (!valid) throw new Error(`${label}は${min}〜${max}の整数で入力してください。`);
    return value;
}

function validateProfileInputs(profileName, inputs) {
    const prefix = profileName === 'normal' ? '通常プレイヤー' : '緩和プレイヤー';
    const profile = {
        timeWindowMinutes: positiveIntegerFromInput(inputs.window, `${prefix}の監視時間`, 1, 1440),
        maxWarnings: positiveIntegerFromInput(inputs.maxWarnings, `${prefix}のBAN警告数`, 1, 100000),
        notifyAt: inputs.notifyEnabled.checked
            ? positiveIntegerFromInput(inputs.notify, `${prefix}の本人通知数`, 1, 100000)
            : 0,
        markAtWarnings: positiveIntegerFromInput(inputs.mark, `${prefix}の危険候補数`, 1, 100000),
        fastBanWarningsPerMinute: positiveIntegerFromInput(inputs.fastBan, `${prefix}の高速BAN警告数`, 2, 100000)
    };
    if (profile.notifyAt > 0 && profile.notifyAt >= profile.maxWarnings) throw new Error(`${prefix}の本人通知数はBAN警告数より小さくしてください。`);
    if (profile.markAtWarnings >= profile.maxWarnings) throw new Error(`${prefix}の危険候補数はBAN警告数より小さくしてください。`);
    return profile;
}

function collectConfigData() {
    const thresholds = {
        mobKills: positiveIntegerFromInput(cfgMobKills, 'モブ殺害しきい値'),
        tntPlacements: positiveIntegerFromInput(cfgTntPlacements, 'TNT設置しきい値'),
        liquidPlacements: positiveIntegerFromInput(cfgLiquidPlacements, '液体設置しきい値')
    };
    const categories = {};
    document.querySelectorAll('[data-threshold]').forEach(input => { thresholds[input.dataset.threshold] = positiveIntegerFromInput(input, '追加しきい値'); });
    document.querySelectorAll('[data-category]').forEach(input => { categories[input.dataset.category] = input.checked; });
    const normalProfile = validateProfileInputs('normal', { window: cfgNormalWindow, maxWarnings: cfgNormalMaxWarnings, notify: cfgNormalNotify, notifyEnabled: cfgNormalNotifyEnabled, mark: cfgNormalMark, fastBan: cfgNormalFastBan });
    const relaxedProfile = validateProfileInputs('relaxed', { window: cfgRelaxedWindow, maxWarnings: cfgRelaxedMaxWarnings, notify: cfgRelaxedNotify, notifyEnabled: cfgRelaxedNotifyEnabled, mark: cfgRelaxedMark, fastBan: cfgRelaxedFastBan });
    if (highProfileDraft) {
        for (const [name, values] of Object.entries({ normal: normalProfile, relaxed: relaxedProfile })) {
            const target = highProfileDraft[name];
            if (!target) continue;
            target.detection = { ...(target.detection || {}), timeWindowMinutes: values.timeWindowMinutes, maxWarnings: values.maxWarnings, notifyAt: values.notifyAt, markAtWarnings: values.markAtWarnings };
            target.flashBan = { ...(target.flashBan || {}), warningsPerMinute: values.fastBanWarningsPerMinute };
        }
        highProfileDraft.normal.thresholds = { ...(highProfileDraft.normal.thresholds || {}), ...thresholds };
        highProfileDraft.normal.categories = { ...(highProfileDraft.normal.categories || {}), ...categories };
    }
    const highVersion = highVersionSettings.hidden ? undefined : {
        connectionHistory: cfgHighHistory.checked,
        accountCorrelation: cfgHighCorrelation.checked,
        connectionDefense: cfgHighDefense.checked,
        autoRelaxation: cfgHighAutoRelax.checked,
        requiredEligibleDays: positiveIntegerFromInput(cfgHighRequiredDays, '緩和までの有効日数', 1, 365),
        minimumActiveMinutesPerDay: positiveIntegerFromInput(cfgHighActiveMinutes, '1日の最低プレイ時間', 1, 1440),
        warningFreeDays: positiveIntegerFromInput(cfgHighWarningFreeDays, '警告なし日数', 0, 365),
        countExistingHistory: cfgHighCountExisting.checked,
        notifyPlayer: cfgHighNotifyPlayer.checked,
        ...(highProfileDraft ? { playerProfiles: highProfileDraft } : {})
    };
    return {
        autoBan: cfgAutoBan.checked, autoRollback: cfgAutoRollback.checked,
        backupStorageLocation: cfgBackupStorage.value,
        backupCustomDirectory: cfgBackupCustomDirectory.value.trim(), banReason: cfgBanReason.value,
        discordEnabled: cfgDiscordEnabled.checked, discordToken: cfgDiscordToken.value, discordFeatures: collectDiscordFeatures(),
        discordBridgeMode: cfgDiscordBridgeMode.checked, discordVpsIp: cfgDiscordVpsIp.value.trim(),
        discordBridgePort: parseInt(cfgDiscordBridgePort.value || '25501'), discordWindowsIp: cfgDiscordWindowsIp.value.trim(),
        discordLauncherPort: parseInt(cfgDiscordLauncherPort.value || '25500'), discordProxyPort: parseInt(cfgDiscordProxyPort.value || '25565'),
        discordMinecraftPort: parseInt(cfgDiscordMinecraftPort.value || '25565'), discordRestartScript: cfgDiscordRestartScript.value.trim(),
        ddosLimit: positiveIntegerFromInput(cfgDdosLimit, 'DDoS接続上限', 1, 100000), rateLimitEnabled: true, thresholds, categories,
        profiles: { normal: normalProfile, relaxed: relaxedProfile },
        fastBan: { enabled: cfgFastBanEnabled.checked, windowSeconds: positiveIntegerFromInput(cfgFastBanWindow, '高速BAN判定時間', 5, 3600), requirePotentialDanger: cfgFastBanRequireMark.checked },
        ...(highVersion ? { highVersion } : {})
    };
}

async function saveAllSettings(restartAfterSave) {
    try {
        const configData = collectConfigData();
        const propertiesData = collectProperties();
        showToast("すべての設定を保存中...");
        // Save config.yml
        const confRes = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': currentToken
            },
            body: JSON.stringify(configData)
        });
        
        const configResult = await confRes.json().catch(() => ({}));
        if (!confRes.ok) throw new Error(configResult.error || 'GriefGuard設定を保存できませんでした。');

        // Save server.properties only after config.yml validation has completed.
        const propRes = await fetch('/api/server-properties', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': currentToken
            },
            body: JSON.stringify(propertiesData)
        });
        
        const propertiesResult = await propRes.json().catch(() => ({}));
        if (propRes.ok) {
            if (restartAfterSave) {
                const restart = await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: currentToken }, body: JSON.stringify({ command: '/restart', reasonCode: 'settings-restart' }) });
                if (!restart.ok) throw new Error('再起動コマンドを送信できませんでした');
                showToast('保存し、サーバーの再起動を開始しました');
                logLine('success', '[GriefGuard Mobile] Settings saved; Paper restart requested.');
            } else {
                showToast("設定を保存しました。再起動後に反映されます ⚙️");
            }
            logLine("success", "[GriefGuard Mobile] Both config.yml and server.properties saved successfully.");
        } else throw new Error(propertiesResult.error || 'サーバー設定を保存できませんでした。');
    } catch (e) {
        showToast(e.message || "通信エラーが発生しました。");
    }
}

async function saveGriefGuardSettings() {
    showToast('GriefGuard設定を保存中…');
    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: currentToken },
            body: JSON.stringify(collectConfigData())
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'GriefGuard設定を保存できませんでした');
        showToast('GriefGuard設定を保存しました。再起動後に反映されます');
        logLine('success', '[GriefGuard Mobile] GriefGuard config.yml saved.');
    } catch (error) {
        showToast(error.message || 'GriefGuard設定を保存できませんでした');
    }
}

btnSaveConfig.addEventListener('click', () => saveAllSettings(false));
btnSaveAndRestart.addEventListener('click', () => saveAllSettings(true));

// Give immediate feedback before the user presses save. The API repeats all
// validation, so direct requests or manually edited HTML cannot bypass it.
document.addEventListener('input', event => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.type !== 'number' || !input.closest('#tab-settings')) return;
    const min = Number(input.min || 0);
    const value = Number(input.value);
    const valid = input.value === '' || (Number.isInteger(value) && value >= min);
    input.classList.toggle('input-invalid', !valid);
    input.setAttribute('aria-invalid', String(!valid));
    input.setCustomValidity(valid ? '' : `${min}以上の整数を入力してください`);
});

// Do not rely on device type. visualViewport changes on phones, tablets, touch
// PCs, split-screen windows, and desktop accessibility keyboards alike.
(() => {
    const root = document.documentElement;
    const viewport = window.visualViewport;
    let focused = null;
    let scrollTimer = null;

    const updateViewport = () => {
        const visibleHeight = viewport ? viewport.height : window.innerHeight;
        const offsetTop = viewport ? viewport.offsetTop : 0;
        const keyboardHeight = Math.max(0, window.innerHeight - visibleHeight - offsetTop);
        root.style.setProperty('--gg-visible-height', `${Math.round(visibleHeight)}px`);
        root.style.setProperty('--gg-keyboard-height', `${Math.round(keyboardHeight)}px`);
        document.body.classList.toggle('keyboard-open', keyboardHeight > 80 && Boolean(focused));
    };

    const revealFocusedInput = () => {
        if (!focused || !document.contains(focused)) return;
        focused.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    };

    document.addEventListener('focusin', event => {
        if (!(event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLSelectElement)) return;
        focused = event.target;
        updateViewport();
        clearTimeout(scrollTimer);
        scrollTimer = setTimeout(revealFocusedInput, 180);
    });
    document.addEventListener('focusout', () => {
        clearTimeout(scrollTimer);
        setTimeout(() => {
            if (!document.activeElement || !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) focused = null;
            updateViewport();
        }, 80);
    });
    window.addEventListener('resize', updateViewport);
    if (viewport) {
        viewport.addEventListener('resize', () => { updateViewport(); setTimeout(revealFocusedInput, 80); });
        viewport.addEventListener('scroll', updateViewport);
    }
    updateViewport();
})();
