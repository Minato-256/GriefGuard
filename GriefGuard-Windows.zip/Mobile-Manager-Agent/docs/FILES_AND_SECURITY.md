# ファイル生成・セキュリティ・確認表

## 配布物と自動生成物

| 項目 | いつ作られるか | 扱い |
|---|---|---|
| `GriefGuard.jar` | 配布物 | `MinecraftServer/plugins/`へ置く |
| `plugins/GriefGuard/config.yml` | PaperがGriefGuardを初めて有効化した時 | 通常はアプリから編集。直接編集後は再起動 |
| `plugins/GriefGuard/data.db` | GriefGuard初期化時 | 停止中にのみバックアップ |
| `rollback_pending.txt` | 自動ロールバック予約時だけ | 通常は存在しない。手動削除しない |
| `Backups/` | 最初の自動バックアップが成功した時 | 通常バックアップの保存先。通常起動前には存在しないことがある |
| `Backups/Special/` | 自動ロールバックで被害状態を退避する時だけ | 荒らし発生前は作られないことがある。被害状態のZIPを保存 |
| `AgentData/agent-config.json` | インストーラーまたは設定保存時 | パスワードハッシュとパスを含む。配布禁止 |
| `AgentData/.agent-sessions.json` | Agent初回起動またはログイン時 | セッション情報。配布禁止 |
| `AgentData/.password-reset.json` | パスワードリセットコード発行時だけ | 10分後または使用後に削除 |
| `AgentData/runtime-instance.json` | Agent起動中だけ | 操作ファイルが現在のAgentを識別する。正常停止時に削除 |
| `AgentData/agent-control-token` | インストーラー実行時 | localhost専用操作の秘密情報。配布禁止 |
| `Show-GriefGuard-Setup-Code.bat` / `.command` | インストーラー完了時 | Agent起動中に初回コードを安全に再発行 |
| `Reset-GriefGuard-Admin-Password.bat` / `.command` | インストーラー完了時 | Agent起動中にパスワードリセットコードを発行 |
| `Stop-GriefGuard-Agent.bat` / `.command` | インストーラー完了時 | 対象ワークスペースのAgentだけを正常停止 |
| `Restart-GriefGuard-Agent` / `Agent-Status` / `View-Agent-Log` | インストーラー完了時 | Agentの再起動・状態確認・ログ確認。操作一覧は`Agent-Manual-Controls.txt` |
| `.griefguard/Managed-Plugin-Updater.js` | Java版＋統合版を選択した時 | Geyser/FloodgateだけをPaper起動前に公式配布元から更新確認 |
| `.griefguard/managed-plugins.json` | 同上 | 自動導入したGeyser/Floodgateの管理状態。手動導入JARは自動上書きしない |
| `GriefGuard-Access.txt` | Tailscale設定時、または設定保留時 | Paperサーバー親フォルダーに作成。HTTPS URLと再開方法のみを記録 |
| `connection-info.json` | 同上 | 管理ワークスペース内の機械用接続情報。秘密情報は含めない |
| `node_modules/` | 手動導入で`npm install`後 | インストーラー版では利用者が操作しない |
| `runtime/` | 選んだPaperに必要なJavaがOSで見つからない時 | `GriefGuard-HomeServer`内。OSの有効なJavaがあれば新規取得しない |

## 守ること

- Agentの3000番とBridgeの25501番をインターネットへ直接公開しない。
- 外部アクセスはTailscale Serveを使用する。
- セットアップコード、管理パスワード、Discordトークン、AgentDataを共有しない。
- `config.yml`を直接編集する場合は、数値に0や負数を設定しない。起動時に安全な値へ修復され、ログへ警告が出る。
- プラグイン更新、Paper更新、ワールド移動の前にサーバーを停止し、`Backups`と`plugins/GriefGuard`を別媒体へ保存する。

## 導入完了チェック

```text
□ Paperだけで正常に起動・停止できる
□ plugins/GriefGuard/config.yml が生成された
□ Backups が存在する（Backups/Special は自動ロールバック時にだけ作られる場合がある）
□ 初回コードが不明な場合、Show-GriefGuard-Setup-Codeで再発行できる
□ localhost:3000 で初回セットアップできる
□ Agent起動中にアプリからPaperを起動できる
□ Tailscale HTTPS URLからログインできる（外部利用時）
□ Java版＋統合版を選んだ場合、pluginsにGeyser-Spigot.jarとfloodgate-spigot.jarがある
□ Paperサーバー親フォルダーのGriefGuard-Access.txtに接続URLまたは再開方法が記録されている
```
