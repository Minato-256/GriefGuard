# macOS 導入手順

## 推奨保存先

常時起動用AgentとPaperが同じ場所を読めるよう、次を推奨します。

```text
/Users/Shared/GriefGuardServers/HomeServer/
├─ MinecraftServer/
├─ AgentData/
├─ Backups/
└─ installer-log/
```

`/Applications`はAgentアプリ本体の場所です。ワールドや認証データの保存先ではありません。

## 再インストール時の注意

`/Applications/GriefGuard Manager`だけをゴミ箱へ入れても、起動中のAgent、`~/Library/LaunchAgents/jp.griefguard.mobile-manager.plist`、および`GriefGuard-HomeServer/AgentData`は残ります。最新版インストーラーは、同じ`AgentData`を検出した場合、残っているAgentを正常停止してから最新版を起動し直します。

初期設定前なら、完了画面に新しい`GG-XXXX-XXXX`コードが表示されます。管理パスワードを設定済みなら、既存パスワードを引き継ぐため初回コードは表示されません。別の管理ワークスペースのAgentが3000番を使っている時は安全のため停止せず、対象の`Stop-GriefGuard-Agent.command`を実行するよう案内されます。

## 開始前

1. Paperを一度起動し、`eula.txt`で`eula=true`を設定します。
2. Paperを`stop`で終了します。
3. ターミナルで`java -version`を実行し、Paperが必要とするJavaを確認します。1.17.1〜1.20.4はJava 17、1.20.5〜1.21.xはJava 21、26.xはJava 25です。OSに利用できるJavaがある時はそれを使い、不足時だけ`GriefGuard-HomeServer/runtime`を使います。
4. ダウンロードしたアプリを初回起動する時は、Finderで右クリックして「開く」を選びます。

## インストーラー

配布フォルダの`Installers/macOS/GriefGuard-Installer.pkg`を先に開き、完了後に`GriefGuard-Setup.command`を開きます。既存Paperを選ぶと候補を自動検索します。候補にない時は、開く画面で`paper.jar`、`server.properties`、`start.bat`、`start.command`のどれか一つを選ぶだけです。Paperサーバーフォルダのパスを入力する必要はありません。新しいPaperは`~/Documents/GriefGuardServers/MinecraftServer`へ自動作成され、Agent用の`GriefGuard-HomeServer`はPaperと同じ親へ後から自動作成されます。

パッケージ版が利用できない開発段階では、Agentフォルダから次を実行します。

```sh
chmod +x installer/macos/install.sh
./installer/macos/install.sh
```

質問された値を説明に従って入力します。

- Paperのサーバーフォルダ
- 管理ワークスペース
- Paper JARのファイル名
- Java版ポート（通常`25565/TCP`）
- 統合版を使う時だけGeyserMC用ポート（通常`19132/UDP`）

## 起動

1. `GRIEFGUARD_AGENT_DATA_DIR`を`.../AgentData`に設定してAgentを起動します。
2. ターミナルの`GG-XXXX-XXXX`を初回セットアップ画面へ入力します。
3. Paperは`MinecraftServer/start.command`で起動します。

初回だけ実行権限が必要な場合は、`MinecraftServer`をFinderで開き、ターミナルへフォルダーをドラッグしてから次を実行します。

```sh
chmod +x start.command
```

## `start.command`の手動編集

先頭の4項目だけを編集します。

```sh
PAPER_JAR="paper.jar"
MIN_MEMORY="1G"
MAX_MEMORY="2G"
SERVER_PORT="25565"
```

`java -Xms"$MIN_MEMORY" -Xmx"$MAX_MEMORY" -jar "$PAPER_JAR" --nogui`は変更しません。

## Tailscale

1. MacとスマホへTailscaleを導入して同じアカウントへログインします。
2. Agentを起動してからMacのターミナルで`tailscale serve --bg 3000`を実行します。
3. `tailscale serve status`のHTTPS URLをスマホで開きます。

Tailscale URLは通信経路の認証、GriefGuardパスワードは管理画面の認証です。どちらも必要です。

## macOSでの常時稼働

ログイン中だけでよい場合はLaunchAgent、再起動後にも常時稼働させる場合は専用ユーザーのLaunchDaemonを使用します。後者は`/Users/Shared/GriefGuardServers`へ置き、必要最小限のフォルダ権限だけをAgentへ与えます。管理者権限でAgentを常時実行しません。
