# GriefGuard 配布説明書 更新計画

対象リリース: `2026.07.26.3`  
対象OS: Windows / macOS  
この文書は更新計画および実施記録です。2026-07-26に正本PDF・Plugin同梱README/TXT・Agent README/補助文書・配布入口READMEを生成・同期しました。

## 1. 更新対象

正本を先に更新し、生成物を後から同期する。

1. PDF正本: `GriefGuard_setting/GriefGuard/scripts/build_current_manual_pdf.py`
2. Plugin同梱説明: `GriefGuard_setting/GriefGuard/src/main/resources/README.md`
3. Plugin同梱テキスト: `GriefGuard_setting/GriefGuard/src/main/resources/explain.txt`
4. Agent説明: `GriefGuard_setting/griefguard-ios-web/README.md`
5. Agent補助文書: `GriefGuard_setting/griefguard-ios-web/docs/`
6. 配布入口: `GriefGuard_Distribution/README_FIRST.txt`
7. インストーラー説明: `GriefGuard_Distribution/Installers/README.md`
8. 最終PDF: `output/pdf/GriefGuard_導入・機能説明書.pdf`
9. 配布PDF: `GriefGuard_Distribution/GriefGuard_Manual_JA.pdf`

## 2. PDFの再編内容

### 第1部: 導入前に理解すること

- Agent、Webアプリ、GriefGuard Plugin、Paper、Tailscale、BlueMapの関係図
- Agentのみ起動、Paperのみ起動、Plugin Bridge接続済みの違い
- ルーターへ3000/TCPや25501/TCPを公開しない注意
- 対応表を明記
  - Paper 1.17.1: Java 17
  - Paper 1.20.4: Java 17
  - Paper 1.20.5以降と1.21系: Java 21
  - Paper 26系: Java 25
- GriefGuard JARはJava 17バイトコード、Paper API 1.17基準で作られ、1.17.1から26.1.2まで実起動確認済みと記載

### 第2部: 新規導入

- Windowsは `Start-GriefGuard-Setup.bat`、macOSはPKG実行後に`GriefGuard-Setup.command`を開く
- 既存Paperと新規Paperの選択画面を分け、選ぶフォルダーを図で示す
- 新規Paper作成、Java自動検出・不足時のみTemurin導入、メモリー、ポート、Agent、初回Paper起動、Tailscale HTTPS、BlueMap確認までを画面順に記載
- 各ステップへ「開くファイル」「入力例」「生成されるファイル」「完了の目印」「失敗時のログ」を付ける
- WindowsとmacOSで生成される起動ファイルは、そのOS用だけであることを明記

### 第3部: 既存サーバーへの導入

- Paperサーバー最上位フォルダーの判定条件を示す
- `world`、`plugins`、`server.properties`、既存起動ファイルを勝手に削除しないことを明記
- 既存の起動メモリー設定は読み取って引き継ぐことを記載
- インストーラー実行前にPaperを`stop`で完全停止する理由を説明
- 起動中Paperが妨げる場合の停止選択と、`session.lock`を手動削除しない注意を記載

### 第4部: 旧GriefGuardから最新版へ更新

- 最新配布フォルダーは旧配布フォルダーへ上書きせず別の場所へ展開
- PaperとAgentを停止し、「既存Paper」を選択して再実行
- 既存`plugins/GriefGuard.jar`は日時付き`.installer-backup-*`へ退避される
- `plugins/GriefGuard/config.yml`の既存値、`data.db`、バックアップ、AgentData、管理パスワード、Tailscale URLは保持対象
- 欠けている新設定だけを`config.yml`へ追加する移行仕様を説明
- 更新後に確認するコマンドと状態:
  - Agent / Paper / PluginがONLINE
  - `/say 更新確認`
  - `/griefguard relax <player> true`
  - `/griefguard unrelax <player>`
  - `/griefguard unban <player>`
- 問題時は退避JARへ戻す方法と、設定・DBを消さずにログを確認する順序を記載

### 第5部: Webアプリの操作

- ステータス、コンソール、管理、マップ、設定の5タブを画面例付きで説明
- スマホ、タブレット、小さいPC画面、仮想キーボードで入力欄が隠れない動作を説明
- コンソールはEnterまたは送信ボタンで送信し、成功・失敗・Paper停止中のいずれでも入力欄と候補が消えることを記載
- 管理パスワードはログイン後に入力欄へ保持されないことを記載
- 管理タブで通常／緩和、OP、ログイン回数、BAN、ホワイトリスト候補、先頭`.`付き統合版名を扱う方法を説明
- 数値しきい値の許容範囲と、0を許す例外項目を表にする
- 設定保存と「保存してサーバーを再起動」の違いを説明

### 第6部: BlueMap

- BlueMapは標準導入対象で、Agentの`/map/`から中継することを説明
- 未導入、同意待ち、設定待ち、初回描画中、Paper停止中、表示可能を別々に説明
- `Repair-BlueMap.bat` / `.command`を使う条件
- Paper初回起動で設定生成、ローカルWeb設定適用、2回目起動で待受確認、正常停止という自動確認手順
- BlueMap 8100番を外部へ直接公開しない注意

### 第7部: 更新と保守

- `Update-Paper.bat` / `.command`は公式STABLEだけを表示すること
- 選択Paperに必要なJavaをOS上または管理ワークスペースのキャッシュから再利用すること
- 1.20.4まではJava 17、1.20.5以降はJava 21という境界を強調
- GeyserMC、Floodgate、ViaVersion、BlueMapは必要時だけ互換版へ更新
- 自分で入れたPluginは自動削除・無断更新しないこと
- Agentの開始、停止、再起動、初回コード再発行、パスワードリセット、Tailscale再開の各ファイルを一覧化

### 第8部: トラブル対応

症状ごとに「状態確認 → ログ → 修復ファイル」の順で記載する。

- Agentが開かない
- Paperが起動前に終了する
- `PLUGIN OFFLINE`
- Webアプリからコマンドを送れない
- 外部HTTPSだけ遅い
- BlueMapが未導入と表示される
- Javaを毎回ダウンロードする
- Windows BATが一瞬で閉じる
- PowerShellまたはNode.jsが見つからない
- 旧GriefGuard更新後に設定が見えない

ログ場所はWindows、macOS、Paper、Agent、インストーラーに分け、コピーして問い合わせる範囲と、共有してはいけない認証情報を示す。

## 3. README / MD / TXTの更新方針

- 本文は原則日本語に統一する
- コマンド、ファイル名、ログ原文だけ英数字を維持する
- PDFと同じ対応Java表、既存サーバー導入、旧GriefGuard更新、BlueMap状態表を短縮版として反映する
- `README_FIRST.txt`は「最初に開くファイル」「新規／既存の分岐」「PDFの参照章」だけに絞る
- Plugin同梱READMEと`explain.txt`には、Paper内の配置、初回生成ファイル、GriefGuardコマンド、Agentが別プロセスで必要なことを書く
- 生成条件がある`Backups/`、`Backups/Special/`、`plugins/GriefGuard/config.yml`、`data.db`、BlueMap設定フォルダーは「いつ作られるか」を必ず併記する

## 4. 作成・検証工程

1. 正本の記述を`2026.07.26.3`へ更新
2. PDFを`output/pdf/`へ生成
3. 全ページをPNGへ描画
4. 目次、しおり、ページ番号、表の改ページ、文字切れ、日本語フォント、コマンド枠を目視確認
5. PDFテキストを抽出し、古い版番号、`api-version: 1.21`固定、1.20.4へJava 21必須とする誤記、古いBlueMap手順が残っていないか検索
6. WindowsでPDFを開き、日本語のファイル名と本文が文字化けしないことを確認
7. Windows実機でBATから既存Paper導入を1回、macOS実機でcommandから1回実行
8. 新規、既存、旧GriefGuard更新の各チェックリストを完了
9. 配布フォルダーへPDF、README、MD、TXTを同期
10. Windows/macOS ZIPを再作成し、展開試験とファイルハッシュを確認

## 5. 完了条件

- PDFだけで新規導入、既存導入、旧GriefGuard更新、Tailscale HTTPS、日常操作、復旧が実行できる
- WindowsとmacOSの操作差が章内で明確
- Paper 1.17.1、1.20.4、1.21.11、26.1.2の実試験結果と必要Javaが一致
- 配布版番号がインストーラー、PDF、READMEで一致
- 配布PDFと`output/pdf`のSHA-256が一致
- Windows実機のBAT・PowerShell・フォルダー選択・日本語表示試験が完了
- macOSのPKG・command・Finder選択・自動起動試験が完了

## 6. 実施記録（2026-07-26）

- PDF正本を`配布版 2026.07.26.3`として生成し、16ページをPNG描画して表、本文、目次、ページ番号、日本語フォントを確認した。
- `output/pdf/GriefGuard_導入・機能説明書.pdf`と`GriefGuard_Distribution/GriefGuard_Manual_JA.pdf`のSHA-256一致を確認した。
- Plugin JARを再生成し、同梱README/TXTが最新版であることを確認した。
- Windows/macOS配布ZIPを再作成し、`unzip -t`で整合性を確認した。
- Windows/macOS実機でのインストーラー操作試験は、利用者環境での最終確認が必要である。
