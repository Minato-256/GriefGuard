# GriefGuard オンライン実行環境ブートストラップ計画

作成日: 2026-07-28  
対象: Standard / HighVersion、Windows / macOS  
この文書は設計のみを示し、現行配布物は変更しない。

## 1. 目的

現行macOS PKGへ同梱しているNode.js一式を廃止し、すべてのインストーラーを次の共通方針へ移行する。

1. PC内にある実行可能なNode.js・Javaを検出する。
2. 選択した構成と互換性がある場合だけ既存環境を再利用する。
3. 利用できない場合だけ、公式配布元から必要な版をダウンロードする。
4. GriefGuardが取得した実行環境は共有キャッシュへ保存し、再インストール・Standard/HighVersion間で再利用する。
5. システム側のNode.js・Javaは変更・削除しない。
6. ネットワーク障害で停止しても、再実行時は完了済み工程から再開する。

完全オフライン版は新規作成しない。過去の配布物はロールバック用のGitHub Releaseとして保持する。

## 2. 現状と変更点

| 対象 | 現状 | 変更後 |
|---|---|---|
| Windows Node.js | PATH、Program Filesなどを確認し、無ければエラー終了 | 検出・互換性確認後、無ければ公式Node.jsをユーザー領域へ取得 |
| macOS Node.js | PKGへNode.jsのインストールプレフィックス全体を同梱 | PATH、Homebrew、nvm、Volta、fnmなどを確認し、無ければ公式Node.jsをユーザー領域へ取得 |
| Agent依存関係 | `node_modules`を配布物とPKGへ同梱 | 当面は約4MBの本番依存関係を同梱し、npm操作を利用者へ要求しない |
| Java | PATHのJava、ワークスペース内Temurin、公式Temurinの順で使用 | 全インストーラーで同じ検出結果表示・共有キャッシュ・再開処理へ統一 |
| macOS PKG | Node.jsを含むため約122MB | Agent、Plugin、設定ブートストラップだけを含む小型PKG |
| Standard / HighVersion | 別々の配布物にNode.jsを含める | Node.js・Javaキャッシュを共有し、AgentDataとPluginだけを分離 |

`node_modules`は実行言語ではなくAgentの固定依存関係で、現在約4.1MBしかない。初回のnpmレジストリ障害や依存関係の差し替えを避けるため、最初の移行では同梱を継続する。将来、署名済みAgent Bundleのダウンロード方式へ切り替える余地を残す。

## 3. 配布構成

### 3.1 GitHub Release

```text
GriefGuard Release
├─ GriefGuard-Windows.zip
├─ GriefGuard-macOS.zip
├─ GriefGuard-HighVersion-Windows.zip
├─ GriefGuard-HighVersion-macOS.zip
├─ SHA256SUMS.txt
└─ release-manifest.json
```

各ZIPには次だけを含める。

- 小型インストーラー
- GriefGuard Plugin JAR
- Agentソースと固定本番依存関係
- 説明書
- 公式ランタイムのURL・版・SHA-256を記録したマニフェスト

Node.js、Java、Paper、BlueMap、GeyserMC、Floodgate本体は含めない。

### 3.2 共有ランタイムキャッシュ

Windows:

```text
%LOCALAPPDATA%\GriefGuard\runtimes\
├─ node\<version>-<arch>\
├─ java\<major>-<version>-<arch>\
├─ downloads\
└─ runtime-state.json
```

macOS:

```text
~/Library/Application Support/GriefGuard/runtimes/
├─ node/<version>-<arch>/
├─ java/<major>-<version>-<arch>/
├─ downloads/
└─ runtime-state.json
```

StandardとHighVersionはこのランタイムだけ共有する。認証情報、AgentData、設定、ログは共有しない。

## 4. 起動フロー

### 4.1 Node.jsブートストラップ

Node.jsはセットアップ本体を動かすため、Paper選択より前に確認する。

1. OSとCPUを判定する。
2. 既存Node.js候補を列挙する。
3. 各候補を実際に起動し、版・OS・CPU・実行可能性をJSONで取得する。
4. 対応範囲なら絶対パスを採用する。
5. 利用可能な候補がない場合、共有キャッシュを確認する。
6. キャッシュにも無ければ、マニフェスト指定のNode.js公式アーカイブを取得する。
7. SHA-256一致後だけ展開する。
8. 展開後のNode.jsを実行して再検証する。
9. 選択した絶対パスをセットアップ本体とAgent起動ファイルへ渡す。

Windowsで確認する候補:

- `Get-Command node`
- `where.exe node`
- `%ProgramFiles%\nodejs\node.exe`
- `%LOCALAPPDATA%\Programs\nodejs\node.exe`
- nvm-windows、Volta、fnmの一般的な配置
- GriefGuard共有キャッシュ

macOSで確認する候補:

- ログインシェルの`command -v node`
- `/opt/homebrew/bin/node`
- `/usr/local/bin/node`
- `~/.nvm/versions/node/*/bin/node`
- `~/.volta/bin/node`
- `~/.local/share/fnm/node-versions/*/installation/bin/node`
- GriefGuard共有キャッシュ

単にファイルが存在するだけでは再利用しない。`node`を実行できること、対応メジャー版であること、現在OSで動くことを必須にする。

### 4.2 Javaブートストラップ

Javaは選択したPaper版によって必要版が変わるため、Paper版確定後に確認する。

1. Paper版から必要Javaメジャーを決定する。
2. PATH、OS標準登録、一般的なJDK配置、GriefGuard共有キャッシュを確認する。
3. 必要Javaと一致する実行環境だけを採用する。
4. 見つからない場合だけEclipse Temurin公式APIから取得する。
5. APIが返すSHA-256で検証してから展開する。
6. `java -version`と小さな起動試験を行う。
7. Paper、Paper更新、BlueMap、起動ファイルへ同じ絶対パスを保存する。

古いPaperは新しすぎるJavaで起動できない場合があるため、「必要版以上」ではなくPaper世代ごとの互換版判定を維持する。

### 4.3 その他のダウンロード

Node.js確保後はNodeベースの共通ダウンロード処理を利用する。

- Paper: 公式Paper APIの安定版とSHA-256
- Java: Eclipse Temurin公式APIとSHA-256
- BlueMap: 公式GitHub Release、JAR形式・互換性・SHA-256
- GeyserMC / Floodgate / ViaVersion: Geyser公式配布API、ETag・SHA-256
- GriefGuard更新: GitHub Releaseの署名済みマニフェストとSHA-256

HTTPS以外のURL、許可していないホスト、チェックサム不一致、HTMLを返したダウンロードは拒否する。

## 5. ユーザー画面

最初に「実行環境の確認」ステップを表示する。

```text
[1/6] 実行環境の確認
Node.js 22.x   検出済み・再利用
Java           Paper版選択後に確認
ネット接続     利用可能
保存先         ユーザー用GriefGuardランタイム
```

不足時:

```text
[2/6] Node.jsを準備
PC内に対応版がありません。
公式Node.jsをダウンロードしています  31MB / 42MB
SHA-256を確認しています
Node.js 22.xを利用可能にしました
```

重要な仕様:

- ダウンロード前に名称・版・公式配布元・容量・保存先を表示する。
- 再利用できる場合はダウンロード画面を出さない。
- 管理者権限を要求せず、ランタイムはユーザー領域へ保存する。
- Tailscaleなど別アプリの導入は、自動ダウンロードと同じ工程へ混ぜない。
- エラー画面には「再試行」「後で再開」「ログを開く」を表示する。

## 6. 再開・更新・削除

`bootstrap-state.json`へ各工程を記録する。

```json
{
  "release": "installer release",
  "edition": "standard",
  "completed": ["node-detect", "node-ready", "paper-selected"],
  "nodeExecutable": "absolute path",
  "javaExecutable": "absolute path or null",
  "lastError": null
}
```

- 再実行時はファイルの存在だけでなく、実行試験とチェックサムを再確認する。
- `.partial`ファイルへダウンロードし、検証後に原子的に正式名へ変更する。
- 同じランタイムを複数インストーラーが同時取得しないようロックファイルを使う。
- 更新時は新しい版を別フォルダーへ導入し、動作確認後に参照先を切り替える。
- アンインストーラーはGriefGuardがダウンロードしたランタイムだけ削除できる。
- OSへ元から入っていたNode.js・Javaは絶対に削除しない。

## 7. 修正対象

### 共通

- `installer/runtime-manifest.json`を新設
- ダウンロード元、版、OS、CPU、SHA-256、アーカイブ形式を定義
- `scripts/setup-wizard.js`のJavaキャッシュをOS共通ランタイムキャッシュへ移行
- ランタイムの所有者情報と参照中インストールを記録

### Windows

- `installer/windows/GriefGuard-Setup.ps1`
  - Node.js未検出時のエラー終了を自動取得へ変更
  - TLS 1.2以上、進捗、SHA-256、ZIP展開、再開を実装
- `installer/windows/Start-GriefGuard-Setup.bat`
  - ASCII・CRLFを維持
  - PowerShellブートストラップの終了状態とログを表示
- Windows配布物
  - Node.jsとJavaを同梱しない
  - `node_modules`は当面維持

### macOS

- `installer/macos/GriefGuard Setup.command`
  - 同梱Node.js固定参照を廃止
  - システムNode.js・各バージョン管理ツール・共有キャッシュを検出
  - 不足時は`curl`、`shasum`、`tar`で公式Node.jsを取得
- `installer/macos/2_インストール後のセットアップ.command`
  - PKGにNode.jsが存在することを完了条件から削除
  - ブートストラップの完了状態を確認
- `installer/macos/build-pkg.sh`
  - `node/`ディレクトリとNodeプレフィックスのコピーを削除
  - 小型Agent、Plugin、固定依存関係、マニフェストだけをPKG化
- macOS配布物
  - 小型PKGを通常配布に置き換える
  - 現行122MB PKGは新規配布から外す

### Standard / HighVersion

- 同じブートストラップ実装とランタイムマニフェストを使用
- edition、Plugin JAR、アプリ名、AgentDataだけをパラメーター化
- HighVersion導入時もStandardで取得済みのNode.js・Javaを再利用

## 8. 実装ロードマップ

### Phase 1: 仕様固定

- 対応Windows/macOS、CPU、Node.js対応範囲を確定
- ランタイムマニフェスト形式と公式ホスト許可リストを確定
- 共有キャッシュ・AgentData・アンインストール対象の境界を確定

### Phase 2: Windowsブートストラップ

- 既存Node.js候補検出
- 公式Node.js取得・SHA-256・展開
- 再実行時のキャッシュ再利用
- GUI/ログ/終了コードを実装

### Phase 3: macOS小型PKG

- Node.js同梱を削除
- Intel / Apple Silicon検出
- 既存Node.js・公式取得・SHA-256・展開
- launchd用起動ファイルへ絶対パスを保存

### Phase 4: Java共有処理

- OS内の全候補と既存Temurinキャッシュを統合
- Paper版別互換性を検証
- Standard / HighVersion間の共有と参照管理を実装

### Phase 5: 再開・更新・アンインストール

- 工程状態、ロック、部分ダウンロード、再試行
- ランタイム更新の安全な切替
- GriefGuard管理ランタイムだけを消す削除処理

### Phase 6: 配布再構成

- 通常版・HighVersion版の4配布物を再生成
- Node.js・Java・開発用キャッシュがZIPへ混入していないことを確認
- macOS ZIPの目標を25MB未満に設定
- GitHub Release用SHA256SUMSと更新内容を生成

## 9. テスト計画

最低限、次を自動テストする。

1. 対応Node.jsがある場合、ダウンロード要求が0回である。
2. Node.jsが無い場合だけ、正しいOS・CPUのアーカイブを取得する。
3. 古いNode.js、壊れたNode.js、別CPU版を誤って再利用しない。
4. SHA-256不一致では展開・実行しない。
5. 途中切断後、再実行で完了済み工程をやり直さない。
6. 対応Javaがある場合、Javaをダウンロードしない。
7. PaperごとにJava 17 / 21 / 25を正しく選択する。
8. Standard導入後のHighVersionでランタイムを再ダウンロードしない。
9. システムNode.js・Javaをアンインストーラーが削除しない。
10. Windows x64、Windows ARM64、Intel Mac、Apple Silicon Macで検証する。
11. launchd、Windows自動起動、手動起動・停止、Paper更新が絶対パスで動作する。
12. ネットワーク無し、プロキシ、TLS失敗、公式API停止時に復旧手順を表示する。
13. Windows BATのASCII/CRLF、PowerShellのUTF-8 BOMを維持する。
14. 通常版とHighVersionのAgent・Plugin・設定が混ざらない。

## 10. 完了条件

- macOS配布ZIPが25MB未満を目標として大幅に縮小されている。
- PCに互換Node.js・Javaがある環境では、該当ランタイムを一度もダウンロードしない。
- 不足時はインストーラーを閉じずに自動取得後、そのままセットアップが続く。
- 2回目以降は共有キャッシュを使い、同じランタイムを再取得しない。
- ダウンロードした全実行ファイルについて公式配布元とSHA-256を確認できる。
- Windows・macOS、Standard・HighVersionで同じ判断結果になる。
- ネットワーク障害後の再実行が最初からにならない。
- 現行インストーラーと同等のAgent自動起動、手動管理、Paper更新、BlueMap、Tailscale設定が維持される。
