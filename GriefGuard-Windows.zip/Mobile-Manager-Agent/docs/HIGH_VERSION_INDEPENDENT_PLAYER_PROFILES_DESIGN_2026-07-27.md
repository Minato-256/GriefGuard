# GriefGuard HighVersion 独立プレイヤープロファイル設計

作成日: 2026-07-27  
対象: GriefGuard HighVersion Plugin / Mobile Manager Agent / Webアプリ / インストーラー  
状態: 設計のみ（この文書の作成時点では実装しない）

関連するBlueMapの描画・同期・埋め込み修正は、`BLUEMAP_RENDER_SYNC_AND_EMBED_FIX_DESIGN_2026-07-27.md`に分離して設計する。プレイヤープロファイル改修と同じHighVersionリリースで統合テストする。

## 1. 目的

HighVersionでは「通常プレイヤー」と「緩和プレイヤー」を、名前だけ違う設定ではなく完全に独立した保護プロファイルとして扱う。

各プロファイルで、次の項目を個別に保存・検証・適用できるようにする。

- 監視時間
- 警告上限
- 本人へ警告を表示する値
- 危険候補に指定する値
- Flash BANのON/OFF、判定秒数、警告数、危険候補を必須にするか
- すべての検知カテゴリのON/OFF
- すべての検知カテゴリのしきい値
- 自動BAN
- 自動ロールバック
- BAN理由
- 有効プレイ日数
- 1日として数える最低プレイ時間
- 警告なしを求める日数
- 既存履歴を数えるか
- 条件達成時の本人通知

片方を変更しても、もう片方の値は一切変更しない。設定の継承や暗黙の共通値も使用しない。

## 2. 現状との差

現行実装でプロファイル別になっているのは、次の5項目だけである。

- `time-window-minutes`
- `max-warnings`
- `notify-at`
- `mark-at-warnings`
- `fast-ban-warnings-per-minute`

次の項目は現在共通設定であり、通常・緩和の完全分離には不足している。

- `grief-detection.fast-ban`
- `grief-detection.thresholds`
- `grief-detection.enabled-categories`
- `auto-action`
- `ban-reason`
- `high-version.auto-relaxation`

また、現在の検知処理には、緩和プレイヤーでは危険候補判定を行わない分岐や、カテゴリごとの警告加算上限がコードに固定されている箇所がある。HighVersionでは設定プロファイルから判定するように統一する。

## 3. プロファイルの意味

### 3.1 通常プレイヤー

新規プレイヤーおよび管理者が「通常」に指定したプレイヤーへ適用する。通常プロファイルの信頼条件を満たした場合だけ、自動で緩和プロファイルへ変更できる。

### 3.2 緩和プレイヤー

管理者が「緩和」に指定したプレイヤー、または通常プロファイルの信頼条件を満たしたプレイヤーへ適用する。通常とは別の検知値、カテゴリ、Flash BAN、アクションを使用する。

### 3.3 緩和プロファイルの日数設定

すでに緩和状態のプレイヤーを、さらに別の第三プロファイルへ移動させることはしない。緩和側の日数・プレイ時間・警告なし日数は「緩和状態の継続確認」に使用する。

- 条件達成: 緩和状態を継続し、次の確認期間を開始する。
- 条件未達: 初期設定では状態を勝手に変更せず、管理画面へ「要確認」と表示する。
- 自動で通常へ戻す機能は、誤操作を避けるため別の明示的なON/OFF項目とする。
- 自動復帰をONにした場合だけ、条件未達時に緩和から通常へ戻す。

これにより「通常から緩和へ進む条件」と「緩和状態を維持する条件」を、それぞれ別の日数で管理できる。

## 4. 設定ファイル案

HighVersionの正規設定を `high-version.player-profiles` にまとめる。Standard版はこのブロックを読み込まない。

```yaml
high-version:
  profile-schema-version: 2
  player-profiles:
    normal:
      detection:
        enabled: true
        time-window-minutes: 15
        max-warnings: 5
        notify-at: 0
        mark-at-warnings: 1
        max-warning-contribution-per-category: 2

      flash-ban:
        enabled: false
        window-seconds: 60
        warnings: 3
        require-potential-danger: true

      actions:
        auto-ban: true
        auto-rollback: true
        ban-reason: "Suspicious behavior detected (Anti-Grief)."

      thresholds:
        friendly-mob-kills: 10
        item-drops-stacks: 64
        advancements: 5
        liquid-placements: 5
        tnt-placements: 5
        exploded-containers: 8
        arson-attempts: 10
        entity-griefing: 10
        sign-placements: 10
        player-kills: 1
        tamed-mob-kills: 1
        tamed-mob-damage: 1
        end-crystal-explosions: 1
        rare-block-breaks: 1
        bed-traps: 1

      enabled-categories:
        MOB_KILL: true
        ITEM_DROP: true
        ADVANCEMENT: true
        CONTAINER_BREAK: true
        LIQUID_PLACE: true
        TNT_PLACE: true
        END_CRYSTAL_EXPLODE: true
        ARSON: true
        ENTITY_GRIEF: true
        TAMED_MOB_KILL: true
        TAMED_MOB_DAMAGE: true
        RARE_BLOCK: true
        SIGN_PLACE: true
        PVP_KILL: true
        BED_TRAP: true

      trust-policy:
        enabled: false
        purpose: "promote-to-relaxed"
        required-eligible-days: 14
        minimum-active-minutes-per-day: 30
        warning-free-days: 7
        count-existing-history: false
        notify-player: true

    relaxed:
      detection:
        enabled: true
        time-window-minutes: 5
        max-warnings: 9
        notify-at: 7
        mark-at-warnings: 4
        max-warning-contribution-per-category: 2

      flash-ban:
        enabled: false
        window-seconds: 60
        warnings: 4
        require-potential-danger: true

      actions:
        auto-ban: true
        auto-rollback: true
        ban-reason: "Suspicious behavior detected (Anti-Grief)."

      thresholds:
        # normalとは別の値を全項目保存する

      enabled-categories:
        # normalとは別のON/OFFを全項目保存する

      trust-policy:
        enabled: false
        purpose: "retain-relaxed"
        required-eligible-days: 30
        minimum-active-minutes-per-day: 15
        warning-free-days: 14
        count-existing-history: false
        notify-player: false
        return-to-normal-on-failure: false
```

`thresholds` と `enabled-categories` は両方のプロファイルに全キーを必ず生成する。片方にキーがない場合に、もう片方や共通設定へ暗黙にフォールバックする仕様にはしない。

## 5. プロファイル外に残す設定

次の項目はプレイヤーの検知種別ではなく、サーバー全体・接続元・ワールドへ作用するため、通常と緩和へ複製しない。

- バックアップ先、保存世代数、対象ワールド
- Discord通知と通知チャンネル
- Agent Bridge接続
- 接続回数制限、接続履歴、関連アカウント候補
- BlueMap
- ホワイトリスト
- Paperおよびサーバー設定

ただし、BANとロールバックを実行するかはプレイヤープロファイルの `actions` で個別に指定する。

## 6. Plugin内部設計

### 6.1 設定取得の一本化

`WarningManager`から直接 `plugin.getConfig()` を呼ぶ構造を減らし、次のクラスを追加する。

```text
PlayerProfilePolicy
  ├─ DetectionPolicy
  ├─ FlashBanPolicy
  ├─ ActionPolicy
  ├─ ThresholdPolicy
  ├─ CategoryPolicy
  └─ TrustPolicy

PlayerProfilePolicyResolver
  ├─ resolve(UUID / Player)
  ├─ loadNormal()
  ├─ loadRelaxed()
  └─ validate()
```

すべての検知処理は最初にプレイヤーのプロファイルを確定し、その同じ `PlayerProfilePolicy` インスタンスだけを1回の判定中に使用する。判定途中で設定やプロファイルが変わっても、同一イベント内で通常と緩和の値が混在しないようにする。

### 6.2 変更対象

- `getTimeWindowMillis`: プロファイルの監視時間を使用
- `registerThresholdRule`: プロファイルのしきい値を使用
- `addWarning`: プロファイルのカテゴリON/OFFを使用
- 危険候補判定: 通常・緩和の両方で各自の値を使用
- Flash BAN: ON/OFF、秒数、警告数、危険候補条件をすべてプロファイルから取得
- `executeBan`: プロファイル別の自動BAN、ロールバック、BAN理由を使用
- 個別検知メソッド: 共通 `thresholds` を直接読まず、プロファイルポリシーを使用
- 警告合計: プロファイル別のカテゴリ寄与上限を使用

### 6.3 プロファイル切替時

通常と緩和では監視時間やしきい値が異なるため、切替前の短期カウンターをそのまま引き継がない。

1. プロファイル変更をDBへ記録する。
2. 現在の警告履歴は監査履歴として保持する。
3. BAN判定用のアクティブ警告、イベント回数、Flash BAN時間窓をクリアする。
4. 新しいプロファイル用の信頼期間を開始する。
5. Agentへプレイヤー更新イベントを送る。

これにより、緩和へ変更した瞬間に通常側の警告値でBANされることや、その逆を防ぐ。

## 7. 日数・プレイ時間の記録

現在の単一 `uniqueJoinDays` だけでは、通常と緩和の期間を独立して扱えない。DBにプロファイル別の進捗を保存する。

```sql
player_profile_progress
  player_uuid TEXT NOT NULL
  profile TEXT NOT NULL              -- NORMAL / RELAXED
  period_started_at INTEGER NOT NULL
  eligible_days INTEGER NOT NULL
  active_minutes_today INTEGER NOT NULL
  active_date TEXT
  last_warning_at INTEGER
  last_completed_at INTEGER
  review_status TEXT NOT NULL         -- COUNTING / PASSED / NEEDS_REVIEW / PAUSED
  PRIMARY KEY (player_uuid, profile)
```

追加でプロファイル変更履歴を保持する。

```sql
player_profile_history
  id INTEGER PRIMARY KEY
  player_uuid TEXT NOT NULL
  from_profile TEXT
  to_profile TEXT NOT NULL
  changed_at INTEGER NOT NULL
  source TEXT NOT NULL                -- manual / automatic / retention-failure
  reason TEXT
```

日付変更はサーバーの設定タイムゾーンを基準とする。AFK時間は有効プレイ時間に含めない。再起動しても当日の進捗が失われないようにDBを正とする。

## 8. Agent API設計

取得・保存とも、通常と緩和を同一構造で返す。

```json
{
  "highVersion": {
    "available": true,
    "profileSchemaVersion": 2,
    "playerProfiles": {
      "normal": {
        "detection": {},
        "flashBan": {},
        "actions": {},
        "thresholds": {},
        "enabledCategories": {},
        "trustPolicy": {}
      },
      "relaxed": {
        "detection": {},
        "flashBan": {},
        "actions": {},
        "thresholds": {},
        "enabledCategories": {},
        "trustPolicy": {}
      }
    }
  }
}
```

- APIは片方だけ欠けた保存を拒否する。
- 保存前に両プロファイルを個別検証する。
- エラーには `profile: normal|relaxed` と `field` を含める。
- Standard Plugin接続時はHighVersion用保存をHTTP 409で拒否する。
- 保存成功後は設定ファイルを置き換える前に `.before-profile-v2-日時.bak` を作成する。

## 9. 入力検証

| 項目 | 範囲・条件 |
|---|---|
| 監視時間 | 1～1440分 |
| 警告上限 | 1～100000 |
| 本人通知 | 0でOFF、使用時は警告上限未満 |
| 危険候補 | 1以上、警告上限未満 |
| Flash BAN警告数 | 2～100000 |
| Flash BAN判定時間 | 5～3600秒 |
| 各検知しきい値 | 1～1000000 |
| カテゴリ寄与上限 | 1～1000 |
| 有効日数 | 1～365日 |
| 最低プレイ時間 | 1～1440分 |
| 警告なし日数 | 0～365日 |
| BAN理由 | 空欄不可、最大500文字 |

すべての数値は整数のみとし、`0`、負数、指数表記、`NaN`、小数を用途に応じて拒否する。`警告なし日数` と通知OFFを表す `notify-at: 0` だけは0を許可する。

## 10. WebアプリUI

設定画面のHighVersionカード内に、上部固定の切替を置く。

```text
┌─────────────────────────────────────┐
│ HighVersion プレイヤー保護          │
│ [ 通常プレイヤー ] [ 緩和プレイヤー ] │
├─────────────────────────────────────┤
│ 基本警告設定                        │
│ Flash BAN                           │
│ 信頼・緩和条件                      │
│ 自動アクション                      │
│ ▸ 個別の検知項目                    │
└─────────────────────────────────────┘
```

- 通常は青系、緩和は紫系で識別するが、色だけに依存せず見出しを常時表示する。
- タブを切り替えても未保存値を保持する。
- 各タブに「変更あり」を表示する。
- 保存確認には「通常を変更」「緩和を変更」を個別に列挙する。
- 検知項目はカテゴリごとの折りたたみにし、ON/OFFとしきい値を同じ行へ配置する。
- 「通常の設定を緩和へコピー」「緩和の設定を通常へコピー」は確認ダイアログ付きの補助機能とし、自動同期はしない。
- モバイルでは横並び入力を1列にし、仮想キーボード表示時に選択中の入力欄を画面中央までスクロールする。
- PCの小さいウィンドウや仮想キーボードでも保存バーが入力欄を覆わないようにする。

### 10.1 信頼条件の表示名

- 通常: 「緩和プレイヤーへ移行する条件」
- 緩和: 「緩和状態を継続確認する条件」

緩和側の「条件未達時に通常へ戻す」は危険な設定として詳細欄に置き、初期値をOFFにする。

## 11. インストーラー

HighVersionを選択した時だけ、次の3種類から初期テンプレートを選べるようにする。

1. 推奨: 通常は厳しめ、緩和は余裕を持たせる
2. 同一値から開始: 初期値だけコピーし、導入後は独立
3. 詳細設定をアプリで行う: 安全な初期値で作成

インストーラー内ですべてのしきい値を入力させると導入が複雑になるため、インストーラーではテンプレートと信頼条件のON/OFFだけを扱う。全項目は初回接続後のアプリで編集する。

## 12. 既存環境の移行

初回起動時に `profile-schema-version` が2未満なら一度だけ移行する。

1. 現在の `config.yml` を日時付きでバックアップする。
2. 既存のプロファイル別5項目を、それぞれ対応する新プロファイルへコピーする。
3. 共通 `fast-ban`、`thresholds`、`enabled-categories`、`auto-action`、`ban-reason` を通常・緩和の両方へコピーする。
4. 現在の `high-version.auto-relaxation` を通常の `trust-policy` へコピーする。
5. 緩和の `trust-policy` はOFF、`return-to-normal-on-failure` もOFFで作成する。
6. 既存プレイヤーの通常・緩和区分を維持する。
7. 移行に成功してから `profile-schema-version: 2` を保存する。

移行後も旧キーは1リリースの間読み取り専用フォールバックとして残す。ただし新旧両方が存在する場合は必ず新設定を優先する。次のメジャー更新で旧キーの読み取りを削除する。

## 13. Standard版との分離

- Standard JARは従来の設定構造と動作を維持する。
- HighVersion JARだけが `high-version.player-profiles` を解釈する。
- Agentは接続時の `edition=high` を確認してHighVersion UIを表示する。
- HighVersion設定をStandard JARへ書き込まない。
- HighVersionからStandardへ戻した場合も新設定は削除せず、Standard側が無視する。

## 14. テスト計画

### Plugin単体

- 通常と緩和で同じ行動を行い、異なるしきい値が適用される。
- 通常のカテゴリをOFFにしても緩和側は変わらない。
- 通常のFlash BANをON、緩和をOFFにした時に混在しない。
- プロファイル変更時にアクティブ警告だけがクリアされ、監査履歴は残る。
- 通常の信頼条件達成で一度だけ緩和へ変更される。
- 緩和の継続条件未達でも初期設定では通常へ戻らない。
- 明示的に自動復帰をONにした時だけ通常へ戻る。

### Agent/API

- 両プロファイルの全項目を読み書きできる。
- 片方の保存で他方が変化しない。
- 0、負数、小数、不整合値を拒否する。
- Standard接続中はHighVersion設定を拒否する。
- 保存前バックアップが生成される。

### UI

- スマホ、タブレット、PCでタブと折りたたみが崩れない。
- 仮想キーボードで入力欄と保存ボタンが隠れない。
- 未保存値を保持したまま通常・緩和を往復できる。
- コピー機能は確認後だけ実行される。

### 移行

- 現行HighVersion設定から値を失わず移行できる。
- 古いGriefGuardから最新版への直接更新が成功する。
- 途中失敗時に旧 `config.yml` へ戻せる。
- WindowsとmacOSのインストーラーで同じ設定結果になる。

## 15. 実装順序

1. 新設定スキーマ、検証クラス、移行処理を追加する。
2. `PlayerProfilePolicyResolver`を追加する。
3. 全検知処理から共通設定の直接参照を除去する。
4. プロファイル別進捗DBと変更履歴を追加する。
5. Bridge/APIの取得・保存形式を更新する。
6. Webアプリを通常・緩和の独立タブへ再構成する。
7. HighVersionインストーラーのテンプレートを更新する。
8. Plugin、Agent、UI、移行、Windows/macOSの回帰テストを行う。
9. HighVersion JAR、PKG、Windows配布物、ZIP、説明書を同じ版番号で再生成する。

## 16. 完了条件

- 通常と緩和の全主要設定が同一構造で表示される。
- 片方の設定変更がもう片方へ影響しない。
- Pluginのすべての検知経路が現在のプレイヤープロファイルだけを参照する。
- 日数、プレイ時間、警告なし日数がプロファイル別に保存される。
- 緩和プレイヤーを意図せず通常へ戻さない。
- 既存HighVersion環境を値を失わず移行できる。
- Standard版の動作と設定を変更しない。
