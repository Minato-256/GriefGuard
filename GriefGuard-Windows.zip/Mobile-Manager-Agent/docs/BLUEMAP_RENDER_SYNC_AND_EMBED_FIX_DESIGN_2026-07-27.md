# BlueMap 描画・同期・埋め込み不具合 修正設計

作成日: 2026-07-27  
対象: GriefGuard Installer / Mobile Manager Agent / Webアプリ / BlueMap連携  
状態: 設計のみ（この文書の作成時点では修正を実装しない）

関連設計:

- `HIGH_VERSION_INDEPENDENT_PLAYER_PROFILES_DESIGN_2026-07-27.md`
- `BLUEMAP_DIAGNOSTIC_AND_REPAIR_PLAN_2026-07-27.md`

## 1. 対象症状

次の症状を正常動作として扱わず、再現・診断・修復対象とする。

1. BlueMapに表示される地形・バイオームが実際にプレイしたワールドと一致しない。
2. チャンク境界が不自然、欠落、重複して見える。
3. 読み込みマークが消えない。
4. 一人称／自由飛行表示で、過去フレームの残像が消えず重なる。
5. Minecraft内で置いた・壊したブロックが地図へ反映されない。
6. Webページを再読み込みした後、一度表示モードを切り替えないと地図が描画されない。
7. 上記以外のBlueMap、Agent Proxy、Webアプリ埋め込みの不具合も診断する。

## 2. 現環境の調査結果

調査対象:

```text
server data/MinecraftServer
Paper: 26.1.2 build 74
Java: 25
BlueMap: 5.20
BlueMap WebServer: 127.0.0.1:8100
Agent Proxy: /map/
```

### 2.1 互換性

BlueMap 5.20の公式配布情報では、Paper版はPaper/Folia 26.1.1～26.1.2を対象とし、Java 25を要求している。現在のPaper 26.1.2／Java 25は対応範囲内である。

したがって、今回の症状を単純な「非対応バージョン」とは判定しない。

### 2.2 BlueMap本体

- `latest.log`にはBlueMapのERROR／Exceptionがない。
- `world`、`world_the_nether`、`world_the_end`を読み込んでいる。
- WebServerは8100番で正常起動している。
- `pluginState.json`ではレンダースレッドと各マップの更新が有効。
- デバッグログではワールドregionファイルの変更を検出し、更新をスケジュールしている。
- 実際に地図タイルの更新時刻も進んでいる。

BlueMap本体が完全停止している状態ではない。

### 2.3 未描画タイル

WebServerログでは、初期表示中に大量のタイル要求へ`204 No Content`が返っている。生成済みタイルは200、未描画または存在しない範囲は204である。

初期カメラが広い範囲を要求すると、描画済みの小さな範囲より未描画範囲が大幅に多くなり、黒画面や読み込み継続に見える。現在の「settings.jsonが取得できてマップIDが1件以上あればready」という判定では、この状態を正常と誤認する。

### 2.4 WebApp保存先の解決ミス

現在のBlueMap設定は次である。

```hocon
data: "bluemap"
webroot: "bluemap/web"
```

実際のWebAppはPaperの作業ディレクトリを基準に、次へ生成されている。

```text
server data/MinecraftServer/bluemap/web
```

しかし、Agent診断と`refreshBlueMapWebAppIfRequired`はBlueMap設定フォルダを基準に解決し、次を参照している。

```text
server data/MinecraftServer/plugins/BlueMap/bluemap/web
```

後者は存在しない。これにより次の問題が起きる。

- WebAppの版・更新時刻を正しく診断できない。
- Repair-BlueMapが実際の`index.html`を更新できない。
- 修復済みと記録しても、実際のWebAppは古いまま残る可能性がある。
- 正しいWebAppと誤ったパスの診断結果が食い違う。

このパス基準の修正をP0とする。

### 2.5 iframe初期化の競合

現在のアプリは次の順序でBlueMapを読み込む。

1. iframeは`hidden`で開始する。
2. `frame.src`を設定する。
3. その後で`frame.onload`を登録する。
4. iframeの`hidden`を解除する。

問題点:

- 高速なローカル応答では、`onload`登録前にloadが完了する競合が起こり得る。
- 非表示または親タブが`display:none`の状態でBlueMapがWebGL canvasのサイズを計算すると、初期サイズが0または不正になる可能性がある。
- 表示モード切替でBlueMap内部のリサイズが走るため、「一度一人称視点にすると表示される」という症状と一致する。

### 2.6 ブラウザーキャッシュ

Agent経由で確認した結果:

```text
/map/settings.json
  Cache-Control: no-store

/map/maps/world/settings.json
  Cache-Control: no-store

/map/maps/world/tiles/...prbm
  Cache-Control: max-age=86400
```

地図タイルは最大24時間キャッシュされる。BlueMapが同じタイルを再描画してもURLが同一なら、端末側が古いタイルを保持できる。これは「置いたブロックがいつまでも反映されない」直接の原因候補である。

### 2.7 ブラウザー表示比較

- BlueMapへ直接接続した画面では、JavaScriptエラーなしで地図を表示できた。
- Agentの`/map/`経由でも設定・テクスチャ・マップ情報の読み込みは成功し、JavaScriptエラーはなかった。
- `/map/`側では初期カメラ状態によって黒画面になるケースを確認した。
- ブラウザーコンソールにはWebGL例外がないため、通信失敗だけでなく、保存されたカメラ状態、未描画範囲、iframe初期寸法、合成レイヤーの問題を分離して試験する必要がある。

## 3. 原因の優先順位

### P0

1. WebApp相対パスの基準が誤っている。
2. iframeを非表示のまま初期化している。
3. `onload`を`src`設定後に登録している。
4. タイルへ24時間キャッシュが残る。
5. ready判定がマップの実データと描画進捗を確認していない。

### P1

1. 現在のワールドとレンダリング済みデータの同一性を確認する識別子がない。
2. 初期カメラ位置が描画済み範囲またはプレイヤー位置を考慮しない。
3. BlueMapの更新キュー、freeze、stop、最新タイル時刻をAgentが取得しない。
4. WebGL iframeと`overflow:hidden`、角丸、半透明レイヤーの組み合わせを端末別に検証していない。

### P2

1. 初回描画と差分更新の進捗がUIへ表示されない。
2. 直接配信とAgent経由配信の応答差を継続監視しない。
3. 描画負荷・容量・未描画チャンク数を表示しない。

## 4. ワールド・バイオーム不一致対策

BlueMapはMinecraftのワールドを生成しない。既存のregionファイルを読み取り地図を生成する。したがって、地形が異なる場合は「誤ったワールドパス」「異なるdimension」「以前のワールドのタイル」「古いキャッシュ」を順に判定する。

### 4.1 ワールド指紋

インストーラーまたは初回BlueMap起動時に、各マップへワールド指紋を保存する。

```json
{
  "mapId": "world",
  "worldPath": "<canonical absolute path>",
  "dimension": "minecraft:overworld",
  "levelDatHash": "<stable identity hash>",
  "worldUuid": "<available when present>",
  "seedHash": "<seed itselfは保存しない>",
  "regionDirectory": "<canonical absolute path>",
  "storageId": "file",
  "storageRoot": "<canonical absolute path>",
  "recordedAt": "ISO-8601"
}
```

- Seedそのものはアプリやログへ出さない。
- `level.dat`全体の単純ハッシュは`LastPlayed`で変化するため、ワールドUUID、seedのハッシュ、dimension、regionパスなど安定項目を使う。
- NBTを読めない場合は、level.dat内の安定識別情報とregion構成から代替指紋を作る。

### 4.2 不一致時

- 自動で既存地図データを削除しない。
- Paper停止中に、旧ストレージを日時付きの隔離フォルダへ移動する。
- 新しい空のストレージへ対象ワールドを再描画する。
- UIに「旧ワールドの地図を隔離しました」と表示する。
- 復元用パスを診断レポートへ記録する。

### 4.3 マップ設定検証

各`.conf`について次を検証する。

- `world`が実在するPaperワールドを指す。
- `dimension`と実際のdimensionフォルダが一致する。
- `storage`が実在する設定を指す。
- `storage.root`がPaper作業ディレクトリ基準で正しく解決される。
- 同じmap IDの旧データが別ワールド由来でない。
- overworld／nether／endを誤って同じdimensionとして扱っていない。

## 5. WebAppパス修正

パス解決関数を一つに統一する。

```text
resolveBlueMapRuntimePath(serverRoot, configuredPath)
```

要件:

- 絶対パスはそのまま正規化する。
- 相対パスはPaperのサーバールートを基準に解決する。
- `..`でサーバールート外へ出る設定は管理対象外として警告する。
- `core.conf:data`、`webserver.conf:webroot`、`webapp.conf:webroot`、`storage.root`で同じ関数を使う。
- 実在する正規パスを診断結果へ表示する。

`detailsFor`、`refreshBlueMapWebAppIfRequired`、Repair-BlueMap、インストーラー検証、Paper updaterの全箇所をこの関数へ移行する。

## 6. iframe・再読み込み修正

### 6.1 読み込み順

次の順序へ変更する。

1. マップタブがactiveになり、表示領域が0より大きいことを確認する。
2. `load`、`error`、タイムアウトハンドラを先に登録する。
3. iframeをレイアウト上表示する。読み込み中は`visibility:hidden`または`opacity:0`を使い、`display:none`／`hidden`を使わない。
4. 次のanimation frameで`src`を設定する。
5. load後、iframe内へ`resize`イベントを送る。
6. iframe canvasが表示領域と一致したことを確認してからローディングを消す。

iframeが同一オリジンの`/map/`である間は、次を確認できる。

```text
contentWindow.innerWidth / innerHeight
canvas.clientWidth / clientHeight
canvas.width / height
```

### 6.2 初期化状態

`idle → status-checking → document-loading → renderer-ready → visible`

状態遷移を明示し、同時に複数の`loadBlueMap()`を動かさない。各呼び出しへ世代番号を付け、古い非同期結果が新しいiframeを上書きしないようにする。

### 6.3 読み込み完了

iframeのHTML loadだけで完了としない。次の条件を満たして`renderer-ready`とする。

- BlueMapのcanvasが存在する。
- canvasの幅と高さが1以上。
- `settings.json`と選択マップの`settings.json`が成功。
- 代表的な描画済みタイルが200。
- BlueMap側から`postMessage({type:"bluemap-ready"})`を受ける、または同等のラッパー監視が成功。

BlueMap本体を直接改変しない場合は、Agentから配信する小さな同一オリジンラッパーページでready判定とresize通知を行う。

### 6.4 カメラ復旧

- 保存されたURL anchor／cookieが描画済み範囲外なら無視する。
- 最初は現在のオンラインプレイヤー位置、なければworld spawn、なければ最初の描画済みタイル中心を使用する。
- 「表示をリセット」ボタンをアプリ側に設ける。
- リセットはBlueMap全体のcookieを無差別削除せず、カメラ・選択マップ関連だけを対象にする。
- リロード時に一人称切替を要求しない。

## 7. 読み込みマークの修正

ローディング表示を次の3種類へ分ける。

- WebApp読込中
- 初回地図描画中
- 表示位置のタイルが未描画

永続的なスピナーだけを表示しない。15秒で状態文を表示し、30秒で診断導線を出す。

例:

```text
地図画面を読み込んでいます
初回描画: 42%（描画済み 84 / 200 region）
現在位置のタイルはまだ描画されていません
```

`204 No Content`を通信成功として数えるだけでなく、tile missとして集計する。同一画面で一定数以上の204が続く場合は`renderer-ready`にせず、`view-outside-rendered-area`を返す。

## 8. ブロック変更の反映

### 8.1 更新経路

```text
ブロック変更
  → Paperがchunkを保存
  → regionファイルmtime更新
  → BlueMap MapUpdateServiceが検知
  → render queueへ追加
  → 新しいタイルを書き出す
  → Agentが新しいタイルを配信
  → ブラウザーが再検証して表示
```

各段階の時刻を診断結果へ出す。

```text
worldRegionModifiedAt
updateScheduledAt
tileRenderedAt
tileServedAt
clientTileVersion
```

### 8.2 キャッシュ方針

Agent経由の地図タイルは固定の`max-age=86400`をそのまま通さない。

推奨:

```text
Cache-Control: no-cache, must-revalidate
ETag: world-fingerprint + tile-mtime + tile-size
Last-Modified: tile mtime
```

- タイルが変わっていなければ304を返す。
- 変わったタイルだけ200で再取得する。
- ハッシュ付きWebApp JS/CSSは長期キャッシュ可能。
- `settings.json`、liveデータ、地図タイルは用途別にキャッシュを分離する。
- Tailscale HTTPS経由でも同じヘッダーになることを確認する。

### 8.3 更新監視

- region更新後にタイル更新時刻が一定時間進まなければ`render-stalled`。
- render queueが増え続ける場合は`render-backlogged`。
- プレイヤー数による描画停止は`render-paused-by-player-limit`。
- freezeまたはstopは`render-frozen`／`render-stopped`。
- 自動修復では最初に`/bluemap update <map> <x z> <radius>`相当の限定更新を試す。
- `force-update`や全データ再描画はユーザー確認後だけ実行する。

## 9. 一人称表示の残像

残像はWebGLレンダラー、iframe合成、端末GPUのどこで発生しているかを分離する。

### 9.1 比較試験

同じ端末・座標・視点で次を比較する。

1. `http://127.0.0.1:8100/`のBlueMap直接表示
2. `http://localhost:3000/map/`のAgent Proxy直接表示
3. GriefGuardアプリ内iframe
4. Tailscale HTTPSの`/map/`

判定:

- 1でも残像: BlueMap/WebGL/GPU側
- 1は正常、2で発生: Proxyヘッダー・圧縮・配信側
- 2は正常、3で発生: iframe/CSS合成側
- localhostは正常、HTTPSだけ発生: Tailscale経路または端末ブラウザー差

### 9.2 CSS・合成要件

マップ表示中はiframeとWebGL canvasの祖先から、次の影響を排除して比較する。

- `backdrop-filter`
- 不要な`opacity`アニメーション
- `transform`
- iframe自身の`border-radius`クリップ
- 複数の半透明オーバーレイ

マップ領域を独立した不透明レイヤーとして扱い、診断用に「互換表示モード」を用意する。

```css
map-pane: background #000; isolation:isolate;
iframe: border:0; border-radius:0; opacity:1;
```

互換表示で残像が消える場合は、装飾を一つずつ戻して原因となるCSSを特定する。

### 9.3 WebGLテスト

- Chrome／Edge
- Safari／iOS WebKit
- Android Chrome
- Windows GPU 2種類以上
- macOS Intel／Apple Siliconの可能な範囲
- ハードウェアアクセラレーションON/OFF

WebGL context lost／restoredを記録し、context lost時はiframeを自動再生成する。

## 10. 診断API拡張

`GET /api/map-diagnostics`へ追加する。

```json
{
  "state": "ready | initial-rendering | render-stalled | world-mismatch | view-outside-rendered-area | proxy-degraded",
  "worlds": [{
    "mapId": "world",
    "worldPath": "...",
    "dimension": "minecraft:overworld",
    "fingerprintMatch": true,
    "regionModifiedAt": "...",
    "latestTileAt": "...",
    "tileLagSeconds": 12
  }],
  "render": {
    "threadsEnabled": true,
    "updateEnabled": true,
    "queueLength": 0,
    "tileMissRate": 0.12
  },
  "webapp": {
    "resolvedRoot": ".../bluemap/web",
    "canvasReady": true,
    "version": "5.20"
  },
  "proxy": {
    "settings": 200,
    "representativeTile": 200,
    "cachePolicyValid": true
  }
}
```

診断のためにBlueMap公式コマンドの結果も取得できるようにする。

- `/bluemap`
- `/bluemap tasks`
- `/bluemap troubleshoot <map> <x> <z>`
- `/bluemap debug world <map> <x> <y> <z>`
- `/bluemap debug map <map> <x> <z>`
- 必要時だけ`/bluemap debug dump`

読み取り専用診断と更新・再描画コマンドを分離する。

## 11. Repair-BlueMap再設計

### 通常修復

1. Paper停止確認
2. BlueMap JAR・Java・Paper互換性確認
3. 実際のWebApp／storageパス解決
4. map configとworld fingerprint確認
5. WebApp入口だけをバックアップ・再生成
6. Paper一時起動
7. map settings、代表タイル、liveデータ確認
8. 初期描画または差分描画の進捗確認
9. Paper正常停止
10. 修復レポート保存

### 地図不一致修復

1. 不一致を画面に明示
2. 旧地図データの容量と場所を表示
3. ユーザー確認
4. 旧データを削除せず隔離
5. 新ストレージへ再描画
6. 新旧指紋と代表座標を比較

### 描画停止修復

1. freeze／stop／player limitを確認
2. 限定範囲のupdateを実行
3. タイル時刻が進むか確認
4. 改善しない場合だけforce-updateを提案

`Repair-BlueMap`の実行だけで全地図データを消さない。

## 12. インストーラー変更

- BlueMap導入後、JAR・設定・WebServerだけで完了扱いにしない。
- 実際のWebAppパス、マップ数、代表タイル、world fingerprintを検証する。
- 初回描画中なら完了を妨げず、管理ワークスペースへ継続監視ファイルを生成する。
- `GriefGuard-Access.txt`へBlueMap状態、ローカルURL、Tailscale URL、Repairファイルの場所を記録する。
- Paper更新時はBlueMapの対応版とworld path生成仕様を再確認する。
- BlueMap更新でWebApp再生成が必要な場合だけ、安全な再生成を行う。

## 13. 追加で確認する不具合

- `webserver.conf.webroot`と`webapp.conf.webroot`の不一致
- 複数サーバーが同じ8100番を使用する競合
- Agentが別のMinecraftサーバーのBlueMapへ接続する誤配線
- 古いmap IDがsettings.jsonへ残る
- 過去ワールドのstorageが表示される
- Nether／Endのdimensionパス不一致
- BlueMap JARとWebApp JSの版不一致
- gzip／zstd／deflateをAgentが壊さず中継できるか
- Range、ETag、Last-Modified、304の中継
- 404と204の扱い
- Tailscale HTTPSでの遅延・切断・再接続
- iframeを長時間開いた場合のメモリ増加
- タブを往復した場合のWebGL context増殖
- 複数端末で同時閲覧した場合のAgent負荷
- world名に日本語・空白がある場合
- worldの再生成、seed変更、バックアップ復元後の指紋変更
- Paper異常終了後のregion／render-state整合性

## 14. テスト計画

### 自動テスト

- 相対WebAppパスをサーバールート基準で解決する。
- 誤った`plugins/BlueMap/bluemap/web`を参照しない。
- map configとworld fingerprintの一致・不一致を判定する。
- タイル200、未描画204、破損5xxを区別する。
- タイルのキャッシュヘッダーを再検証可能な形式へ変換する。
- iframeのload handlerがsrc設定前に登録される。
- iframeサイズ0では初期化しない。
- 重複した`loadBlueMap()`が同時実行されない。

### 実サーバー

1. 新規ワールドへ目印となるブロックを置く。
2. 対象chunkの保存時刻を確認する。
3. BlueMap更新キューを確認する。
4. タイル更新時刻が進むことを確認する。
5. localhost、Agent Proxy、Tailscale HTTPSで同じ表示を確認する。
6. ページを10回再読み込みし、視点切替なしで表示されることを確認する。
7. 自由飛行で60秒移動し、残像が残らないことを確認する。
8. 通常・平面・自由飛行を往復し、canvasとメモリが増殖しないことを確認する。

### 互換性

- Windows 11: Edge／Chrome
- macOS: Safari／Chrome
- iPhone／iPad: Safari／ホーム画面PWA
- Android: Chrome
- ローカルHTTP／Tailscale HTTPS
- 新規サーバー／既存サーバー／旧GriefGuard更新

## 15. 実装順序

1. BlueMapランタイムパス解決を修正する。
2. 診断APIへworld fingerprint、代表タイル、更新時刻を追加する。
3. Agent Proxyのタイルキャッシュ方針を修正する。
4. iframeの初期化順・状態管理・resize処理を修正する。
5. カメラ復旧と表示リセットを追加する。
6. Repair-BlueMapを段階修復へ変更する。
7. インストーラーの完了判定を強化する。
8. 直接／Proxy／iframe／Tailscaleの比較テストを行う。
9. Windows／macOS／スマホ実機でWebGL残像を確認する。
10. JAR、Agent、インストーラー、配布ZIP、説明書を同じリリースへ更新する。

## 16. 完了条件

- 実際のワールドと異なる地図データを自動でready表示しない。
- 旧ワールドの地図を削除せず検出・隔離できる。
- ページ再読み込み後、視点切替なしで地図が表示される。
- 正常表示時に読み込みマークが残らない。
- 保存・描画済みのブロック変更がキャッシュに妨げられず反映される。
- 自由飛行で残像が発生しない、または互換表示モードで確実に回避できる。
- 初回描画、未描画範囲、描画停止、Proxy障害を別の状態として表示できる。
- Repair-BlueMapが正しいWebAppパスを修復する。
- Windows、macOS、iOS、Android、localhost、Tailscale HTTPSで同じ基本動作を確認する。
