# Windows 導入手順

この手順だけで、Paper・GriefGuard・Mobile Manager Agentを同じ管理単位へ導入できます。Minecraftのワールドを消す操作は含みません。

## 完成形

```text
D:\GriefGuardServers\HomeServer\
├─ MinecraftServer\       ← Paper、world、plugins、start.bat
├─ AgentData\             ← Agentの設定・認証・ログインセッション
├─ Backups\               ← 通常バックアップ（Specialは自動ロールバック時に作成）
└─ installer-log\
```

Agent本体は`C:\Program Files\GriefGuard Manager\`へ置きます。`MinecraftServer`内へAgent本体をコピーしないでください。

## 開始前の確認

1. Paperを一度単体で起動し、`eula.txt`を作成して`eula=true`へ変更します。
2. Paperを停止します。コンソールで`stop`を入力し、プロセスが残っていないことを確認します。
3. Paperに必要なJavaを確認します。1.17.1〜1.20.4はJava 17、1.20.5〜1.21.xはJava 21、26.xはJava 25です。インストーラーはOSに使えるJavaがあれば再利用し、不足時だけ管理ワークスペースの`runtime`を使います。
4. PowerShellで`java -version`を実行し、必要なJavaが表示されることを確認します。

## インストーラーを使う場合

1. 配布ZIPを右クリックして「すべて展開」します。ZIPを開いたまま実行しません。
2. `Installers\Windows\Start-GriefGuard-Setup.bat`をダブルクリックします。`GriefGuard-Setup.ps1`を直接実行する必要はありません。
3. 「既存Paperサーバー」を選ぶと、最初に見つかったPaper候補を番号で選べます。候補にない時もパスを貼り付けず、開く画面で`paper.jar`、`server.properties`、`start.bat`、`start.command`のどれか一つを選びます。インストーラーが親のPaperサーバーフォルダを自動判定します。初回起動前はPaper JARだけでも選択できます。
4. 「新しいPaperサーバー」を選ぶと、`C:\Users\名前\Documents\GriefGuardServers\MinecraftServer`へ自動作成されます。同名がある時は`MinecraftServer-2`になります。配布ZIPや`Installers`の中には作成されません。Paper・Agent・Pluginの初回起動が完了すると、`config.yml`と必要な管理ファイルが自動生成されます。
5. 管理ワークスペースはPaperサーバーと同じ親へ`GriefGuard-HomeServer`として自動作成されます。この場所を選ぶ質問は表示されません。既存サーバーは移動されません。
6. Java版の接続方式では`25565/TCP`を選びます。統合版も参加させる時だけ「Java版＋統合版（GeyserMC）」を選び、GeyserMC用に`19132/UDP`を別設定します。
7. 完了後に作られるAgent起動ファイルを開きます。

成功条件は次の3つです。

```text
MinecraftServer\plugins\GriefGuard.jar が存在する
MinecraftServer\plugins\GriefGuard\config.yml がPaper初回起動後に生成される
AgentData\agent-config.json が存在する
```

## 手動でワークスペースを生成する場合

AgentフォルダでPowerShellを開き、実在するパスとJAR名へ置き換えて実行します。

```powershell
node scripts\create-workspace.js `
  --workspace "D:\GriefGuardServers\HomeServer" `
  --server-dir "D:\GriefGuardServers\HomeServer\MinecraftServer" `
  --paper-jar "paper.jar" `
  --min-memory "1G" `
  --max-memory "2G" `
  --server-port 25565
```

この操作は`AgentData`と起動ファイルを作ります。`Backups`はGriefGuardがPaper上で有効になった後に作られ、`Backups\Special`は自動ロールバックで被害状態を退避する時だけ作られます。既にある起動ファイルは上書きしません。

## 起動する順番

1. Agentを起動します。
2. Agentコンソールの`GG-XXXX-XXXX`を控えます。コードは10分間・1回のみ有効です。
3. `http://localhost:3000`を開き、初回セットアップを完了します。
4. MinecraftServerで`start.bat`を実行するか、アプリの起動ボタンを使用します。
5. PaperのログにGriefGuard有効化とBackup rootが表示されることを確認します。

## `start.bat`を手動編集する場合

編集してよいのは冒頭の4項目だけです。

```bat
set "PAPER_JAR=paper.jar"
set "MIN_MEMORY=1G"
set "MAX_MEMORY=2G"
set "SERVER_PORT=25565"
```

JARを起動する正しい部分は`-jar "%PAPER_JAR%"`です。`-paper.jar`のように`-jar`を省略するとJavaが起動できません。

## Agentを常時利用する場合

インストーラー版ではWindowsサービスを使用します。サービスが起動していれば、Minecraftが停止中でもアプリから起動できます。Agentを停止すると、アプリは接続・起動・ログ取得を行えません。

`AgentData`には認証情報があります。共有フォルダ、クラウド同期、Git、配布ZIPへ入れないでください。

## 外部から安全に接続する

3000番や25501番をルーター公開しません。Agent PCとスマホを同じTailscaleネットワークへ参加させ、Agent PCで次を実行します。

```powershell
tailscale serve --bg 3000
tailscale serve status
```

表示されたHTTPS URLをスマホで開きます。TailscaleログインとGriefGuard管理パスワードは別の認証です。

## 失敗時

| 表示 | 確認する場所 |
|---|---|
| `npm`が見つからない | インストーラー版を使うか、Node.js LTSを導入する |
| `Connection refused 25501` | Agentを先に起動し、Bridgeを127.0.0.1:25501にする |
| `config.yml が見つからない` | Paperを一度起動し、`plugins/GriefGuard/`を生成させる |
| `session.lock` | 同じワールドを使用中のPaperを完全に停止する |
| アプリへ接続できない | Agent稼働、Tailscale接続、HTTPS URL、管理パスワードを順に確認する |
