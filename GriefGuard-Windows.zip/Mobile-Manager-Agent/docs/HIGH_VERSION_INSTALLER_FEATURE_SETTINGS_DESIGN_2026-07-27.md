# GriefGuard HighVersion インストーラー機能設定 設計書

作成日: 2026-07-27  
対象: GriefGuard HighVersion / Windows・macOSインストーラー / Agent / Webアプリ  
状態: 設計のみ（本書の作成時点では未実装）

## 1. 目的

HighVersionの導入時に、次の設定をインストーラーから安全かつ簡単に決められるようにする。

1. 通常プレイヤーが自動的に「緩和」へ移行するまでの日数
2. HighVersion専用機能ごとのON / OFF
3. 再インストール・修復・更新時にも既存設定を勝手に初期化しない仕組み
4. インストーラー、Plugin、Agent、Webアプリで同じ設定状態を表示する仕組み

通常版にはHighVersion専用画面を表示せず、専用設定も書き込まない。

## 2. 現状と不足点

現在の`config.yml`には、HighVersion専用の次の設定がある。

- 接続履歴
- 同一接続元による関連アカウント候補
- 短時間の大量接続に対する接続防御

ただし、現在はインストーラー内で選択できず、各機能の有効状態もアプリへ十分に通知されない。また、DBの`certified_days`は存在するが、「何を1日として数えるか」「何日で緩和にするか」「手動設定とどう共存するか」が定義されていない。

したがって、日数入力欄だけを追加せず、緩和判定そのものを一つの機能として設計する。

## 3. インストーラーに追加する画面

Plugin配置の後、Paper初回起動の前に、HighVersionのJARを検出した場合だけ「HighVersion専用機能」ステップを表示する。

### 3.1 画面構成

最初に、次の4項目をカード形式で表示する。

| 項目 | 新規導入時の推奨初期値 | 説明 |
|---|---:|---|
| 接続履歴 | ON | ログイン日時、接続結果、client brandなどをローカルDBへ保存する |
| 関連アカウント候補 | OFF | 同じ接続元を使ったプレイヤーを候補として表示する。自動処罰はしない |
| 接続防御 | ON | 短時間の大量接続を一時的に制限する |
| 自動緩和 | OFF | 条件を満たした通常プレイヤーを自動で緩和へ移行する |

プライバシーへの影響と意図しないプロフィール変更を避けるため、「関連アカウント候補」と「自動緩和」は新規導入時にOFFとする。既存環境では現在の設定を初期値として表示し、勝手に変更しない。

### 3.2 自動緩和をONにした時だけ表示する項目

必須項目:

- 緩和までの有効日数: 初期値14日、入力範囲1～365日

「詳細設定」を開いた場合だけ表示する項目:

- 1日として数える最低プレイ時間: 初期値30分、1～1440分
- 警告なしを求める直近日数: 初期値7日、0～365日
- 既存のプレイ履歴も日数に含める: 初期値OFF
- 緩和時にプレイヤーへ通知する: 初期値ON

0、負数、小数、空欄、上限超過は確定できないようにする。エラー時は入力欄の直下へ「1～365の整数で入力してください」のように原因を表示する。

### 3.3 専用機能の依存関係

- 「関連アカウント候補」は「接続履歴」がONの場合だけONにできる。
- 接続履歴をOFFにした時は、関連アカウント候補もOFFにして理由を表示する。
- 接続防御は他の項目から独立させる。
- IPのマスク表示は安全機能なのでOFF項目にしない。
- 永続IP BANは本設計の対象外とし、インストーラーにも表示しない。

### 3.4 最終確認

適用前に次の要約を表示する。

```text
HighVersion専用設定
  接続履歴             ON
  関連アカウント候補   OFF
  接続防御             ON
  自動緩和             ON
  緩和まで             有効日14日
  1日と数える条件      30分以上プレイ

この設定は plugins/GriefGuard/config.yml に保存されます。
反映にはPaperの再起動が必要です。
```

## 4. 「緩和までの日数」の定義

単純な初回ログインからの経過日数ではなく、「有効プレイ日」を数える。

有効プレイ日とは、サーバーのタイムゾーンにおける同一暦日の中で、設定した最低プレイ時間を満たした日である。同じ日に何度ログインしても1日として数える。

次の場合は日数を増やさない。

- OPである
- BAN中である
- 当日に必要なプレイ時間を満たしていない
- 自動緩和機能がOFF
- 管理者が手動で自動緩和を停止しているプレイヤー

警告が付いた場合、既定動作は累積日数のリセットではなく「条件を満たすまで一時停止」とする。過去の努力を突然消さず、誤検知の影響を小さくするためである。

## 5. 手動操作との共存

- アプリから手動で「緩和」にした場合は、その状態を優先する。
- アプリから手動で「通常」に戻した場合は、直後に再び自動緩和されないよう、自動緩和対象を一時停止する。
- プレイヤー詳細画面に「自動緩和を再開」を用意する。
- OPは検知プロフィールの対象外とし、自動緩和もしない。
- 自動緩和はNORMALからRELAXEDへの移行だけを行う。RELAXEDからNORMALへの自動降格は行わない。

プロフィール変更履歴には、`manual`、`automatic`、`installer-migration`の変更元を保存する。

## 6. 設定ファイル案

`plugins/GriefGuard/config.yml`のHighVersionブロックを次の形へ拡張する。

```yaml
high-version:
  connection-history:
    enabled: true
    retention-days: 30
    banned-attempt-retention-days: 90

  account-correlation:
    enabled: false
    same-address: true

  connection-defense:
    enabled: true
    per-second-limit: 8
    per-ten-seconds-limit: 30
    initial-block-seconds: 5
    permanent-ip-ban: false

  auto-relaxation:
    enabled: false
    required-eligible-days: 14
    minimum-active-minutes-per-day: 30
    warning-free-days: 7
    count-existing-history: false
    notify-player: true
```

設定値はPlugin起動時にも再検証する。不正値を読み込んだ場合は安全な初期値へ補正し、コンソールへ対象キーと補正後の値を警告表示する。

## 7. DB設計

現在の`certified_days`を無条件に増減させる方式は避け、重複集計を防ぐため日単位の記録を追加する。

### 7.1 新規テーブル

```sql
CREATE TABLE player_eligible_days (
  uuid TEXT NOT NULL,
  eligible_date TEXT NOT NULL,
  active_minutes INTEGER NOT NULL,
  warning_count INTEGER NOT NULL DEFAULT 0,
  qualified INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (uuid, eligible_date)
);
```

`certified_days`は互換用の集計値として維持し、新テーブルの有効日数から再計算可能にする。

### 7.2 `player_profiles`の追加情報

次を追加する。

- `change_source`: `manual` / `automatic` / `migration`
- `auto_relax_paused`: 0 / 1
- `auto_relaxed_at`: 自動緩和時刻

DB変更は追加型マイグレーションとし、既存の`data.db`を削除または再作成しない。

## 8. Plugin側の処理

1. プレイヤーの参加時刻を記録する。
2. 退出時と定期保存時に、その日の実プレイ時間を加算する。
3. 日付が変わった時、または退出時に有効日条件を確定する。
4. 必要日数へ到達したら、メインスレッドで一度だけRELAXEDへ変更する。
5. DB保存と監査ログを非同期化し、ログイン処理やプロフィール切替を止めない。
6. 同じプレイヤーへ重複した緩和処理を送らない。

Paper停止やクラッシュに備え、オンライン中の経過時間を定期チェックポイントへ保存する。

## 9. インストーラーから設定を適用する方法

### 9.1 HighVersion判定

フォルダ名や配布ZIP名ではなく、配置するPlugin JAR内の`edition.properties`を読み、`edition=high`の場合だけ専用ステップを出す。判定できない場合はStandardとして扱い、High設定を書き込まない。

### 9.2 適用順序

1. インストーラーで選択値を取得する。
2. 共通スキーマで値と依存関係を検証する。
3. Paper初回起動で`plugins/GriefGuard/config.yml`を生成する。
4. 既存configを日時付き`.bak`へバックアップする。
5. HighVersionブロックだけを差分更新する。
6. 保存後に読み直して一致を確認する。
7. 設定を有効にするためPaperを再起動する。

初回起動が完了しなかった場合は、管理ワークスペースの非公開状態ファイルに「適用待ち」として保存する。Agentがconfig生成を確認した時だけ適用し、成功後は適用待ちファイルを削除する。

### 9.3 再実行時

- 既存値を読み取り、現在値を選択済みで表示する。
- ユーザーが変更しなければconfigを書き換えない。
- HighVersionの更新だけで日数やON / OFFを初期値へ戻さない。
- config全体を作り直さず、HighVersionブロックだけを更新する。

## 10. Agent・Webアプリとの同期

BridgeのHELLOまたは状態応答へ、エディション能力とは別に現在の有効状態を追加する。

```json
{
  "edition": "high",
  "capabilities": [
    "player.connection-history",
    "player.account-correlation",
    "player.auto-relaxation",
    "security.connection-defense"
  ],
  "features": {
    "connectionHistory": true,
    "accountCorrelation": false,
    "connectionDefense": true,
    "autoRelaxation": true
  }
}
```

`capabilities`は「その製品で使用可能か」、`features`は「現在ONか」を表す。これを混同しない。

Webアプリの設定画面にも「HighVersion専用機能」を追加し、現在値、変更後の再起動要否、自動緩和までの残り有効日数を表示する。OFFの機能はボタンを消すだけでなく、「設定でOFF」と表示して故障と区別する。

## 11. 無効化時のデータ

- 接続履歴をOFFにした場合、新しい履歴の記録を止める。
- OFFにしただけでは既存履歴を削除しない。
- 関連アカウント候補をOFFにした場合、関連検索を停止する。
- 自動緩和をOFFにしても、既に緩和になったプレイヤーを通常へ戻さない。
- 既存データの削除は、確認操作を伴う別の「履歴を削除」機能として扱い、インストーラーでは自動実行しない。

## 12. 共通バリデーション

Plugin、Agent、インストーラーで同じ制約を使用する。

| 値 | 制約 |
|---|---|
| 緩和までの有効日数 | 1～365の整数 |
| 1日の最低プレイ時間 | 1～1440分の整数 |
| 警告なし日数 | 0～365の整数 |
| 接続履歴保持日数 | 1～3650日の整数 |
| 1秒の接続上限 | 1以上 |
| 10秒の接続上限 | 1秒上限以上 |
| 初回遮断秒数 | 1～3600秒 |

Node.js側にHighVersion設定スキーマを一つ作り、インストーラーとAgentで共有する。Java側にも同じ境界値を定数として持たせ、テストで差異を検出する。

## 13. 更新・版変更

### StandardからHighVersion

既存設定とDBを保持し、HighVersion項目だけを追加する。自動緩和は初期値OFFとし、管理者の確認なしに既存プレイヤーを緩和しない。

### HighVersionからStandard

HighVersion設定と履歴DBは削除しない。Standardでは無視し、アプリから専用画面を隠す。データ削除は別操作にする。

### HighVersionの再インストール

既存設定を優先し、不足キーだけを追加する。ON / OFFや必要日数を初期化しない。

## 14. テスト項目

### インストーラー

- Standard JARでは専用ステップが表示されない。
- HighVersion JARでだけ専用ステップが表示される。
- 0、負数、小数、366日を拒否する。
- 接続履歴OFF時に関連候補をONにできない。
- WindowsとmacOSで同じ設定結果になる。
- 再実行時に現在値が表示され、変更なしならファイル差分が出ない。
- 既存configのコメントとHighVersion以外の値を壊さない。

### Plugin

- 自動緩和OFFではプロフィールを変更しない。
- 指定日数未満では変更しない。
- 指定日数到達時に一度だけ緩和する。
- 同一日に複数回ログインしても日数は1だけ増える。
- 最低プレイ時間未満の日は数えない。
- OP、BAN、手動停止プレイヤーを対象外にする。
- 手動で通常へ戻した直後に自動緩和しない。
- 再起動、クラッシュ復旧後も日数が重複しない。

### Agent・アプリ

- 使用可能な機能と現在ONの機能を区別して表示する。
- 機能OFFを「Plugin Offline」と誤表示しない。
- 設定変更後に「保存済み・再起動待ち」を表示する。
- 自動緩和の進捗が「8 / 14有効日」のように確認できる。

## 15. 実装ロードマップ

1. HighVersion設定スキーマとconfig移行処理を作る。
2. 有効プレイ日DBと自動緩和エンジンをPluginへ追加する。
3. 手動変更優先、OP除外、監査ログを実装する。
4. Bridgeへ`features`と自動緩和進捗を追加する。
5. Agent APIとWebアプリ設定画面を追加する。
6. インストーラーへHighVersion判定・専用ステップ・差分保存を追加する。
7. Windows / macOS、新規 / 既存 / 再実行 / 版変更をテストする。
8. HighVersion配布フォルダ、ZIP、PDF、READMEを更新する。

## 16. 完了条件

- インストーラーだけでHighVersion専用機能のON / OFFと緩和日数を設定できる。
- 不正な日数を保存できない。
- 再インストールや更新で既存設定が消えない。
- Plugin、Agent、Webアプリが同じ有効状態を表示する。
- 手動プロフィール操作を自動処理が上書きしない。
- Standard版へHighVersion専用UIや処理が混入しない。

