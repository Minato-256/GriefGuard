# BlueMap 黒画面・継続読み込み・ブロック未反映の調査結果と修正計画

作成日: 2026-07-27  
対象: GriefGuard Mobile Manager / Installer / Paper updater / BlueMap連携

## 1. 結論

現状の症状は正常動作ではない。初回描画中や未描画地域へ移動した直後に短時間読み込むことは正常だが、同じ場所で読み込み表示が継続し、保存済みのブロック変更が長時間反映されない状態は修復対象とする。

今回のソース確認で、次の実装上の不足を確認した。

1. AgentのBlueMap正常判定が「設定ファイルが存在し、8100番ポートへTCP接続できること」だけになっている。
2. `settings.json`、マップ一覧、地図タイル、liveデータが正常に取得できるか確認していない。
3. Paperのバージョンが変わらない場合、Paper updaterはBlueMapの新しい修正版を確認しない。
4. BlueMap JARを更新しても、旧WebAppの`index.html`やブラウザーキャッシュとの互換性を修復する処理がない。
5. インストーラーの「BlueMap検証済み」はWebサーバーの起動確認であり、初回描画完了やブロック更新確認ではない。
6. アプリはBlueMap内部の読み込み失敗と正常な初回描画を区別できず、具体的な失敗箇所を表示できない。

以上から、現時点で最も可能性が高い原因は「BlueMap本体と生成済みWebAppの版不一致、または古いWebAppキャッシュ」と「描画状態を確認しないままAgentがreadyを返すこと」の複合である。

ただし、実際に症状が発生しているサーバーの`latest.log`、BlueMap設定、描画タスク状態がこのワークスペース内に存在しなかったため、そのサーバー固有の最終原因は修正版の診断機能または現地ログで確定する。

## 2. 正常と異常の判定

### 正常

- 初回導入後、生成済みチャンクを順番に描画している。
- 未描画地域へ視点を動かした直後だけ読み込みが表示される。
- Minecraft側でワールドがディスクへ保存された後、設定された更新待ち時間を経て変更が反映される。
- `/bluemap`と`/bluemap tasks`で処理中タスクと進捗が確認できる。

### 異常

- 同じ描画済み地点で数分待っても黒画面のまま。
- 読み込み表示が消えず、視点移動を繰り返した時だけ偶然表示される。
- ワールド保存後も置いたブロックが反映されない。
- BlueMapのWebサーバーは起動しているが、`settings.json`や地図タイルが404、5xx、タイムアウトになる。
- BlueMapの描画がstopまたはfreeze状態になっている。
- WebAppとBlueMap JARの版が一致していない。

## 3. 原因候補と優先度

### P0: ready判定が不十分

`/api/map-status`はBlueMapのポートへTCP接続できれば`ready: true`を返す。地図として使える状態かは確認していない。このため、WebAppの破損、設定ファイル不整合、地図データ未生成、タイル取得失敗でもアプリは地図を表示する。

### P0: BlueMap更新時のWebApp移行がない

BlueMapの一部リリースでは、JAR交換に加えてWebAppの`index.html`再生成が必要と公式に案内されている。現在のBlueMap InstallerはJARだけを交換し、生成済みWebAppを移行しない。古いJavaScriptと新しいBlueMapデータ形式が混在すると、黒画面、読み込み継続、更新されない表示につながる。

### P0: 同一Paper版ではBlueMap修正版を確認しない

Paper updaterはPaper版が変更された場合だけBlueMap Installerを呼ぶ。同じPaper版向けにBlueMapの不具合修正版が公開されても更新されない。

### P1: 描画停止・freeze・タスク詰まりを検出しない

`/bluemap stop`は再起動後も維持され、マップ単位のfreezeも永続化される。現在のAgentはこれらを表示しない。既存設定の`player-render-limit`によって、プレイヤー接続中だけ描画が止まる可能性も診断していない。

### P1: BlueMap直接配信とAgent代理配信の比較がない

BlueMapの`127.0.0.1:8100`では正常でも、Agentの`/map/`経由で一部リクエストだけ失敗する可能性を切り分けられない。現行代理配信はLocation、キャッシュ、圧縮済みタイル、liveデータごとの検証結果を記録しない。

### P1: ブラウザーキャッシュを更新する導線が弱い

BlueMap側の「Update Map」操作やWebApp更新後のキャッシュ更新がアプリ内で案内されない。iframeも同じURLを使い続けるため、古いWebAppを保持しやすい。

### P2: ワールド保存待ち

BlueMapはメモリ上のブロック変更ではなく保存されたワールドデータを読み取る。Paperの自動保存前なら反映に時間がかかる。ただし「いつまでも反映されない」症状は保存待ちだけでは説明しにくく、上記P0/P1を先に確認する。

## 4. 修正の技術要件

### 4.1 BlueMap診断API

`GET /api/map-diagnostics`を追加し、次を個別判定する。

- BlueMap JARのファイル名、SHA-256、管理対象版、導入日時
- Paper版、Java版、BlueMap版の対応関係
- `core.conf`の`accept-download`
- `webserver.conf`と`webapp.conf`のwebroot一致
- map設定ごとのworldパス、dimension、storage
- BlueMap直接URLの`/`、`/settings.json`のHTTP状態、応答時間、Content-Type
- Agent経由の`/map/`、`/map/settings.json`の状態と直接配信との差
- settings内のマップIDと、各マップのメタデータ・タイル・liveデータの取得状態
- 最新Paperログ内のBlueMap ERROR/WARN
- `plugins/BlueMap/web/index.html`などの生成日時とJAR更新日時の前後関係

単なるポート接続は`webserver-listening`とし、`ready`とは分離する。

### 4.2 状態モデル

最低限、次の状態を返す。

- `not-installed`
- `version-incompatible`
- `awaiting-consent`
- `config-invalid`
- `webserver-offline`
- `webapp-stale`
- `map-not-configured`
- `initial-rendering`
- `render-paused`
- `render-frozen`
- `tile-unavailable`
- `proxy-degraded`
- `ready`

`ready`はsettings、マップ情報、代表タイルまたは有効な未生成応答まで確認できた場合だけ使用する。

### 4.3 BlueMapの安全な更新

- Paper版が同じでも、起動前にBlueMapの新しい安定版を確認する。
- Paper版、Java版、BlueMap成果物種別（paper/spigot）を互換表で照合する。
- GitHubリリース本文の曖昧な正規表現だけで判断せず、GriefGuard側に検証済み互換マニフェストを持つ。
- 更新前にBlueMap JAR、設定、WebApp入口ファイルをバックアップする。
- レンダリング済み地図データ、world、storageを削除しない。
- WebApp再生成が必要な更新では、公式移行手順に従って`index.html`を退避し、BlueMapに再生成させる。
- 更新後にJAR版、WebApp生成日時、`settings.json`、代表マップデータを検証する。
- 検証失敗時はJARとWebApp入口を自動復元する。

### 4.4 Repair-BlueMapの再設計

現在の再インストール中心から診断・段階修復へ変更する。

1. 読み取り専用診断
2. バージョン互換性修復
3. WebApp再生成
4. 設定整合性修復
5. Paper一時起動
6. BlueMap Webサーバー確認
7. settingsとマップデータ確認
8. 初回描画状態の確認
9. 正常停止
10. 診断レポート保存

Paper起動中の場合は勝手にJARやWebAppを交換しない。停止確認とユーザー承認を経てから修復する。

### 4.5 Agentのリバースプロキシ

- `/map/`配下のLocationヘッダーを必要に応じて書き換える。
- `index.html`、`settings.json`、liveデータには再検証可能なキャッシュ設定を使う。
- 圧縮済み地図データの`Content-Encoding`、`Content-Length`、Range要求を保持する。
- クライアント切断時に上流リクエストを中止する。
- 上流タイムアウト、404、502を記録し、診断APIへ集計する。
- 直接配信と代理配信のレスポンスハッシュ・応答時間を比較するテストを追加する。

### 4.6 アプリUI

- BlueMap内部の読み込みと、GriefGuard側の状態確認を別表示にする。
- 30秒以上正常表示を確認できない場合、無期限のぐるぐる表示をやめる。
- 「初回描画中」「描画停止」「WebApp更新が必要」「代理配信エラー」を具体的に表示する。
- 「再診断」「地図を再読み込み」「キャッシュを無視して再読み込み」「修復手順を見る」を用意する。
- 地図iframeのURLへ診断セッション単位のバージョン値を付け、修復後に古いWebAppを再利用しない。
- 詳細欄に直接BlueMap応答、Agent経由応答、マップID、最終タイル更新時刻を表示する。

### 4.7 ブロック更新

- Paperの自動保存設定とBlueMapの`update-cooldown`を診断結果に表示する。
- `full-update-interval`、`player-render-limit`、freeze状態を確認する。
- 通常運用で変更ごとに`save-all`を強制しない。
- 手動診断として、保存済み変更に対する`/bluemap update <map-id> <x> <z> <radius>`を案内する。
- 更新後に対象タイルの更新日時またはハッシュが変化したかを検証する。

## 5. テスト要件

### 自動テスト

- BlueMap未導入、設定未生成、Webサーバー停止の各状態
- ポートは開くが`settings.json`が壊れている状態
- 古いWebAppと新しいJARの組み合わせ
- Paper版を変えずBlueMapだけ更新されるケース
- BlueMap更新後もレンダリング済み地図データが保持されること
- 直接BlueMap配信とAgent `/map/`代理配信の内容一致
- 404、502、15秒超過、圧縮済みタイル、Range要求
- WindowsとmacOSで同じ診断結果・修復フローになること

### 実Paperテスト

1. 対応対象PaperとBlueMapを隔離フォルダで起動する。
2. テストワールドの既知座標を初回描画する。
3. 代表タイルの存在とHTTP取得を確認する。
4. Minecraftコマンドで対象座標のブロックを変更する。
5. ワールド保存後、BlueMapの通常更新を待つ。
6. タイルの更新日時またはSHA-256が変わることを確認する。
7. Agent `/map/`経由でも同じ新しいタイルを取得できることを確認する。
8. PaperとAgentを再起動しても更新が維持されることを確認する。

### 回帰テスト

- マップ以外のコンソール、プレイヤー、設定、バックアップが従来通り動く。
- Standard版とHighVersion版で同じBlueMap連携を使える。
- Tailscale HTTPS、localhostの双方で地図を取得できる。
- Paper停止中は黒画面ではなく明示的な停止状態を表示する。

## 6. 実施ロードマップ

### Phase 1: 診断機能

診断API、ログ収集、ready判定の厳格化、UIのエラー表示を実装する。これにより現地環境で原因を確定できるようにする。

### Phase 2: 更新・移行修復

同一Paper版でのBlueMap更新確認、WebApp再生成、互換マニフェスト、ロールバックを実装する。

### Phase 3: Proxyとキャッシュ

Agent代理配信のヘッダー、タイムアウト、キャッシュ、エラー集計を修正する。

### Phase 4: 実ワールド更新試験

ブロック変更からタイル再生成までの実Paper試験を自動化し、対応Paper版ごとに実行する。

### Phase 5: 配布物

通常版・HighVersion版、Windows・macOSの配布物を再生成し、説明書へ診断・修復方法を追加する。

## 7. 完了条件

- 黒画面や継続読み込みを「正常」と誤判定しない。
- 読み込みが30秒以上継続した場合に具体的な原因を表示する。
- 保存済みブロック変更が通常更新で新しいタイルへ反映される。
- 同じPaper版でも必要なBlueMap修正版へ更新できる。
- BlueMap更新後にWebAppとJARの版不一致が残らない。
- 修復時にworld、レンダリング済み地図データ、BlueMap設定を失わない。
- localhostとTailscale HTTPSで同じ地図データが表示される。
