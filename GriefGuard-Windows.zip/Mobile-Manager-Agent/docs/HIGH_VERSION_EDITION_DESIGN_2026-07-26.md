# GriefGuard HighVersion Edition 基本設計・統合設計

作成日: 2026-07-26  
対象: Windows / macOS、Paper、GriefGuard Mobile Manager Agent  
設計対象リリース（仮）: `2026.08-high-preview.1`

## 0. この設計書の結論

HighVersion版は、旧`GriefGuard_HighVertion`をそのまま配布するのではなく、**現行GriefGuardを共通基盤として、HighVersion専用モジュールを追加した別エディション**として作る。

配布物は次の2系統に分ける。

```text
GriefGuard_Distribution/                  標準版。現在の操作感と機能を維持
GriefGuard_HighVersion_Distribution/      HighVersion版。高度な接続分析を追加
```

ただし、Plugin・Agent・インストーラーの基礎コードをコピーして別々に保守しない。共通コードを1つにし、ビルド時のエディション設定とPluginからのCapability通知で画面・API・同梱JARを切り替える。

HighVersion版の中心機能は次の4つとする。

1. プレイヤー接続履歴の詳細表示
2. 同一IP・同一サブネットによる関連アカウント候補の提示
3. VPN・Proxy・Hosting回線の参考リスク情報
4. 接続レート監視と、管理者が確認できるセキュリティイベント

これらは**自動的に処罰を確定する機能ではなく、管理者の判断を補助する機能**として設計する。

## 1. 現行版と旧HighVertionの調査結果

### 1.1 現行標準版を正本にする理由

現行標準版には、旧HighVertionより新しい次の実装がある。

- 全ワールド対応バックアップと、荒らし検知ワールド優先ロールバック
- ワールド数に応じた20 / 15 / 10世代の保存上限
- 通常・緩和プロファイル別の検知値
- 各検知項目のしきい値編集
- Agentとの現在のBridgeプロトコル
- Webアプリの5タブUI、BlueMap、プレイヤー・OP・ホワイトリスト管理
- Tailscale HTTPS、AgentData、セットアップコードによる認証
- Windows/macOSインストーラー、Paper更新、Java自動判定
- Paper 1.17.1 / 1.20.4 / 1.21.11 / 26.1.2の実起動試験

旧HighVertionのコードを正本に戻すと、上記の改善が失われる。したがって統合方向は必ず「標準版へHigh機能を移植」とする。

### 1.2 旧HighVertionにだけ実装されている主な機能

| 機能 | 旧実装 | HighVersionでの扱い |
| --- | --- | --- |
| `/trace <player>` | 接続履歴、GeoIP、ISP、同一IP候補をMarkdown化 | 再設計して採用。アプリUI中心に変更 |
| GeoIP / ISP / ASN | `ip-api.com`へHTTP送信 | そのまま不採用。HTTPS、同意、キャッシュ、無効化を必須化 |
| 同一IPアカウント候補 | SQLiteのlogin_historyを照合 | 採用。あくまで候補として表示 |
| 同一/24サブネット候補 | IPv4文字列の前方一致 | 改修して採用。IPv4/IPv6を正しくCIDR処理 |
| BAN後の再接続履歴 | banned_login_attemptsへ保存 | 採用。保存期間を設定可能にする |
| VPN/Hosting推測 | ISP文字列のキーワード判定 | 参考情報として採用。断定表示・自動BANは禁止 |
| 接続レート制限 | 1秒内のIP別接続数で永久IP BAN | 方式を変更して採用。短時間拒否→段階制、永久BANは手動 |
| Fake Crash | マルウェア感染や情報流出を装う切断文 | 不採用。安全な「接続拒否メッセージ」へ置換 |
| 調査レポート | Special内へ事件レポートを作成 | 不採用。既に削除方針のため復活させない |
| Plugin内Discord Bot | Token、password、channel-idを保持 | 不採用。現行Agentの通知設定へ統合 |
| VPS Launcher / TCP Proxy | Plugin JAR内Launcherが起動・Proxyを担当 | 不採用。現行AgentとTailscaleが担当 |
| 単一ワールドバックアップ | `backup.world-name`だけを保存 | 不採用。現行の全ワールド方式を使用 |

### 1.3 名前の扱い

利用者向け表記は誤字を直して`HighVersion`とする。旧実装の`HighVertion`は互換検出用のLegacy IDとしてのみ残す。

```text
表示名: GriefGuard HighVersion
edition id: high
legacy plugin id: GriefGuard_HighVertion
新Plugin name: GriefGuard
新データフォルダー: plugins/GriefGuard/
```

新HighVersion JARもPlugin名を`GriefGuard`にする。これにより標準版とHighVersion版を同時導入できず、重複監視・二重バックアップ・Bridge二重接続を構造的に防ぐ。

## 2. 製品構成

### 2.1 エディション構成

| 項目 | Standard | HighVersion |
| --- | --- | --- |
| 共通Plugin Core | 使用 | 使用 |
| 荒らし検知・バックアップ | 使用 | 使用 |
| Agent・Webアプリ | 使用 | 使用 |
| 接続履歴の詳細 | 最小限 | 詳細 |
| 関連アカウント候補 | 非表示 | 表示 |
| ネットワークリスク情報 | 非表示 | 任意で表示 |
| セキュリティイベント | 基本ログ | 専用画面・集計 |
| 外部GeoIP照会 | なし | 初期OFF・明示同意後のみ |
| 配布フォルダー | `GriefGuard_Distribution` | `GriefGuard_HighVersion_Distribution` |

### 2.2 推奨ソース構成

```text
GriefGuard_setting/
├─ GriefGuard/                         共通Plugin本体
│  ├─ core/                            検知、Backup、DB、Bridge
│  ├─ edition-standard/                StandardのCapability定義
│  └─ edition-high/                    High専用機能
│     ├─ ConnectionHistoryService
│     ├─ AccountCorrelationService
│     ├─ NetworkRiskService
│     └─ ConnectionDefenseService
├─ griefguard-ios-web/                 共通Agent / Web UI
│  ├─ lib/edition-capabilities.js
│  ├─ lib/high-version-service.js
│  └─ public/                          Capabilityに応じてUIを表示
└─ GriefGuard_HighVertion/             Legacy参照専用。新規機能追加を停止
```

最初の実装ではMavenのmulti-module化を急がず、現行`GriefGuard`内に`edition`パッケージを追加してよい。ただしHigh専用コードからBukkitのグローバル状態へ直接触れず、Coreが渡すInterface経由にする。

## 3. Plugin内部設計

### 3.1 EditionDescriptor

JAR内へ`griefguard-edition.json`を同梱する。

```json
{
  "edition": "high",
  "displayName": "GriefGuard HighVersion",
  "build": "2026.08-high-preview.1",
  "protocolVersion": 2,
  "configSchemaVersion": 5,
  "databaseSchemaVersion": 3,
  "capabilities": [
    "player.connection-history",
    "player.account-correlation",
    "security.network-risk",
    "security.connection-defense"
  ]
}
```

Standard JARでは`edition: standard`とし、High専用Capabilityを含めない。

### 3.2 High専用サービスの境界

```java
public interface EditionModule {
    String id();
    Set<String> capabilities();
    void onEnable(GriefGuardContext context);
    void onDisable();
}

public interface NetworkRiskProvider {
    CompletionStage<NetworkRiskResult> lookup(InetAddress address);
}
```

Core側はEdition IDを条件に具体クラスを直接呼ばない。`ServiceLoader`または明示FactoryでHighModuleを読み込む。HighModuleが失敗しても、荒らし検知・Backup・Bridgeは継続する。

### 3.3 Bridge Capability Handshake

PluginがAgentへ接続した直後、現在の`PLUGIN_ONLINE`通知より先に次を送る。

```json
{
  "type": "hello",
  "protocolVersion": 2,
  "plugin": "GriefGuard",
  "edition": "high",
  "build": "2026.08-high-preview.1",
  "configSchemaVersion": 5,
  "databaseSchemaVersion": 3,
  "capabilities": [
    "players.read",
    "players.profile.write",
    "player.connection-history",
    "player.account-correlation",
    "security.network-risk",
    "security.connection-defense"
  ]
}
```

Agentはフォルダー名やJAR名からHighVersionを推測しない。Handshakeを正本にする。未接続時は最後に確認したCapabilityを表示に使わず、High機能を「Plugin接続待ち」とする。

### 3.4 Bridgeメッセージ

既存の文字列コマンドは互換用に残すが、新機能はJSON request/responseへ移行する。

```json
{ "id": "req-123", "type": "request", "action": "player.securitySummary", "playerUuid": "..." }
{ "id": "req-123", "type": "response", "ok": true, "data": { } }
```

必要Action:

| Action | 内容 | 権限 |
| --- | --- | --- |
| `edition.describe` | EditionとCapability取得 | 認証済み管理者 |
| `player.securitySummary` | 接続回数、最終接続、リスク件数 | 認証済み管理者 |
| `player.connectionHistory` | ページング済み履歴 | セキュリティ閲覧権限 |
| `player.accountCorrelations` | 関連候補 | セキュリティ閲覧権限 |
| `player.networkRisk.refresh` | 外部照会を明示実行 | セキュリティ操作権限 |
| `security.events.list` | レート制限等のイベント | セキュリティ閲覧権限 |
| `security.connectionDefense.update` | 防御設定変更 | セキュリティ設定権限 |

各requestにID、5秒以内のACK、最大30秒の非同期完了通知を持たせる。10秒以上かかる外部照会はHTTPを待たせず`202 Accepted + jobId`にする。

## 4. データ設計

### 4.1 SQLiteスキーマ

現行`data.db`をそのまま使い、破壊的な別DBへ分割しない。`schema_meta`で移行状態を管理する。

```sql
CREATE TABLE IF NOT EXISTS schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS connection_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id TEXT NOT NULL UNIQUE,
  player_uuid TEXT,
  player_name TEXT,
  address_hash TEXT,
  encrypted_address BLOB,
  address_family INTEGER,
  client_brand TEXT,
  virtual_host TEXT,
  result TEXT NOT NULL,
  occurred_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS network_risk_cache (
  address_hash TEXT PRIMARY KEY,
  country_code TEXT,
  region_label TEXT,
  asn TEXT,
  organization TEXT,
  hosting_likelihood TEXT,
  provider TEXT,
  checked_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  player_uuid TEXT,
  address_hash TEXT,
  summary TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  resolved_at INTEGER,
  resolved_by TEXT
);
```

### 4.2 IPアドレスの扱い

IPは機微情報として扱う。

- 一覧画面では初期状態で`203.0.113.xxx`のようにマスクする
- 相関検索用には`HMAC-SHA-256(serverSecret, normalizedIp)`を保存する
- 生IPが必要な場合だけ、AgentData由来の鍵で暗号化して保存する
- Discord通知、通常ログ、WebSocket broadcastへ生IPを出さない
- 生IPの表示は「一時表示」操作と再認証を必要とし、監査ログを残す
- IPv4-mapped IPv6を正規化し、IPv4は/24、IPv6は/64の相関キーを別に作る
- 標準保存期間は30日、BAN再接続は90日、利用者が短縮可能
- 保存期限を過ぎた行は1日1回削除する

### 4.3 旧DBからの移行

旧`plugins/GriefGuard_HighVertion/data.db`がある場合は自動で上書き移行しない。

1. Paper停止を確認
2. DBとconfigを`migration-backup/<timestamp>/`へコピー
3. 旧テーブルを読み取り専用で検査
4. UUID、player_stats、login_history、banned_login_attemptsを新スキーマへ変換
5. IP保存について管理者へ同意画面を出す
6. 同意しない場合はプレイヤー統計だけ移行し、IP履歴は破棄
7. 件数、失敗行、ハッシュを`migration-result.json`へ記録
8. 成功後も旧フォルダーは自動削除しない

移行処理は再実行可能にし、`migration_id`の重複で二重登録を防ぐ。

## 5. HighVersion専用機能

### 5.1 接続履歴

プレイヤー詳細に次を表示する。

- 初回・最終接続日時
- ログイン成功回数、拒否回数
- Java / Bedrockの区分とclient brand
- 使用したホスト名
- 接続元のマスク表示
- 検知・BAN・ホワイトリスト・OP・通常/緩和の状態

履歴は20件単位でページングし、全件を一度にBridgeへ送らない。検索と並び替えはDB側で実行する。

### 5.2 関連アカウント候補

候補理由を分けて表示する。

| 理由 | 信頼度表示 | 注意 |
| --- | --- | --- |
| 同一IP | 強い関連候補 | 家族・学校・会社・VPN出口の可能性あり |
| 同一/24または/64 | 弱い関連候補 | 同一人物とは断定できない |
| 同一client brandのみ | 参考 | 処罰根拠にしない |
| 同一virtual hostのみ | 参考 | 通常は多数が一致する |

単一条件だけで自動BANしない。画面の見出しは「サブアカウント」ではなく「関連アカウント候補」とする。

### 5.3 Network Risk

外部照会は初期OFF。HighVersion初回設定で次を表示する。

```text
この機能を有効にすると、接続元IPを選択した外部事業者へ送信します。
利用者への告知、保存期間、事業者の利用規約を確認してください。
```

設計要件:

- HTTPS APIのみ
- 接続タイムアウト3秒、総タイムアウト5秒
- 24時間以上キャッシュ
- 同時照会数2、指数バックオフ
- Paperメインスレッドでは実行しない
- 失敗時は`不明`とし、安全と判定しない
- `VPN確定`ではなく`VPN/Hostingの可能性`と表示
- 自動BAN条件には使用しない

### 5.4 Connection Defense

旧実装の「1秒内に閾値へ到達したら永久IP BAN」はNAT環境で誤検知しやすいため採用しない。

段階制:

1. 1秒窓と10秒窓の両方を測定
2. 閾値到達で5秒間の一時拒否
3. 連続到達で30秒、5分へ延長
4. セキュリティイベントを記録
5. 永久IP BANは管理者の手動確認だけで実行

Proxy/Geyser/VPN構成では、信頼済みProxyの送信元だけForwarded IPを採用する。文字列にNULがあるだけで実IPとして信用しない。Paperのproxy設定と秘密鍵を検証できる方式に限定する。

### 5.5 Traceの置換

旧`/griefguard_highvertion trace`は次へ置換する。

```text
/griefguard security <player> summary
/griefguard security <player> refresh-risk
```

主操作はアプリのプレイヤー詳細から行う。Markdown調査レポートの自動生成は実装しない。管理者が明示的に「JSON/CSVエクスポート」を実行した場合のみ、個人情報を含む旨を確認して一時ファイルを作成し、10分後に削除する。

### 5.6 安全な接続拒否メッセージ

`fake-crash-message`は廃止し、次へ移行する。

```yaml
security:
  disconnect-message: "このサーバーの保護機能により接続が拒否されました。管理者へお問い合わせください。"
```

マルウェア感染、資格情報流出、PC破損を装う文言や、IP・都市名を表示する機能は統合しない。旧configに該当文面がある場合は移行ログへ警告し、安全な初期文へ置換する。

## 6. Webアプリ設計

### 6.1 Edition表示

上部のサーバー名付近へ小さなEditionバッジを表示する。

```text
STANDARD
HIGH VERSION
```

Plugin未接続時は`EDITION UNKNOWN`とし、High機能の値をキャッシュ表示しない。

### 6.2 管理タブ

既存のプレイヤーカードを押すと詳細Drawerを開く。

HighVersion時だけ次のセクションを追加する。

1. 概要: ログイン回数、最終接続、検知状態
2. 接続履歴: 日時、結果、マスク済み接続元、client brand
3. 関連候補: 理由、最終一致、注意文
4. Network Risk: 情報源、確認時刻、Hosting可能性
5. 管理操作: 通常/緩和、OP、ホワイトリスト、BAN

スマホではタブを横スクロールさせず、Accordionにする。ボタンは最低44×44px、Drawerは`100dvh`と`visualViewport`へ追従し、仮想キーボード表示中も検索欄と保存ボタンが見えるようにする。

### 6.3 セキュリティ画面

旧セキュリティタブを復活させず、統合済み「管理」ページ内にHighVersion用の「接続保護」Accordionを追加する。

- 24時間の拒否数
- 一時レート制限中の接続元数
- 未解決セキュリティイベント
- Network Risk照会のON/OFFと同意状態
- 保存期間
- 一時拒否の閾値

### 6.4 設定画面

`設定 → GriefGuard → HighVersion機能`を最下部へ追加する。CapabilityがないStandard版ではDOMごと生成しない。

入力規則:

| 項目 | 最小 | 最大 | 初期値 |
| --- | ---: | ---: | ---: |
| 1秒あたり接続 | 2 | 100 | 8 |
| 10秒あたり接続 | 5 | 500 | 30 |
| 一時拒否秒数 | 1 | 3600 | 5 |
| 接続履歴保存日数 | 1 | 365 | 30 |
| BAN再接続保存日数 | 1 | 730 | 90 |
| Network Riskキャッシュ時間 | 1 | 168 | 24 |

0や負数を許可しない。機能を止める場合は数値0ではなく専用ON/OFFを使う。

### 6.5 Agent API

追加エンドポイント:

```text
GET  /api/edition
GET  /api/players/:uuid/security-summary
GET  /api/players/:uuid/connections?cursor=...
GET  /api/players/:uuid/correlations?cursor=...
POST /api/players/:uuid/network-risk/refresh
GET  /api/security/events?status=open&cursor=...
PATCH /api/security/events/:id
GET  /api/settings/high-version
PUT  /api/settings/high-version
```

すべて既存の管理認証を必須にする。生IP表示、データエクスポート、Network Risk再照会は管理パスワード再入力または短時間のstep-up tokenを必須にする。

## 7. Agent設計

### 7.1 Edition Resolver

優先順位:

1. 接続中PluginのHandshake
2. JAR内`griefguard-edition.json`
3. Legacy移行時のみ`plugins/GriefGuard_HighVertion/`を検出
4. 不明

現在のように`plugins/GriefGuard/config.yml`を先に見つけ、なければHighVertionを使うだけの判定は廃止する。標準版の古いフォルダーが残っていても、接続中PluginのEditionを正しく選べるようにする。

### 7.2 Pluginデータへのアクセス

High機能のDBはAgentがSQLiteを直接読むのではなく、Plugin Bridge経由で取得する。Paper稼働中にAgentが同じDBへ接続するとロックや不整合の原因になるためである。

Paper停止時は「履歴はPlugin起動中のみ閲覧可能」と表示する。将来読み取り専用Snapshot APIを追加する場合も、Pluginが安全なSnapshotを作成してからAgentへ渡す。

### 7.3 遅延対策

- 一覧APIは300ms以内を目標
- DBクエリはインデックス必須
- 外部照会はjob化し、WebSocketで完了通知
- Bridge requestは5秒でACK、30秒で最終timeout
- Tailscale HTTPS越しでもHTTP接続を長時間保持しない
- UIはOptimistic更新を使う操作と、必ずサーバー確認を待つ操作を分ける

## 8. インストーラー設計

### 8.1 別配布物

```text
GriefGuard_HighVersion_Distribution/
├─ GriefGuard-HighVersion.jar
├─ GriefGuard_HighVersion_Manual_JA.pdf
├─ README_FIRST.txt
├─ Installers/
│  ├─ Windows/Start-GriefGuard-HighVersion-Setup.bat
│  └─ macOS/GriefGuard-HighVersion-Installer.pkg
└─ Mobile-Manager-Agent/
```

ファイル名は英数字を使用する。macOS PKGの表示名は日本語でもよいが、実ファイルはASCIIにする。

### 8.2 共通インストーラーCore

エディション別にセットアップ処理をコピーしない。起動ファイルが次のmanifestを渡す。

```json
{
  "edition": "high",
  "pluginArtifact": "GriefGuard-HighVersion.jar",
  "requiredCapabilities": ["security.connection-defense"],
  "manual": "GriefGuard_HighVersion_Manual_JA.pdf"
}
```

共通Wizardはmanifestを検証し、EditionとJARの組合せが不正なら開始しない。

### 8.3 インストール画面の追加ステップ

既存15ステップへHighVersion選択時だけ次を追加する。

1. HighVersion機能の説明
2. 接続履歴の保存期間
3. 外部Network Risk照会の同意（初期は「使用しない」）
4. Legacy HighVertion検出と移行選択
5. 移行プレビュー
6. 完了時のセキュリティ確認

### 8.4 既存標準版からHighVersionへ変更

1. PaperとAgentを停止
2. world、plugins/GriefGuard、AgentDataをバックアップ
3. 現在のJAR Editionを検査
4. Standard JARを日時付きバックアップへ退避
5. HighVersion JARを配置
6. 既存configへHigh専用キーを初期OFFで追加
7. DB migrationをTransactionで実行
8. Paperテスト起動
9. Handshakeが`edition=high`であることを確認
10. Agentを再起動し、Tailscale URLと管理パスワードが維持されたことを確認

失敗時はJAR、config、DBをまとめて元に戻す。JARだけを戻して新DBを残す部分ロールバックは禁止する。

### 8.5 旧HighVertionからの移行

両方のJARを同時配置しない。インストーラーが次を検出した場合にだけ移行を提案する。

```text
plugins/GriefGuard_HighVertion.jar
plugins/GriefGuard_HighVertion/config.yml
plugins/GriefGuard_HighVertion/data.db
```

移行マッピング:

| Legacy | 新HighVersion | 方針 |
| --- | --- | --- |
| `grief-detection.*` | 現行profiles/categories/thresholds | 現行schemaへ変換 |
| `rate-limiting.*` | `high-version.connection-defense.*` | 値を安全範囲へ補正 |
| `trace.save-to-file` | なし | 自動レポートを廃止 |
| `discord-webhook.*` | Agent Discord通知 | Token/URLは自動移行しない |
| `discord-bot.password` | なし | 破棄。ログへ値を出さない |
| `fake-crash-message` | `security.disconnect-message` | 安全な固定文へ置換 |
| `backup.world-name` | 現行全ワールド自動検出 | 移行しない |
| `backup.max-retention` | 現行20/15/10 | 移行しない |

### 8.6 更新

`Update-Paper`はEditionを維持する。StandardからHigh、HighからStandardへの変更はPaper更新では実行しない。エディション変更は専用の「Edition変更」手順だけで行う。

更新時に確認するもの:

- PaperとJava
- GriefGuard HighVersion互換版
- GeyserMC / Floodgate / ViaVersion / BlueMap
- DB schema migrationの必要性
- Agent protocol version

## 9. 設定schema

High専用設定例:

```yaml
edition:
  id: high

high-version:
  connection-history:
    enabled: true
    retention-days: 30
    banned-attempt-retention-days: 90
    store-raw-address: false
  account-correlation:
    enabled: true
    exact-address: true
    subnet: false
  network-risk:
    enabled: false
    provider: "none"
    cache-hours: 24
    auto-lookup-on-join: false
  connection-defense:
    enabled: true
    per-second-limit: 8
    per-ten-seconds-limit: 30
    initial-block-seconds: 5
    permanent-ip-ban: false
  privacy:
    mask-address-in-ui: true
    allow-raw-address-view: false
```

秘密情報はPlugin configへ保存しない。外部Provider API Keyが必要な場合はAgentData内のsecret storeへ保存し、PluginはAgentへ照会を依頼する。

## 10. Discord統合

HighVersion専用Discord Botを別に作らない。現行AgentのDiscord通知へ次のイベントを追加する。

| イベント | 初期値 | 推奨チャンネル | 初期閲覧 |
| --- | --- | --- | --- |
| 接続レート制限 | OFF | `#minecraft-serverdata` | 管理者 |
| BAN中プレイヤー再接続 | OFF | `#minecraft-grief` | 管理者 |
| 関連候補検出 | OFF | `#minecraft-grief` | 管理者 |
| Network Risk高 | OFF | `#minecraft-serverdata` | 管理者 |

通知本文に生IP、都市、ISP全文を含めない。プレイヤー名、イベントID、アプリ内詳細への導線だけを送る。Token、遠隔操作パスワード、channel-idの手入力は復活させない。

## 11. セキュリティ・法務・運用上の注意

- 接続履歴やIP相関は個人情報・プライバシー情報として扱う
- サーバールールまたはプライバシー説明に、保存目的と期間を明記する
- 関連候補、VPN/Hosting可能性だけで処罰しない
- 外部照会を使用する場合、送信先と目的を管理者へ表示する
- 生IPをDiscord、通常ログ、画面共有へ出さない
- 操作履歴へ「誰が、いつ、どのプレイヤーの詳細を開いたか」を残す
- Agentの3000、Bridgeの25501、BlueMapの8100をルーター公開しない
- Tailscale HTTPSと管理パスワードの二段階で保護する

## 12. テスト計画

### 12.1 Unit test

- IPv4 / IPv6正規化
- HMAC相関キー
- /24・/64判定
- 保存期間削除
- Connection Defense段階制
- configの最小/最大値
- CapabilityによるAPI許可/拒否
- Legacy config migration

### 12.2 Plugin結合試験

対象:

- Paper 1.17.1 + Java 17
- Paper 1.20.4 + Java 17
- Paper 1.21.11 + Java 21
- Paper 26.1.2 + Java 25

確認:

- Standard/Highそれぞれが起動
- HighModule失敗時もCore保護が継続
- SQLite migration後に既存プレイヤー情報が維持
- Geyser/Floodgate経由名とUUIDを正しく扱う
- 全ワールドBackupとロールバックが標準版と同じ
- 二重JARを検出して起動を安全に中断

### 12.3 Agent/API試験

- Standard接続時にHigh APIが404ではなく`capability_unavailable`を返す
- High接続時だけHigh UIが表示
- Plugin再接続後にEditionを再判定
- 10秒以上の外部処理をjob化
- Tailscale HTTPSでtimeoutしない
- 生IPがWebSocket、ログ、Discordへ漏れない

### 12.4 UI試験

- 390×844スマホ
- タブレット
- PC小画面＋仮想キーボード
- ライト/ダークの入力欄統一
- 44px以上の操作ボタン
- 長いBedrock名、先頭`.`、IPv6マスク、長いISP名

### 12.5 インストーラー試験

- Windows新規/既存/Standard→High/Legacy→High
- macOS新規/既存/Standard→High/Legacy→High
- Tailscale未導入からの再開
- Agent既起動時の二重起動防止
- Paper起動中の停止選択
- migration失敗時の完全ロールバック
- Windows/macOS ZIPの日本語文字化け確認

## 13. 実装ロードマップ

### Phase 0: Legacy凍結

- `GriefGuard_HighVertion`へ新機能を追加しない
- 調査レポート、旧Discord、Launcher、Fake Crashを移植対象外として固定
- Legacy DB/configのfixtureを作成

完了条件: 旧版から読み取るデータと、破棄する設定の一覧がテスト化されている。

### Phase 1: Edition基盤

- EditionDescriptor
- Capability Handshake v2
- Agent Edition Resolver
- Standard版が今までどおり動く後方互換試験

完了条件: StandardのUI・Plugin・インストーラーに機能退行がない。

### Phase 2: High Plugin Module

- 接続履歴
- HMAC/暗号化
- 相関候補
- Connection Defense
- DB migration

完了条件: 外部Network RiskなしでもHighVersionの主要機能が利用できる。

### Phase 3: Agent/API/UI

- High API
- プレイヤー詳細Drawer
- 接続保護Accordion
- 保存期間・同意UI
- WebSocket job通知

完了条件: StandardではHigh UIが存在せず、Highでは全機能が操作できる。

### Phase 4: Network Risk

- Provider Interface
- HTTPS Provider
- 同意・キャッシュ・timeout
- マスク表示とstep-up認証

完了条件: 外部送信OFFが初期値で、通信失敗がPaperやログインを妨げない。

### Phase 5: インストーラー・配布

- High manifest
- 別配布フォルダー
- Standard→HighとLegacy→Highの移行Wizard
- High専用PDF
- Windows/macOS ZIP、macOS PKG

完了条件: 既存Standard配布物を置換せず、両エディションを独立して配布できる。

### Phase 6: 実環境検証

- 4世代Paper matrix
- Windows実機
- macOS実機
- Java版のみ
- Java＋統合版
- Tailscale HTTPS
- 大規模履歴性能試験

完了条件: 全チェックが通り、Preview表記を外せる。

## 14. 変更予定ファイル

### Plugin

```text
GriefGuard_setting/GriefGuard/pom.xml
GriefGuard_setting/GriefGuard/src/main/resources/plugin.yml
GriefGuard_setting/GriefGuard/src/main/resources/config.yml
GriefGuard_setting/GriefGuard/src/main/resources/griefguard-edition.json
GriefGuard_setting/GriefGuard/src/main/java/.../edition/
GriefGuard_setting/GriefGuard/src/main/java/.../network/
GriefGuard_setting/GriefGuard/src/main/java/.../db/DatabaseManager.java
```

### Agent / Web

```text
GriefGuard_setting/griefguard-ios-web/server.js
GriefGuard_setting/griefguard-ios-web/lib/edition-capabilities.js
GriefGuard_setting/griefguard-ios-web/lib/high-version-service.js
GriefGuard_setting/griefguard-ios-web/public/index.html
GriefGuard_setting/griefguard-ios-web/public/app.js
GriefGuard_setting/griefguard-ios-web/public/styles.css
```

### Installer / Distribution

```text
GriefGuard_setting/griefguard-ios-web/scripts/setup-wizard.js
GriefGuard_setting/griefguard-ios-web/scripts/build-release.js
GriefGuard_setting/griefguard-ios-web/scripts/build-installer-distribution.js
GriefGuard_setting/griefguard-ios-web/installer/windows/
GriefGuard_setting/griefguard-ios-web/installer/macos/
GriefGuard_HighVersion_Distribution/
output/pdf/GriefGuard_HighVersion_導入・機能説明書.pdf
```

## 15. 完了条件

- 標準版の配布物・既存設定・操作感が変わらない
- HighVersionが別配布物として作成される
- Plugin HandshakeからEditionとCapabilityを判定できる
- StandardとHighVersionを同時導入できない
- 旧HighVertionから安全に移行でき、元へ戻せる
- 調査レポート、旧Discordパスワード、旧Launcher、誤解を招くFake Crashを復活させない
- High専用UIがStandardに表示されない
- IP等の情報が初期状態でマスクされ、保存期間と同意を管理できる
- Paper 1.17.1〜26.1.2の確認対象で起動できる
- WindowsとmacOSでインストーラー、Agent、Tailscale HTTPSが同じ操作感で使える
- HighVersion専用PDFだけで新規導入・移行・日常操作・復旧を行える

## 16. 実装開始前に固定する判断

次の既定値で実装を開始する。

1. HighVersionの外部Network Risk照会はOFF
2. 生IP保存はOFF、HMAC相関だけON
3. サブネット相関はOFF、同一IP相関だけON
4. 永久IP BANは自動実行しない
5. 接続履歴は30日、BAN再接続履歴は90日
6. Discord通知はすべてOFF
7. Legacy調査レポート、Fake Crash、Plugin内Discord Bot、VPS Launcherは統合しない

この7点を変える場合は、実装前にセキュリティ・プライバシー・誤検知リスクを再評価する。
