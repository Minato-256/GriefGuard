const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const net = require('net');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');
const { StringDecoder } = require('string_decoder');
const PluginBridge = require('./lib/plugin-bridge');
const { DATA_DIRECTORY, loadAgentConfig, saveAgentConfig, resolveMode } = require('./lib/agent-config');
const { POSITIVE_INTEGER_LIMITS, integer: schemaInteger, validateProfile } = require('./lib/griefguard-schema');
const { createAdapter, executeControl } = require('./lib/adapters');
const CommandJournal = require('./lib/command-journal');
const { parseYamlField, writeYamlField } = require('./lib/yaml-scalar');
const { detailsFor: blueMapDetailsFor, diagnose: diagnoseBlueMap, requestProbe: blueMapRequestProbe } = require('./lib/bluemap-diagnostics');

const app = express();
app.use(express.json());
app.use((req, res, next) => {
    if (req.path === '/' || /\.(?:html|css|js)$/.test(req.path)) {
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.set('Pragma', 'no-cache');
        res.set('Expires', '0');
    }
    next();
});
app.use(express.static(path.join(__dirname, 'public')));

let agentConfig = loadAgentConfig();
let agentMode = resolveMode(agentConfig);
// Each Agent writes a small runtime marker in its own AgentData directory.
// TestLab uses this marker to stop only the Agent it launched; it never
// guesses based on the shared default port (3000).
const AGENT_INSTANCE_ID = crypto.randomUUID();
const TESTLAB_SESSION_ID = String(process.env.GRIEFGUARD_TESTLAB_SESSION_ID || '').trim();
const TESTLAB_CLEANUP_TOKEN = String(process.env.GRIEFGUARD_TESTLAB_CLEANUP_TOKEN || '').trim();
const RUNTIME_FILE = path.join(DATA_DIRECTORY, 'runtime-instance.json');
const CONTROL_TOKEN_FILE = path.join(DATA_DIRECTORY, 'agent-control-token');
// A path fingerprint lets the installer tell whether an Agent listening on
// localhost belongs to the workspace it is currently configuring. The actual
// filesystem path is deliberately never exposed through the health endpoint.
const AGENT_DATA_ID = crypto.createHash('sha256').update(path.resolve(DATA_DIRECTORY)).digest('hex').slice(0, 24);
function controlToken() {
    try {
        const existing = fs.readFileSync(CONTROL_TOKEN_FILE, 'utf8').trim();
        if (/^[A-Za-z0-9_-]{40,}$/.test(existing)) return existing;
    } catch (_) {}
    const created = crypto.randomBytes(32).toString('base64url');
    fs.mkdirSync(DATA_DIRECTORY, { recursive: true, mode: 0o700 });
    fs.writeFileSync(CONTROL_TOKEN_FILE, `${created}\n`, { encoding: 'utf8', mode: 0o600 });
    try { fs.chmodSync(CONTROL_TOKEN_FILE, 0o600); } catch (_) {}
    return created;
}
const AGENT_CONTROL_TOKEN = controlToken();
const commandJournal = new CommandJournal(DATA_DIRECTORY);
// Lifecycle actions can take tens of seconds (and deliberately wait five
// seconds after a /say notice).  They must not hold an HTTPS request open.
// This map also prevents a second tap from starting a second Paper process.
const activeControlOperations = new Map();
function writeRuntimeMarker(port) {
    fs.mkdirSync(DATA_DIRECTORY, { recursive: true, mode: 0o700 });
    const marker = {
        product: 'GriefGuard Mobile Manager', instanceId: AGENT_INSTANCE_ID,
        pid: process.pid, port, startedAt: new Date().toISOString()
    };
    if (TESTLAB_SESSION_ID && TESTLAB_CLEANUP_TOKEN) {
        marker.testLabSessionId = TESTLAB_SESSION_ID;
        marker.cleanupToken = TESTLAB_CLEANUP_TOKEN;
    }
    fs.writeFileSync(RUNTIME_FILE, JSON.stringify(marker, null, 2) + '\n', { mode: 0o600 });
}
function removeRuntimeMarker() {
    try {
        const marker = JSON.parse(fs.readFileSync(RUNTIME_FILE, 'utf8'));
        if (marker.instanceId === AGENT_INSTANCE_ID) fs.rmSync(RUNTIME_FILE, { force: true });
    } catch (_) {}
}
const pluginBridge = new PluginBridge(agentConfig.bridge);
let platformAdapter = createAdapter(agentMode, agentConfig, pluginBridge);
function synchronizeLocalBridgeConfiguration() {
    const root = path.isAbsolute(agentConfig.serverDirectory)
        ? agentConfig.serverDirectory
        : path.resolve(__dirname, agentConfig.serverDirectory);
    const file = path.join(root, 'plugins', 'GriefGuard', 'config.yml');
    if (!fs.existsSync(file)) return { state: 'pending', file, reason: 'GriefGuardのconfig.ymlはPaper初回起動後に生成されます。' };
    try {
        const original = fs.readFileSync(file, 'utf8');
        let next = writeYamlField(original, 'discord-bot.bridge-mode', true);
        next = writeYamlField(next, 'discord-bot.vps-ip', '127.0.0.1');
        next = writeYamlField(next, 'discord-bot.bridge-port', Number(agentConfig.bridge?.port || 25501));
        if (next !== original) fs.writeFileSync(file, next, 'utf8');
        return { state: 'ready', file, changed: next !== original, reason: next !== original ? 'Agent起動時にPlugin Bridge設定を同期しました。Paperの次回起動で反映されます。' : 'Plugin Bridge設定は同期済みです。' };
    } catch (error) {
        return { state: 'error', file, reason: `Plugin Bridge設定を確認できません: ${error.message}` };
    }
}
const bridgeConfiguration = synchronizeLocalBridgeConfiguration();
let wss = null;
let latestPluginStatus = null;
const blueMapProxyStats = { requests: 0, failures: 0, tileMisses: 0, lastError: null, lastErrorAt: null };
let latestPlayerDirectory = [];
let previousCpuSnapshot = null;
let paperLogTailActive = false;
let paperLogOffset = 0;
let paperLogIdentity = null;
let paperLogRemainder = '';
let paperLogDecoder = new StringDecoder('utf8');

pluginBridge.on('log', message => {
    // LocalProcessAdapter can read Paper's canonical latest.log, which includes
    // command output that the Bukkit JUL handler does not receive. Prefer that
    // source locally so the same line is not broadcast twice.
    if (agentMode !== 'plugin-only' || !paperLogTailActive) {
        broadcast({ type: 'log', level: 'info', message });
    }
});
pluginBridge.on('result', message => broadcast({ type: 'log', level: 'success', message }));
pluginBridge.on('status', status => broadcast({ type: 'plugin_status', ...status }));
pluginBridge.on('server_status', status => {
    latestPluginStatus = status;
    broadcast({ type: 'server_status', ...status });
});
pluginBridge.on('hello', hello => broadcast({ type: 'plugin_hello', hello }));
pluginBridge.on('player_directory', directory => {
    latestPlayerDirectory = Array.isArray(directory) ? directory : [];
    broadcast({ type: 'players_changed' });
});
pluginBridge.on('player_update', update => {
    const index = latestPlayerDirectory.findIndex(entry => String(entry?.uuid).toLowerCase() === String(update.uuid).toLowerCase());
    if (index >= 0) latestPlayerDirectory[index] = { ...latestPlayerDirectory[index], ...update };
    else latestPlayerDirectory.push(update);
    broadcast({ type: 'player_updated', player: update });
});
pluginBridge.on('ban', event => broadcast({ type: 'ban_changed', ...event }));
pluginBridge.start();

function broadcast(payload) {
    if (!wss) return;
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN && client.isAuthorized) client.send(JSON.stringify(payload));
    });
}

function controlChannel(command) {
    return /^\/(start|stop|restart)$/i.test(String(command || '')) ? 'agent-control' : 'plugin-bridge';
}

function controlOperationKey(command) {
    const normalized = String(command || '').trim().toLowerCase();
    // Starting while stopping/restarting is just as dangerous as pressing the
    // same button twice, so all lifecycle commands share one lock.
    return /^(\/start|\/stop|\/restart)$/.test(normalized) ? 'paper-lifecycle' : null;
}

function queueControlOperation({ command, reasonCode, device }) {
    const key = controlOperationKey(command);
    const existing = key ? activeControlOperations.get(key) : null;
    if (existing) return { accepted: true, duplicate: true, event: existing.event };

    const before = commandJournal.record({ command, source: 'mobile-app', device, status: 'queued', channel: controlChannel(command), message: 'Agentが操作を受け付けました。' });
    const operation = { event: before, startedAt: Date.now() };
    if (key) activeControlOperations.set(key, operation);
    broadcast({ type: 'command_event', event: before });

    setImmediate(async () => {
        const running = commandJournal.update(before.id, { status: 'running', message: '処理中です。完了までこの画面を閉じても操作は継続します。' });
        operation.event = running || before;
        if (running) broadcast({ type: 'command_event', event: running });
        try {
            const result = await executeControl(platformAdapter, command, { reasonCode });
            const entry = commandJournal.update(before.id, {
                status: 'success', channel: controlChannel(command), message: result.message || '操作が完了しました。'
            });
            operation.event = entry || operation.event;
            if (entry) broadcast({ type: 'command_event', event: entry });
        } catch (error) {
            const entry = commandJournal.update(before.id, {
                status: 'failed', channel: controlChannel(command), message: error.message || '操作に失敗しました。'
            });
            operation.event = entry || operation.event;
            if (entry) broadcast({ type: 'command_event', event: entry });
        } finally {
            if (key && activeControlOperations.get(key) === operation) activeControlOperations.delete(key);
        }
    });
    return { accepted: true, duplicate: false, event: before };
}

function disconnectAuthorizedClients(reason) {
    if (!wss) return;
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN && client.isAuthorized) client.close(4001, reason);
    });
}

function publicAgentInfo(status = null) {
    const plugin = pluginBridge.getStatus();
    const paperState = status?.state || 'unknown';
    const paperOnline = paperState === 'online' || paperState === 'running';
    const bridgeOnline = Boolean(plugin.connected);
    const overall = paperOnline ? (bridgeOnline ? 'healthy' : 'bridge-disconnected') :
        (paperState === 'offline' || paperState === 'stopped' ? 'paper-stopped' : 'unknown');
    return {
        name: agentConfig.displayName,
        mode: agentMode,
        platform: process.platform,
        capabilities: platformAdapter.capabilities(),
        local: agentConfig.local,
        plugin,
        status,
        health: {
            overall,
            paperOnline,
            bridgeOnline,
            bridgeConfiguration,
            tailscaleConfigured: Boolean(agentConfig.access?.tailscaleDnsName),
            reason: overall === 'healthy' ? 'Agent・Paper・GriefGuard Pluginは接続済みです。'
                : overall === 'paper-stopped' ? 'Paperは停止中です。起動後にGriefGuard Pluginの接続を待機します。'
                : overall === 'bridge-disconnected' ? `Paperは起動中ですが、GriefGuard PluginがAgentへ接続していません。${bridgeConfiguration.reason ? ` ${bridgeConfiguration.reason}` : ''}`
                : 'Paperの状態を確認中です。'
        }
    };
}

function serverPath(...segments) {
    const root = path.isAbsolute(agentConfig.serverDirectory)
        ? agentConfig.serverDirectory
        : path.resolve(__dirname, agentConfig.serverDirectory);
    return path.join(root, ...segments);
}

function resetPaperLogDecoder() {
    paperLogRemainder = '';
    paperLogDecoder = new StringDecoder('utf8');
}

function broadcastPaperLogLine(line) {
    if (!line) return;
    const match = line.match(/^\[(\d{2}:\d{2}:\d{2})\] \[[^\]]+\/(TRACE|DEBUG|INFO|WARN|ERROR|FATAL)\]:\s?(.*)$/);
    const levelName = match?.[2] || 'INFO';
    const level = ['ERROR', 'FATAL'].includes(levelName) ? 'error' : (levelName === 'WARN' ? 'warn' : 'info');
    const rawMessage = match ? match[3] : line;
    // BlueMap intentionally saves once during its startup in the supplied
    // configuration to verify level.dat. Paper reports this class of normal
    // plugin initialization action as a WARN, but it is not a data-loss event.
    const isBlueMapStartupSave = rawMessage === 'A manual (plugin-induced) save has been detected while server is configured to auto-save. This may affect performance.';
    const message = isBlueMapStartupSave
        ? `[Paper/初期化] プラグイン初期化時の保存です（Paperの自動保存は変更していません）。`
        : (match ? `[Paper/${levelName}] ${rawMessage}` : line);
    broadcast({ type: 'log', level: isBlueMapStartupSave ? 'info' : level, message });
}

function pollPaperLog() {
    if (agentMode !== 'plugin-only') {
        paperLogTailActive = false;
        return;
    }
    const logPath = serverPath('logs', 'latest.log');
    try {
        const stat = fs.statSync(logPath);
        const identity = `${stat.dev}:${stat.ino}`;
        if (paperLogIdentity === null) {
            // Agent startup should not replay an entire existing log.
            paperLogIdentity = identity;
            paperLogOffset = stat.size;
            resetPaperLogDecoder();
        } else if (identity !== paperLogIdentity || stat.size < paperLogOffset) {
            // Paper creates/truncates latest.log during a restart. Stream the new
            // startup from its beginning so the mobile console shows progress.
            paperLogIdentity = identity;
            paperLogOffset = 0;
            resetPaperLogDecoder();
        }
        paperLogTailActive = true;
        if (stat.size <= paperLogOffset) return;

        const length = Math.min(stat.size - paperLogOffset, 512 * 1024);
        const fd = fs.openSync(logPath, 'r');
        const buffer = Buffer.allocUnsafe(length);
        let bytesRead;
        try {
            bytesRead = fs.readSync(fd, buffer, 0, length, paperLogOffset);
        } finally {
            fs.closeSync(fd);
        }
        if (bytesRead <= 0) return;
        paperLogOffset += bytesRead;
        const text = paperLogRemainder + paperLogDecoder.write(buffer.subarray(0, bytesRead));
        const lines = text.split(/\r?\n/);
        paperLogRemainder = lines.pop() || '';
        lines.forEach(broadcastPaperLogLine);
    } catch (error) {
        if (error.code !== 'ENOENT') console.warn('[PaperLog] ' + error.message);
        paperLogTailActive = false;
    }
}

pollPaperLog();
setInterval(pollPaperLog, 500).unref();

function getHostMetrics() {
    const snapshot = os.cpus().map(cpu => ({ idle: cpu.times.idle, total: Object.values(cpu.times).reduce((sum, value) => sum + value, 0) }));
    let cpu = null;
    if (previousCpuSnapshot && previousCpuSnapshot.length === snapshot.length) {
        let idleDelta = 0;
        let totalDelta = 0;
        snapshot.forEach((current, index) => {
            idleDelta += Math.max(0, current.idle - previousCpuSnapshot[index].idle);
            totalDelta += Math.max(0, current.total - previousCpuSnapshot[index].total);
        });
        if (totalDelta > 0) cpu = Math.round((1 - idleDelta / totalDelta) * 100);
    }
    previousCpuSnapshot = snapshot;
    const total = os.totalmem();
    const used = Math.max(0, total - os.freemem());
    return { cpu, ramUsedBytes: used, ramTotalBytes: total, ramPct: total ? Math.round(used / total * 100) : 0 };
}

fs.mkdirSync(DATA_DIRECTORY, { recursive: true, mode: 0o700 });
const SESSION_FILE = path.join(DATA_DIRECTORY, '.agent-sessions.json');
const PASSWORD_RESET_FILE = path.join(DATA_DIRECTORY, '.password-reset.json');
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

function sessionHash(token) {
    return crypto.createHash('sha256').update(String(token || ''), 'utf8').digest('hex');
}

function loadSessions() {
    const sessions = new Map();
    try {
        if (!fs.existsSync(SESSION_FILE)) return sessions;
        const saved = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
        const now = Date.now();
        Object.entries(saved.sessions || {}).forEach(([hash, expiresAt]) => {
            if (/^[a-f0-9]{64}$/.test(hash) && Number(expiresAt) > now) sessions.set(hash, Number(expiresAt));
        });
    } catch (error) {
        console.warn('[Auth] Failed to load persisted sessions:', error.message);
    }
    return sessions;
}

const activeSessions = loadSessions();

function persistSessions() {
    const now = Date.now();
    for (const [hash, expiresAt] of activeSessions) {
        if (expiresAt <= now) activeSessions.delete(hash);
    }
    const payload = JSON.stringify({ version: 1, sessions: Object.fromEntries(activeSessions) }, null, 2) + '\n';
    fs.writeFileSync(SESSION_FILE, payload, { encoding: 'utf8', mode: 0o600 });
    try { fs.chmodSync(SESSION_FILE, 0o600); } catch (_) {}
}

function issueSession() {
    const token = 'gg_token_' + crypto.randomBytes(32).toString('base64url');
    activeSessions.set(sessionHash(token), Date.now() + SESSION_TTL_MS);
    while (activeSessions.size > 100) activeSessions.delete(activeSessions.keys().next().value);
    persistSessions();
    return token;
}

function isActiveSession(token) {
    if (!token) return false;
    const hash = sessionHash(token);
    const expiresAt = activeSessions.get(hash);
    if (!expiresAt) return false;
    if (expiresAt <= Date.now()) {
        activeSessions.delete(hash);
        persistSessions();
        return false;
    }
    return true;
}

function revokeSession(token) {
    if (token && activeSessions.delete(sessionHash(token))) persistSessions();
}

const PASSWORD_SCRYPT_N = 16384;
const SETUP_CODE_TTL_MS = 10 * 60 * 1000;
const CODE_MAX_ATTEMPTS = 5;
const LOGIN_WINDOW_MS = 5 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = 5;
const loginAttempts = new Map();
let setupChallenge = null;
let passwordChangeChallenge = null;
let lastSetupCodeRequestAt = 0;
let lastLocalSetupCodeIssueAt = 0;
let lastLocalPasswordResetIssueAt = 0;
const LOCAL_CONTROL_CODE_INTERVAL_MS = 30 * 1000;
const INSTALLER_BOOTSTRAP_FILE = process.env.GRIEFGUARD_INSTALLER_BOOTSTRAP_FILE || path.join(DATA_DIRECTORY, 'installer-bootstrap.json');

function hashPassword(password) {
    const salt = crypto.randomBytes(16);
    const derived = crypto.scryptSync(String(password), salt, 64, { N: PASSWORD_SCRYPT_N, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
    return `scrypt$${PASSWORD_SCRYPT_N}$8$1$${salt.toString('base64url')}$${derived.toString('base64url')}`;
}

function verifyPassword(password, encoded = agentConfig.auth?.passwordHash) {
    try {
        const [algorithm, n, r, p, saltValue, hashValue] = String(encoded || '').split('$');
        if (algorithm !== 'scrypt' || !saltValue || !hashValue) return false;
        const expected = Buffer.from(hashValue, 'base64url');
        const actual = crypto.scryptSync(String(password || ''), Buffer.from(saltValue, 'base64url'), expected.length, {
            N: Number(n), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024
        });
        return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
    } catch (_) {
        return false;
    }
}

function passwordPolicyError(password) {
    const value = String(password || '');
    const length = Array.from(value).length;
    if (length < 12) return '管理パスワードは12文字以上にしてください。';
    if (length > 128 || Buffer.byteLength(value, 'utf8') > 256) return '管理パスワードが長すぎます。';
    const categories = [/[a-z]/.test(value), /[A-Z]/.test(value), /\d/.test(value), /[^A-Za-z0-9]/.test(value)].filter(Boolean).length;
    if (categories < 3 && length < 20) return '英大文字・英小文字・数字・記号のうち3種類を使うか、20文字以上のパスフレーズにしてください。';
    if (new Set(Array.from(value)).size < 6) return '同じ文字の繰り返しではないパスワードを設定してください。';
    return null;
}

function hasAdminPassword() {
    return String(agentConfig.auth?.passwordHash || '').startsWith('scrypt$');
}

function readInstallerBootstrap() {
    try {
        const value = JSON.parse(fs.readFileSync(INSTALLER_BOOTSTRAP_FILE, 'utf8'));
        if (typeof value.token !== 'string' || value.token.length < 32 || Number(value.expiresAt) <= Date.now()) return null;
        return value;
    } catch (_) { return null; }
}

function isLoopbackAddress(address) {
    return address === '::1' || address === '127.0.0.1';
}

function generateConsoleCode(prefix) {
    const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let value = '';
    for (let index = 0; index < 8; index++) value += alphabet[crypto.randomInt(alphabet.length)];
    return `${prefix}-${value.slice(0, 4)}-${value.slice(4)}`;
}

function createChallenge(prefix) {
    const code = generateConsoleCode(prefix);
    return { code, hash: sessionHash(code), expiresAt: Date.now() + SETUP_CODE_TTL_MS, attempts: 0 };
}

function challengeMatches(challenge, code) {
    if (!challenge || challenge.expiresAt <= Date.now() || challenge.attempts >= CODE_MAX_ATTEMPTS) return false;
    challenge.attempts += 1;
    const provided = Buffer.from(sessionHash(String(code || '').trim().toUpperCase()), 'hex');
    const expected = Buffer.from(challenge.hash, 'hex');
    return provided.length === expected.length && crypto.timingSafeEqual(provided, expected);
}

function printConsoleCode(title, challenge) {
    console.log('==================================================');
    console.log(` ${title}`);
    console.log(` Code: ${challenge.code}`);
    console.log(' 有効期限: 10分 / 1回限り / 最大5回まで');
    console.log(' このコードはアプリ画面やチャットへ公開しないでください。');
    console.log('==================================================');
}

function issueSetupChallenge() {
    setupChallenge = createChallenge('GG');
    lastSetupCodeRequestAt = Date.now();
    printConsoleCode('GriefGuard 初回セットアップコード', setupChallenge);
}

function issuePasswordChangeChallenge() {
    passwordChangeChallenge = createChallenge('PW');
    printConsoleCode('GriefGuard 管理パスワード変更確認コード', passwordChangeChallenge);
}

function readPasswordResetChallenge() {
    try {
        const challenge = JSON.parse(fs.readFileSync(PASSWORD_RESET_FILE, 'utf8'));
        const valid = /^[a-f0-9]{64}$/.test(String(challenge.hash || ''))
            && Number(challenge.expiresAt) > Date.now()
            && Number(challenge.attempts) < CODE_MAX_ATTEMPTS;
        if (valid) return challenge;
        try { fs.unlinkSync(PASSWORD_RESET_FILE); } catch (_) {}
    } catch (error) {
        if (error.code !== 'ENOENT') console.warn('[Auth] Failed to read password reset challenge:', error.message);
    }
    return null;
}

function savePasswordResetChallenge(challenge) {
    fs.writeFileSync(PASSWORD_RESET_FILE, JSON.stringify(challenge, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
    try { fs.chmodSync(PASSWORD_RESET_FILE, 0o600); } catch (_) {}
}

function consumePasswordResetChallenge(code) {
    const challenge = readPasswordResetChallenge();
    if (!challenge) return { valid: false, exhausted: true };
    challenge.attempts = Number(challenge.attempts) + 1;
    const provided = Buffer.from(sessionHash(String(code || '').trim().toUpperCase()), 'hex');
    const expected = Buffer.from(challenge.hash, 'hex');
    const valid = provided.length === expected.length && crypto.timingSafeEqual(provided, expected);
    if (valid || challenge.attempts >= CODE_MAX_ATTEMPTS) {
        try { fs.unlinkSync(PASSWORD_RESET_FILE); } catch (_) {}
    } else {
        savePasswordResetChallenge(challenge);
    }
    return { valid, exhausted: !valid && challenge.attempts >= CODE_MAX_ATTEMPTS };
}

function issuePasswordResetChallenge() {
    const challenge = createChallenge('RS');
    savePasswordResetChallenge({
        version: 1,
        hash: challenge.hash,
        expiresAt: challenge.expiresAt,
        attempts: 0
    });
    return challenge;
}

// One-time migration for existing installations. Plaintext is removed from
// agent-config.json immediately after a scrypt verifier has been created.
if (!hasAdminPassword() && typeof agentConfig.auth?.password === 'string' && agentConfig.auth.password) {
    agentConfig = saveAgentConfig({ auth: { password: null, passwordHash: hashPassword(agentConfig.auth.password) } });
    console.log('[Auth] Existing plaintext management password migrated to scrypt.');
}
if (!hasAdminPassword()) {
    activeSessions.clear();
    persistSessions();
    issueSetupChallenge();
}

function loginRateLimited(address) {
    const entry = loginAttempts.get(address);
    if (!entry) return false;
    if (entry.blockedUntil > Date.now()) return true;
    if (Date.now() - entry.windowStartedAt > LOGIN_WINDOW_MS) loginAttempts.delete(address);
    return false;
}

function recordLoginFailure(address) {
    const now = Date.now();
    let entry = loginAttempts.get(address);
    if (!entry || now - entry.windowStartedAt > LOGIN_WINDOW_MS) entry = { failures: 0, windowStartedAt: now, blockedUntil: 0 };
    entry.failures += 1;
    if (entry.failures >= LOGIN_MAX_ATTEMPTS) entry.blockedUntil = now + LOGIN_WINDOW_MS;
    loginAttempts.set(address, entry);
}

function loginResponse(token) {
    return { token, config: { windowsIp: agentConfig.windows.launcherHost, vpsIp: agentConfig.bridge.host }, agent: publicAgentInfo() };
}

function clientAddress(req) {
    return String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
}

function ipv4Number(address) {
    const parts = address.split('.').map(Number);
    if (parts.length !== 4 || parts.some(part => !Number.isInteger(part) || part < 0 || part > 255)) return null;
    return (((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3]) >>> 0;
}

function isAllowedClient(address) {
    if (address === '::1' || address === '127.0.0.1') return true;
    const numeric = ipv4Number(address);
    if (numeric === null) return false;
    const tailscale = numeric >= ipv4Number('100.64.0.0') && numeric <= ipv4Number('100.127.255.255');
    const local = address.startsWith('10.') || address.startsWith('192.168.') || /^172\.(1[6-9]|2\d|3[01])\./.test(address);
    return (agentConfig.auth.allowTailscale !== false && tailscale) || (agentConfig.auth.allowLocalNetwork !== false && local);
}

app.get('/api/access-info', (req, res) => {
    const dnsName = String(agentConfig.access?.tailscaleDnsName || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
    return res.json({
        mode: 'local-and-tailscale',
        currentUrl: `${req.protocol}://${req.get('host')}`,
        tailscaleUrl: dnsName ? `${agentConfig.access?.https === false ? 'http' : 'https'}://${dnsName}` : null,
        tailscaleConfigured: Boolean(dnsName),
        serveCommand: 'tailscale serve --bg 3000'
    });
});

function blueMapDetails() {
    const root = path.isAbsolute(agentConfig.serverDirectory) ? agentConfig.serverDirectory : path.resolve(__dirname, agentConfig.serverDirectory);
    const details = blueMapDetailsFor(root);
    return { ...details, url: '/map/', status: String(details.installerState.status || ''), managed: details.installerState.managed === true };
}

function isBlueMapListening(details) {
    return new Promise(resolve => {
        if (!details.installed || !details.configured) return resolve(false);
        const probe = net.createConnection({ host: details.host === '0.0.0.0' ? '127.0.0.1' : details.host, port: details.port });
        const done = value => { probe.destroy(); resolve(value); };
        probe.setTimeout(700);
        probe.once('connect', () => done(true));
        probe.once('error', () => done(false));
        probe.once('timeout', () => done(false));
    });
}

app.get('/api/map-status', auth, async (req, res) => {
    const details = blueMapDetails();
    const diagnostic = await diagnoseBlueMap(details.root);
    if (diagnostic.ready) return res.json({ ...diagnostic, url: details.url, port: details.port, proxy: { ...blueMapProxyStats } });
    const paperStatus = await platformAdapter.status().catch(() => ({ state: 'unknown' }));
    if (['offline', 'stopped'].includes(paperStatus.state) && ['webserver-offline', 'config-invalid'].includes(diagnostic.state)) {
        diagnostic.state = 'paper-offline';
        diagnostic.message = 'Paperが停止しています。サーバーを起動するとBlueMapの地図を表示できます。';
    }
    return res.json({ ...diagnostic, url: details.url, port: details.port, proxy: { ...blueMapProxyStats } });
});

app.get('/api/map-diagnostics', auth, async (req, res) => {
    const details = blueMapDetails();
    const diagnostic = await diagnoseBlueMap(details.root);
    // Compare a representative BlueMap document through the same proxy used by
    // Tailscale clients. This makes a broken Agent proxy visible separately.
    const agentPort = Number(process.env.GRIEFGUARD_PORT || 3000);
    const proxySettings = await blueMapRequestProbe({ host: '127.0.0.1', port: agentPort, requestPath: '/map/settings.json', timeoutMs: 5000 });
    diagnostic.checks.proxySettings = { status: proxySettings.status, elapsedMs: proxySettings.elapsedMs, error: proxySettings.error || null };
    if (diagnostic.ready && !proxySettings.ok) {
        diagnostic.ready = false;
        diagnostic.state = 'proxy-degraded';
        diagnostic.message = 'BlueMap本体には接続できますが、Agent経由の地図データ取得に失敗しています。';
    }
    res.json({ ...diagnostic, url: details.url, port: details.port, proxy: { ...blueMapProxyStats } });
});

// BlueMap is never exposed directly.  The Agent streams it from a loopback
// port under /map/ so Tailscale HTTPS and the app use one stable URL.
app.use('/map', (req, res) => {
    const details = blueMapDetails();
    if (!details.installed || !details.configured) return res.status(503).type('text/plain').send('BlueMap is not configured yet.');
    const requestPath = req.originalUrl.replace(/^\/map(?=\/|$)/, '') || '/';
    blueMapProxyStats.requests += 1;
    const upstream = http.request({
        host: details.host === '0.0.0.0' ? '127.0.0.1' : details.host,
        port: details.port,
        path: requestPath,
        method: req.method,
        headers: { ...req.headers, host: `127.0.0.1:${details.port}`, 'x-forwarded-proto': req.protocol }
    }, upstreamResponse => {
        // Missing tiles are normal while BlueMap is still rendering. The
        // upstream webapp treats 204 as an intentionally unavailable tile;
        // returning its raw 404 can leave some clients spinning indefinitely.
        if (upstreamResponse.statusCode === 404 && /^\/maps\/[^/]+\/tiles\//.test(requestPath)) {
            blueMapProxyStats.tileMisses += 1;
            upstreamResponse.resume();
            return res.status(204).end();
        }
        const headers = { ...upstreamResponse.headers };
        delete headers['x-frame-options'];
        if (headers.location && String(headers.location).startsWith('/')) headers.location = `/map${headers.location}`;
        if (/\/(?:$|index\.html|settings\.json$)|\/live\//.test(requestPath)) headers['cache-control'] = 'no-store, no-cache, must-revalidate';
        res.writeHead(upstreamResponse.statusCode || 502, headers);
        upstreamResponse.pipe(res);
    });
    upstream.setTimeout(30000, () => upstream.destroy(new Error('BlueMap接続がタイムアウトしました。')));
    upstream.once('error', error => {
        blueMapProxyStats.failures += 1;
        blueMapProxyStats.lastError = error.message;
        blueMapProxyStats.lastErrorAt = new Date().toISOString();
        if (!res.headersSent) res.status(502).type('text/plain').send('BlueMap is unavailable. Start Paper and check BlueMap diagnostics.');
    });
    req.once('aborted', () => upstream.destroy());
    req.pipe(upstream);
});

app.get('/api/health', (req, res) => {
    res.json({
        product: 'GriefGuard Mobile Manager',
        instanceId: AGENT_INSTANCE_ID,
        agentDataId: AGENT_DATA_ID,
        port: Number(process.env.GRIEFGUARD_PORT || 3000),
        testLabSessionId: TESTLAB_SESSION_ID || null,
        agent: 'online',
        setupRequired: !hasAdminPassword(),
        bridgeConnected: Boolean(pluginBridge.getStatus().connected),
        mode: agentMode
    });
});

function validControlToken(provided) {
    const token = String(provided || '');
    return token.length === AGENT_CONTROL_TOKEN.length
        && crypto.timingSafeEqual(Buffer.from(token), Buffer.from(AGENT_CONTROL_TOKEN));
}
function stopAgentGracefully() {
    if (stopAgentGracefully.requested) return;
    stopAgentGracefully.requested = true;
    console.log('[Agent] Local control requested a normal shutdown.');
    disconnectAuthorizedClients('Agent is stopping.');
    try { pluginBridge.socket?.destroy(); } catch (_) {}
    try { pluginBridge.server?.close(); } catch (_) {}
    try { wss?.close(); } catch (_) {}
    server.close(() => { removeRuntimeMarker(); process.exit(0); });
    setTimeout(() => { removeRuntimeMarker(); process.exit(0); }, 3000).unref();
}
stopAgentGracefully.requested = false;

// This endpoint is deliberately not available through LAN, Tailscale, or a
// browser login. The generated local command file presents both a private
// token and the current instance ID, so it cannot accidentally stop another
// Node.js process that happens to use the same port.
app.post('/api/local-control/stop', (req, res) => {
    if (!isLoopbackAddress(clientAddress(req))) return res.status(403).json({ error: 'localhostからのみ利用できます。' });
    if (!validControlToken(req.get('X-GriefGuard-Agent-Control'))) return res.status(403).json({ error: 'Agent制御トークンが一致しません。' });
    if (String(req.get('X-GriefGuard-Agent-Instance') || '') !== AGENT_INSTANCE_ID) return res.status(409).json({ error: 'Agentの起動情報が古いため停止しませんでした。' });
    res.json({ success: true, message: 'Agentを正常停止します。', instanceId: AGENT_INSTANCE_ID });
    setTimeout(stopAgentGracefully, 100).unref();
});

function validateLocalControlRequest(req, res) {
    if (!isLoopbackAddress(clientAddress(req))) {
        res.status(403).json({ error: 'localhostからのみ利用できます。' });
        return false;
    }
    if (!validControlToken(req.get('X-GriefGuard-Agent-Control'))) {
        res.status(403).json({ error: 'Agent制御トークンが一致しません。' });
        return false;
    }
    if (String(req.get('X-GriefGuard-Agent-Instance') || '') !== AGENT_INSTANCE_ID) {
        res.status(409).json({ error: 'Agentの起動情報が古いため操作しませんでした。' });
        return false;
    }
    return true;
}

app.post('/api/local-control/setup-code', (req, res) => {
    if (!validateLocalControlRequest(req, res)) return;
    if (hasAdminPassword()) {
        return res.status(409).json({
            error: '初回セットアップは完了しています。登録済みの管理パスワードでログインしてください。',
            setupRequired: false
        });
    }
    if (Date.now() - lastLocalSetupCodeIssueAt < LOCAL_CONTROL_CODE_INTERVAL_MS) {
        return res.status(429).json({ error: 'コードは30秒に1回だけ発行できます。少し待ってから再実行してください。' });
    }
    issueSetupChallenge();
    lastLocalSetupCodeIssueAt = Date.now();
    return res.json({
        success: true,
        code: setupChallenge.code,
        expiresAt: setupChallenge.expiresAt,
        setupRequired: true
    });
});

app.post('/api/local-control/password-reset-code', (req, res) => {
    if (!validateLocalControlRequest(req, res)) return;
    if (!hasAdminPassword()) {
        return res.status(409).json({
            error: '管理パスワードはまだ設定されていません。初回セットアップコードを発行してください。',
            setupRequired: true
        });
    }
    if (Date.now() - lastLocalPasswordResetIssueAt < LOCAL_CONTROL_CODE_INTERVAL_MS) {
        return res.status(429).json({ error: 'コードは30秒に1回だけ発行できます。少し待ってから再実行してください。' });
    }
    const challenge = issuePasswordResetChallenge();
    lastLocalPasswordResetIssueAt = Date.now();
    printConsoleCode('GriefGuard 管理パスワード・リセットコード', challenge);
    return res.json({
        success: true,
        code: challenge.code,
        expiresAt: challenge.expiresAt,
        setupRequired: false
    });
});

// This endpoint exists only while the installer has created a short-lived
// local bootstrap token. It never accepts a tailnet/LAN request and removes
// the need to leave a visible Agent terminal open just to read the one-time
// setup code.
app.get('/api/install/bootstrap', (req, res) => {
    if (!isLoopbackAddress(clientAddress(req))) return res.status(403).json({ error: 'localhostからのみ利用できます。' });
    const bootstrap = readInstallerBootstrap();
    const provided = String(req.get('X-GriefGuard-Installer-Token') || '');
    if (!bootstrap || !provided || provided.length !== bootstrap.token.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(bootstrap.token))) return res.status(403).json({ error: 'インストーラー確認トークンが無効です。' });
    return res.json({ setupRequired: !hasAdminPassword(), code: !hasAdminPassword() ? setupChallenge?.code || null : null, expiresAt: setupChallenge?.expiresAt || null });
});

app.post('/api/install/access', (req, res) => {
    if (!isLoopbackAddress(clientAddress(req))) return res.status(403).json({ error: 'localhostからのみ利用できます。' });
    const bootstrap = readInstallerBootstrap();
    const provided = String(req.get('X-GriefGuard-Installer-Token') || '');
    if (!bootstrap || !provided || provided.length !== bootstrap.token.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(bootstrap.token))) return res.status(403).json({ error: 'インストーラー確認トークンが無効です。' });
    const dnsName = String(req.body?.tailscaleDnsName || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
    if (!/^[a-z0-9][a-z0-9.-]*\.ts\.net$/i.test(dnsName)) return res.status(400).json({ error: 'Tailscale MagicDNS名が不正です。' });
    agentConfig = saveAgentConfig({ access: { tailscaleDnsName: dnsName, https: true } });
    return res.json({ success: true, tailscaleUrl: `https://${dnsName}` });
});

app.get('/api/setup/status', (req, res) => {
    return res.json({
        required: !hasAdminPassword(),
        codeIssued: Boolean(setupChallenge && setupChallenge.expiresAt > Date.now()),
        expiresAt: setupChallenge?.expiresAt || null,
        passwordResetAvailable: Boolean(readPasswordResetChallenge())
    });
});

app.post('/api/setup/code', (req, res) => {
    const address = clientAddress(req);
    if (!isAllowedClient(address)) return res.status(403).json({ error: 'この接続元からセットアップコードを要求できません。' });
    if (hasAdminPassword()) return res.status(409).json({ error: '初回セットアップは完了しています。' });
    if (Date.now() - lastSetupCodeRequestAt < 60000) return res.status(429).json({ error: 'コードの再表示は1分後に試してください。' });
    if (!setupChallenge || setupChallenge.expiresAt <= Date.now() || setupChallenge.attempts >= CODE_MAX_ATTEMPTS) issueSetupChallenge();
    else {
        lastSetupCodeRequestAt = Date.now();
        printConsoleCode('GriefGuard 初回セットアップコード（再表示）', setupChallenge);
    }
    return res.json({ success: true, expiresAt: setupChallenge.expiresAt });
});

app.post('/api/setup/complete', (req, res) => {
    const address = clientAddress(req);
    if (!isAllowedClient(address)) return res.status(403).json({ error: 'この接続元から初回設定できません。' });
    if (hasAdminPassword()) return res.status(409).json({ error: '初回セットアップは完了しています。' });
    const policyError = passwordPolicyError(req.body.password);
    if (policyError) return res.status(400).json({ error: policyError });
    if (!challengeMatches(setupChallenge, req.body.code)) {
        const exhausted = !setupChallenge || setupChallenge.expiresAt <= Date.now() || setupChallenge.attempts >= CODE_MAX_ATTEMPTS;
        return res.status(exhausted ? 429 : 401).json({ error: exhausted ? 'セットアップコードの有効期限または試行回数を超えました。コードを再発行してください。' : 'セットアップコードが正しくありません。' });
    }
    agentConfig = saveAgentConfig({ auth: { password: null, passwordHash: hashPassword(req.body.password) } });
    setupChallenge = null;
    try { fs.unlinkSync(INSTALLER_BOOTSTRAP_FILE); } catch (_) {}
    activeSessions.clear();
    persistSessions();
    const token = issueSession();
    console.log(`[Auth] Initial setup completed from ${address}.`);
    return res.json(loginResponse(token));
});

app.post('/api/login', (req, res) => {
    const { password } = req.body;
    const address = clientAddress(req);
    
    if (!hasAdminPassword()) return res.status(409).json({ error: '初回セットアップコードを使って管理パスワードを設定してください。', setupRequired: true });
    if (!password) {
        return res.status(400).json({ error: "パスワードを入力してください。" });
    }
    if (loginRateLimited(address)) return res.status(429).json({ error: 'ログイン試行回数が多すぎます。5分後に再試行してください。' });
    const isValidNetwork = isAllowedClient(address);
    const isValidPassword = isValidNetwork && verifyPassword(password);
    
    if (isValidNetwork && isValidPassword) {
        loginAttempts.delete(address);
        const token = issueSession();
        return res.json(loginResponse(token));
    } else {
        recordLoginFailure(address);
        return res.status(401).json({ error: isValidNetwork ? "パスワードが正しくありません。" : "この接続元はlocalhost・LAN・Tailscaleとして確認できません。" });
    }
});

app.post('/api/security/password-reset', (req, res) => {
    const address = clientAddress(req);
    if (!isAllowedClient(address)) return res.status(403).json({ error: 'この接続元から管理パスワードをリセットできません。' });
    if (!hasAdminPassword()) return res.status(409).json({ error: '初回セットアップを完了してください。', setupRequired: true });
    const policyError = passwordPolicyError(req.body.newPassword);
    if (policyError) return res.status(400).json({ error: policyError });
    const result = consumePasswordResetChallenge(req.body.code);
    if (!result.valid) {
        return res.status(result.exhausted ? 429 : 401).json({
            error: result.exhausted
                ? 'リセットコードの有効期限または試行回数を超えました。Agentコンソールで新しいコードを発行してください。'
                : 'リセットコードが正しくありません。'
        });
    }
    agentConfig = saveAgentConfig({ auth: { password: null, passwordHash: hashPassword(req.body.newPassword) } });
    setupChallenge = null;
    passwordChangeChallenge = null;
    loginAttempts.clear();
    activeSessions.clear();
    persistSessions();
    const token = issueSession();
    disconnectAuthorizedClients('Management password reset');
    console.log(`[Auth] Management password reset with a local console code from ${address}. All previous sessions were revoked.`);
    return res.json(loginResponse(token));
});

function auth(req, res, next) {
    const token = req.headers['authorization'];
    if (isActiveSession(token)) {
        next();
    } else {
        // Keep enough information to diagnose an expired browser session
        // without ever logging the actual session token.
        if (req.path === '/api/control') console.warn(`[Auth] Command request rejected from ${clientAddress(req)}: session is missing or expired.`);
        res.status(403).json({ error: "Unauthorized access." });
    }
}

function commandClientName(value, legacyHeader) {
    // Device names are shown in the shared command history. Accept Unicode
    // from JSON, but make the value safe and compact before storing it.
    const candidate = String(value || legacyHeader || '管理端末')
        .replace(/[\u0000-\u001F\u007F]/g, ' ')
        .trim();
    return Array.from(candidate || '管理端末').slice(0, 60).join('');
}

app.post('/api/logout', auth, (req, res) => {
    revokeSession(req.headers['authorization']);
    return res.json({ success: true });
});

app.post('/api/security/password-code', auth, (req, res) => {
    if (!verifyPassword(req.body.currentPassword)) return res.status(401).json({ error: '現在の管理パスワードが正しくありません。' });
    issuePasswordChangeChallenge();
    return res.json({ success: true, expiresAt: passwordChangeChallenge.expiresAt });
});

app.post('/api/security/password', auth, (req, res) => {
    const policyError = passwordPolicyError(req.body.newPassword);
    if (policyError) return res.status(400).json({ error: policyError });
    const passwordValid = verifyPassword(req.body.currentPassword);
    const codeValid = challengeMatches(passwordChangeChallenge, req.body.code);
    if (!passwordValid || !codeValid) {
        const exhausted = !passwordChangeChallenge || passwordChangeChallenge.expiresAt <= Date.now() || passwordChangeChallenge.attempts >= CODE_MAX_ATTEMPTS;
        return res.status(exhausted ? 429 : 401).json({ error: exhausted ? '確認コードの有効期限または試行回数を超えました。新しいコードを発行してください。' : '現在のパスワードまたは確認コードが正しくありません。' });
    }
    if (verifyPassword(req.body.newPassword)) return res.status(400).json({ error: '現在とは異なる管理パスワードを設定してください。' });
    agentConfig = saveAgentConfig({ auth: { password: null, passwordHash: hashPassword(req.body.newPassword) } });
    passwordChangeChallenge = null;
    activeSessions.clear();
    persistSessions();
    const token = issueSession();
    disconnectAuthorizedClients('Management password changed');
    console.log(`[Auth] Management password changed from ${clientAddress(req)}. Other sessions were revoked.`);
    return res.json({ success: true, token });
});

app.get('/api/agent/status', auth, async (req, res) => {
    try { return res.json(publicAgentInfo(await platformAdapter.status())); }
    catch (error) { return res.json(publicAgentInfo({ state: 'unknown', error: error.message })); }
});

// This endpoint measures only the browser-to-Agent path. It intentionally
// does not wait for Paper or the Plugin Bridge, so the UI can distinguish a
// Tailscale/HTTPS delay from a long-running server action.
app.get('/api/ping', auth, (req, res) => {
    res.json({ ok: true, agentTime: Date.now(), pluginConnected: Boolean(pluginBridge.getStatus().connected) });
});

app.get('/api/metrics', auth, (req, res) => {
    return res.json({
        host: getHostMetrics(),
        minecraft: latestPluginStatus || pluginBridge.getStatus().live || null,
        configuredMemory: agentConfig.local?.memory || { min: '', max: '', source: '' }
    });
});

app.get('/api/edition', auth, (req, res) => {
    const hello = pluginBridge.getStatus().hello || null;
    const capabilities = Array.isArray(hello?.capabilities) ? hello.capabilities : [];
    return res.json({
        connected: Boolean(pluginBridge.getStatus().connected),
        edition: hello?.edition || 'unknown',
        build: hello?.build || '',
        bridgeProtocol: Number(hello?.bridgeProtocol || 0),
        capabilities
    });
});

app.get('/api/agent/config', auth, (req, res) => {
    return res.json({
        mode: agentConfig.mode,
        displayName: agentConfig.displayName,
        serverDirectory: agentConfig.serverDirectory,
        bridge: agentConfig.bridge,
        local: agentConfig.local,
        windows: agentConfig.windows,
        linux: agentConfig.linux,
        panel: { type: agentConfig.panel.type, url: agentConfig.panel.url, serverId: agentConfig.panel.serverId, apiKeyConfigured: Boolean(agentConfig.panel.apiKey) },
        access: agentConfig.access
    });
});

app.post('/api/agent/config', auth, (req, res) => {
    const allowedModes = ['auto', 'windows', 'linux', 'panel', 'plugin-only'];
    if (req.body.mode && !allowedModes.includes(req.body.mode)) return res.status(400).json({ error: 'Invalid agent mode.' });
    // Authentication can only be changed through /api/security/password,
    // which requires the current password and a console-only one-time code.
    const allowedKeys = ['mode', 'displayName', 'serverDirectory', 'bridge', 'local', 'windows', 'linux', 'panel', 'access'];
    const update = {};
    allowedKeys.forEach(key => {
        if (Object.prototype.hasOwnProperty.call(req.body, key)) update[key] = req.body[key];
    });
    agentConfig = saveAgentConfig(update);
    agentMode = resolveMode(agentConfig);
    platformAdapter = createAdapter(agentMode, agentConfig, pluginBridge);
    return res.json({ success: true, agent: publicAgentInfo() });
});

app.post('/api/control', auth, async (req, res) => {
    const { command, reasonCode } = req.body;
    console.log(`[Control] ${agentMode}: ${command}${reasonCode ? ` (${reasonCode})` : ''}`);
    // Older clients may still send an ASCII-only header. New clients send the
    // display name in JSON so Japanese and emoji do not cause fetch TypeError.
    const device = commandClientName(req.body?.clientName, req.get('X-GriefGuard-Client-Name'));
    try {
        const result = queueControlOperation({ command, reasonCode, device });
        return res.status(202).json({ ...result, commandEvent: result.event });
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
});

app.get('/api/control/:id', auth, (req, res) => {
    const entry = commandJournal.recent(500).find(item => item.id === req.params.id);
    if (!entry) return res.status(404).json({ error: '操作履歴が見つかりません。' });
    return res.json({ commandEvent: entry });
});

app.get('/api/console/history', auth, (req, res) => {
    return res.json({ entries: commandJournal.recent(req.query.limit) });
});

const scheduleFilePath = path.join(__dirname, 'auto_restart.json');

function loadScheduleSettings() {
    if (fs.existsSync(scheduleFilePath)) {
        try {
            return JSON.parse(fs.readFileSync(scheduleFilePath, 'utf8'));
        } catch (e) {
            console.error("Failed to parse auto_restart.json:", e);
        }
    }
    return { enabled: false, time: "04:00" };
}

app.get('/api/restart-schedule', auth, (req, res) => {
    return res.json(loadScheduleSettings());
});

app.post('/api/restart-schedule', auth, (req, res) => {
    const { enabled, time } = req.body;
    if (typeof enabled !== 'boolean' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(String(time || ''))) {
        return res.status(400).json({ error: "自動再起動の有効状態または時刻形式が正しくありません。" });
    }
    
    const settings = { enabled, time };
    try {
        fs.writeFileSync(scheduleFilePath, JSON.stringify(settings, null, 2), 'utf8');
        console.log(`[Scheduler] Auto-restart settings updated: Enabled=${enabled}, Time=${time}`);
        return res.json({ success: true });
    } catch (e) {
        console.error("Failed to save auto_restart.json:", e);
        return res.status(500).json({ error: "Failed to save schedule settings on server." });
    }
});

setInterval(async () => {
    const settings = loadScheduleSettings();
    if (!settings.enabled) return;
    
    const now = new Date();
    const currentHour = String(now.getHours()).padStart(2, '0');
    const currentMin = String(now.getMinutes()).padStart(2, '0');
    const currentTimeStr = `${currentHour}:${currentMin}`;
    
    if (currentTimeStr === settings.time) {
        console.log(`[Scheduler] Scheduled auto-restart time reached (${currentTimeStr}). Triggering restart...`);
        
        broadcast({ type: 'log', level: 'warn', message: `[自動再起動] ${currentTimeStr} の予約時刻になったため、Paperを再起動します。` });
        try {
            const result = await executeControl(platformAdapter, '/restart', { reasonCode: 'scheduled-restart' });
            const detail = result?.message ? ` ${result.message}` : '';
            console.log(`[Scheduler] Auto-restart completed.${detail}`);
            broadcast({ type: 'log', level: 'success', message: `[自動再起動] 正常に完了しました。${detail}` });
        } catch (error) {
            console.error('[Scheduler] Auto-restart failed:', error.message);
            broadcast({ type: 'log', level: 'error', message: `[自動再起動] 失敗しました: ${error.message}` });
        }
    }
}, 60000);

app.get('/api/commands', auth, (req, res) => {
    const commandsFilePath = path.join(__dirname, 'commands.json');
    if (fs.existsSync(commandsFilePath)) {
        try {
            const data = JSON.parse(fs.readFileSync(commandsFilePath, 'utf8'));
            return res.json(data);
        } catch (e) {
            console.error("Failed to read commands.json:", e);
        }
    }
    return res.json([]);
});

function playerNameIsValid(name) {
    return /^\.?[A-Za-z0-9_]{3,16}$/.test(String(name || '').trim());
}

function readWhitelistNames() {
    const whitelistPath = serverPath('whitelist.json');
    if (!fs.existsSync(whitelistPath)) return new Set();
    const entries = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
    return new Set((Array.isArray(entries) ? entries : [])
        .map(entry => String(entry?.name || '').toLowerCase()).filter(Boolean));
}

function buildPlayerList() {
    const usercachePath = serverPath('usercache.json');
    const bannedPlayersPath = serverPath('banned-players.json');
    const cache = fs.existsSync(usercachePath) ? JSON.parse(fs.readFileSync(usercachePath, 'utf8')) : [];
    const bans = fs.existsSync(bannedPlayersPath) ? JSON.parse(fs.readFileSync(bannedPlayersPath, 'utf8')) : [];
    const bannedNames = new Set((Array.isArray(bans) ? bans : []).map(entry => String(entry.name || entry.target || '').toLowerCase()).filter(Boolean));
    const whitelistNames = readWhitelistNames();
    const playersByUuid = new Map();
    (Array.isArray(latestPlayerDirectory) ? latestPlayerDirectory : []).filter(entry => entry?.name).forEach(entry => {
        const key = entry.uuid || String(entry.name).toLowerCase();
        playersByUuid.set(key, {
            name: entry.name, uuid: entry.uuid || null, ip: null,
            lastLogin: entry.lastLogin ? new Date(Number(entry.lastLogin)).toISOString() : null,
            loginCount: Number(entry.loginCount || 0), warnings: Number.isFinite(entry.warnings) ? entry.warnings : null,
            relaxed: Boolean(entry.relaxed), op: Boolean(entry.op), profile: entry.op ? 'OP' : (entry.relaxed ? 'RELAXED' : 'NORMAL'),
            whitelisted: whitelistNames.has(String(entry.name).toLowerCase()),
            status: bannedNames.has(String(entry.name).toLowerCase()) ? 'BANNED' : (entry.online ? 'ONLINE' : 'OFFLINE')
        });
    });
        (Array.isArray(cache) ? cache : []).filter(entry => entry && entry.name).forEach(entry => {
            const key = entry.uuid || entry.name.toLowerCase();
            const current = playersByUuid.get(key) || {};
            playersByUuid.set(key, {
                ...current,
                name: entry.name, uuid: entry.uuid || null, ip: current.ip || null, lastLogin: current.lastLogin || null,
                loginCount: current.loginCount || 0, warnings: current.warnings ?? null, profile: current.profile || null,
                relaxed: Boolean(current.relaxed), op: Boolean(current.op), whitelisted: whitelistNames.has(String(entry.name).toLowerCase()),
                status: bannedNames.has(String(entry.name).toLowerCase()) ? 'BANNED' : 'OFFLINE'
            });
        });
        const livePlayers = Array.isArray(latestPluginStatus?.playerList) ? latestPluginStatus.playerList : [];
        livePlayers.forEach(entry => {
            const key = entry.uuid || String(entry.name).toLowerCase();
            const current = playersByUuid.get(key) || {};
            playersByUuid.set(key, {
                ...current,
                name: entry.name, uuid: entry.uuid || null, ip: entry.ip || current.ip || null, lastLogin: current.lastLogin || null,
                loginCount: current.loginCount || 0,
                warnings: Number.isFinite(entry.warnings) ? entry.warnings : null,
                profile: entry.profile || null,
                relaxed: Boolean(entry.relaxed ?? current.relaxed), op: Boolean(entry.op ?? current.op),
                whitelisted: whitelistNames.has(String(entry.name).toLowerCase()),
                status: bannedNames.has(String(entry.name).toLowerCase()) ? 'BANNED' : 'ONLINE'
            });
        });
    return [...playersByUuid.values()].sort((a, b) => (b.lastLogin ? Date.parse(b.lastLogin) : 0) - (a.lastLogin ? Date.parse(a.lastLogin) : 0));
}

app.get('/api/players', auth, (req, res) => {
    try {
        return res.json(buildPlayerList());
    } catch (error) {
        console.error('Failed to read player data:', error);
        return res.status(500).json({ error: 'プレイヤーデータを読み込めませんでした。' });
    }
});

app.get('/api/players/:uuid/security-summary', auth, async (req, res) => {
    const uuid = String(req.params.uuid || '').trim();
    if (!/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(uuid)) return res.status(400).json({ error: 'プレイヤーIDの形式が正しくありません。' });
    const hello = pluginBridge.getStatus().hello || {};
    const capabilities = Array.isArray(hello.capabilities) ? hello.capabilities : [];
    if (hello.edition !== 'high' || !capabilities.includes('player.connection-history')) {
        return res.status(409).json({ error: 'HighVersion Pluginが接続されていません。' });
    }
    try {
        const result = await pluginBridge.sendCommandAndWait(`GG:HIGH:SUMMARY:${uuid}`, 10000);
        if (!String(result.message || '').startsWith('HIGHJSON:')) throw new Error(result.message || 'HighVersionの応答を取得できませんでした。');
        const payload = JSON.parse(String(result.message).slice('HIGHJSON:'.length));
        return res.json(payload);
    } catch (error) {
        return res.status(503).json({ error: error.message || 'HighVersionの接続履歴を取得できませんでした。' });
    }
});

app.get('/api/bans', auth, (req, res) => {
    try {
        const ipPath = serverPath('banned-ips.json');
        const playerPath = serverPath('banned-players.json');
        const ipEntries = fs.existsSync(ipPath) ? JSON.parse(fs.readFileSync(ipPath, 'utf8')) : [];
        const playerEntries = fs.existsSync(playerPath) ? JSON.parse(fs.readFileSync(playerPath, 'utf8')) : [];
        const ips = (Array.isArray(ipEntries) ? ipEntries : []).map(entry => typeof entry === 'string' ? entry : entry.ip || entry.target).filter(Boolean);
        const players = (Array.isArray(playerEntries) ? playerEntries : []).map(entry => typeof entry === 'string' ? entry : entry.name || entry.target).filter(Boolean);
        return res.json({ ips, players });
    } catch (error) {
        return res.status(500).json({ error: 'BANリストを読み込めませんでした。' });
    }
});

app.delete('/api/bans/ip/:ip', auth, async (req, res) => {
    const ip = String(req.params.ip || '').trim();
    if (!/^[0-9a-fA-F:.]+$/.test(ip)) return res.status(400).json({ error: 'IPアドレスの形式が正しくありません。' });
    try { return res.json(await executeControl(platformAdapter, `/pardon-ip ${ip}`)); }
    catch (error) { return res.status(503).json({ error: error.message }); }
});

app.get('/api/whitelist', auth, (req, res) => {
    const whitelistPath = serverPath('whitelist.json');
    try {
        if (!fs.existsSync(whitelistPath)) return res.json([]);
        const entries = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
        return res.json(Array.isArray(entries) ? entries.map(entry => entry.name).filter(Boolean) : []);
    } catch (error) {
        return res.status(500).json({ error: 'ホワイトリストを読み込めませんでした。' });
    }
});

app.get('/api/whitelist/candidates', auth, (req, res) => {
    try {
        const candidates = buildPlayerList()
            .filter(player => playerNameIsValid(player.name) && !player.whitelisted && player.status !== 'BANNED')
            .map(({ name, uuid, lastLogin, loginCount, status }) => ({ name, uuid, lastLogin, loginCount, status }));
        return res.json(candidates);
    } catch (error) {
        return res.status(500).json({ error: 'ホワイトリスト候補を読み込めませんでした。' });
    }
});

app.post('/api/whitelist', auth, async (req, res) => {
    const name = String(req.body.name || '').trim();
    if (!playerNameIsValid(name)) return res.status(400).json({ error: 'プレイヤー名の形式が正しくありません。' });
    try { return res.json(await executeControl(platformAdapter, `/whitelist add ${name}`)); }
    catch (error) { return res.status(503).json({ error: error.message }); }
});

app.post('/api/whitelist/bulk', auth, async (req, res) => {
    const names = [...new Set((Array.isArray(req.body?.names) ? req.body.names : [])
        .map(value => String(value || '').trim()).filter(Boolean))];
    if (!names.length || names.length > 100 || names.some(name => !playerNameIsValid(name))) {
        return res.status(400).json({ error: '追加するプレイヤー名を1〜100件、正しい形式で指定してください。' });
    }
    const results = [];
    for (const name of names) {
        try {
            await executeControl(platformAdapter, `/whitelist add ${name}`);
            results.push({ name, ok: true });
        } catch (error) {
            results.push({ name, ok: false, error: error.message });
        }
    }
    return res.json({ results });
});

app.delete('/api/whitelist/:name', auth, async (req, res) => {
    const name = String(req.params.name || '').trim();
    if (!playerNameIsValid(name)) return res.status(400).json({ error: 'プレイヤー名の形式が正しくありません。' });
    try { return res.json(await executeControl(platformAdapter, `/whitelist remove ${name}`)); }
    catch (error) { return res.status(503).json({ error: error.message }); }
});

app.patch('/api/players/:uuid/profile', auth, (req, res) => {
    const uuid = String(req.params.uuid || '').trim();
    const profile = String(req.body?.profile || '').trim().toLowerCase();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid)) {
        return res.status(400).json({ error: 'プレイヤーIDの形式が正しくありません。' });
    }
    if (!['normal', 'relaxed'].includes(profile)) return res.status(400).json({ error: '通常または緩和を選択してください。' });
    const player = buildPlayerList().find(entry => String(entry.uuid).toLowerCase() === uuid.toLowerCase());
    if (!player) return res.status(404).json({ error: '対象プレイヤーが見つかりません。' });
    if (player.op) return res.status(403).json({ error: 'OPプレイヤーの検知プロフィールは変更できません。' });
    try {
        const result = pluginBridge.sendCommandAndWait(`GG:RELAX:${uuid}:${profile === 'relaxed'}`, 5000);
        return result.then(confirmation => res.json({ accepted: true, profile: profile.toUpperCase(), message: confirmation.message || 'プロフィールを変更しました。' }))
            .catch(error => res.status(503).json({ error: error.message }));
    } catch (error) {
        return res.status(503).json({ error: error.message });
    }
});

app.patch('/api/players/:uuid/operator', auth, async (req, res) => {
    const uuid = String(req.params.uuid || '').trim();
    const operator = req.body?.operator === true;
    const confirmation = String(req.body?.confirmation || '').trim();
    const currentPassword = String(req.body?.currentPassword || '');
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid)) {
        return res.status(400).json({ error: 'プレイヤーIDの形式が正しくありません。' });
    }
    const player = buildPlayerList().find(entry => String(entry.uuid).toLowerCase() === uuid.toLowerCase());
    if (!player) return res.status(404).json({ error: '対象プレイヤーが見つかりません。' });
    if (!verifyPassword(currentPassword)) return res.status(401).json({ error: '管理パスワードが正しくありません。' });
    if (confirmation !== player.name) return res.status(400).json({ error: '確認用プレイヤー名が一致しません。' });
    try {
        const result = await pluginBridge.sendCommandAndWait(`GG:OP:${uuid}:${operator}`, 5000);
        return res.json({ accepted: true, operator, message: result.message || `${player.name} の権限を変更しました。` });
    } catch (error) {
        return res.status(503).json({ error: error.message });
    }
});

// Generic plugin configuration editor. Supports text-based configuration files
// used alongside or instead of config.yml while preventing path traversal.
const PLUGIN_CONFIG_EXTENSIONS = new Set(['.yml', '.yaml', '.json', '.toml', '.conf', '.properties', '.txt']);
function pluginsRoot() { return serverPath('plugins'); }

function editablePluginFiles(directory, root = pluginsRoot(), depth = 0) {
    if (depth > 3 || !fs.existsSync(directory)) return [];
    const files = [];
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        if (entry.name.startsWith('.') || entry.name.endsWith('.bak')) continue;
        const absolute = path.join(directory, entry.name);
        if (entry.isDirectory()) files.push(...editablePluginFiles(absolute, root, depth + 1));
        else if (PLUGIN_CONFIG_EXTENSIONS.has(path.extname(entry.name).toLowerCase()) && fs.statSync(absolute).size <= 1024 * 1024) {
            files.push(path.relative(root, absolute));
        }
    }
    return files;
}

function readZipTextEntry(file, acceptedNames) {
    const stat = fs.statSync(file);
    if (stat.size > 128 * 1024 * 1024) return null;
    const buffer = fs.readFileSync(file);
    const minimum = Math.max(0, buffer.length - 65557);
    let eocd = -1;
    for (let offset = buffer.length - 22; offset >= minimum; offset--) {
        if (buffer.readUInt32LE(offset) === 0x06054b50) { eocd = offset; break; }
    }
    if (eocd < 0) return null;
    const entries = buffer.readUInt16LE(eocd + 10);
    let cursor = buffer.readUInt32LE(eocd + 16);
    for (let index = 0; index < entries && cursor + 46 <= buffer.length; index++) {
        if (buffer.readUInt32LE(cursor) !== 0x02014b50) break;
        const method = buffer.readUInt16LE(cursor + 10);
        const compressedSize = buffer.readUInt32LE(cursor + 20);
        const uncompressedSize = buffer.readUInt32LE(cursor + 24);
        const nameLength = buffer.readUInt16LE(cursor + 28);
        const extraLength = buffer.readUInt16LE(cursor + 30);
        const commentLength = buffer.readUInt16LE(cursor + 32);
        const localOffset = buffer.readUInt32LE(cursor + 42);
        const name = buffer.subarray(cursor + 46, cursor + 46 + nameLength).toString('utf8');
        if (acceptedNames.includes(name) && uncompressedSize <= 256 * 1024 && localOffset + 30 <= buffer.length && buffer.readUInt32LE(localOffset) === 0x04034b50) {
            const localNameLength = buffer.readUInt16LE(localOffset + 26);
            const localExtraLength = buffer.readUInt16LE(localOffset + 28);
            const start = localOffset + 30 + localNameLength + localExtraLength;
            const compressed = buffer.subarray(start, start + compressedSize);
            if (method === 0) return compressed.toString('utf8');
            if (method === 8) return zlib.inflateRawSync(compressed, { maxOutputLength: 256 * 1024 }).toString('utf8');
            return null;
        }
        cursor += 46 + nameLength + extraLength + commentLength;
    }
    return null;
}

function yamlTopLevelValue(content, key) {
    const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = String(content || '').match(new RegExp(`^${escapedKey}:\\s*(.+?)\\s*$`, 'm'));
    if (!match) return '';
    const value = match[1].trim();
    if (value === '|' || value === '>') return '';
    return value.replace(/^['"]|['"]$/g, '');
}

function pluginDescriptor(jarFile) {
    try {
        const content = readZipTextEntry(jarFile, ['plugin.yml', 'paper-plugin.yml']);
        if (!content) return null;
        return {
            name: yamlTopLevelValue(content, 'name'),
            version: yamlTopLevelValue(content, 'version'),
            description: yamlTopLevelValue(content, 'description'),
            apiVersion: yamlTopLevelValue(content, 'api-version')
        };
    } catch (error) {
        console.warn(`[Plugins] Could not inspect ${path.basename(jarFile)}: ${error.message}`);
        return null;
    }
}

function pluginKey(value) { return String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }

app.get('/api/plugins', auth, (req, res) => {
    const root = pluginsRoot();
    try {
        if (!fs.existsSync(root)) return res.json({ plugins: [], count: 0, editableCount: 0 });
        const entries = fs.readdirSync(root, { withFileTypes: true });
        const directories = entries.filter(entry => entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'bStats');
        const usedDirectories = new Set();
        const plugins = entries
            .filter(entry => entry.isFile() && entry.name.toLowerCase().endsWith('.jar'))
            .map(entry => {
                const jar = path.join(root, entry.name);
                const descriptor = pluginDescriptor(jar) || {};
                const jarName = path.basename(entry.name, path.extname(entry.name));
                const displayName = descriptor.name || jarName;
                const directory = directories.find(candidate => pluginKey(candidate.name) === pluginKey(displayName))
                    || directories.find(candidate => pluginKey(candidate.name) === pluginKey(jarName));
                if (directory) usedDirectories.add(directory.name);
                const configFiles = directory ? editablePluginFiles(path.join(root, directory.name)).sort() : [];
                return {
                    id: pluginKey(displayName) || pluginKey(jarName),
                    name: displayName,
                    version: descriptor.version || '',
                    description: descriptor.description || '',
                    apiVersion: descriptor.apiVersion || '',
                    jar: entry.name,
                    dataDirectory: directory?.name || '',
                    configFiles,
                    specialized: pluginKey(displayName) === 'griefguard',
                    source: 'jar'
                };
            });
        for (const directory of directories) {
            if (usedDirectories.has(directory.name)) continue;
            const configFiles = editablePluginFiles(path.join(root, directory.name)).sort();
            if (!configFiles.length) continue;
            plugins.push({
                id: pluginKey(directory.name), name: directory.name, version: '',
                description: 'サーバー組み込み機能または設定フォルダーを検出しました。', apiVersion: '',
                jar: '', dataDirectory: directory.name, configFiles, specialized: false, source: 'config-directory'
            });
        }
        plugins.sort((left, right) => Number(right.specialized) - Number(left.specialized) || left.name.localeCompare(right.name, 'ja'));
        return res.json({
            plugins,
            count: plugins.length,
            editableCount: plugins.filter(plugin => plugin.configFiles.length > 0).length
        });
    } catch (error) {
        console.error('[Plugins] Inventory failed:', error);
        return res.status(500).json({ error: '導入プラグインを確認できませんでした。' });
    }
});

function pluginUploadName(value) {
    const name = path.basename(String(value || '')).trim();
    if (!name || name.length > 160 || !/^[^\\/\0]+\.jar$/i.test(name)) throw new Error('プラグインJAR（.jar）を選択してください。');
    return name;
}

function isZipArchive(buffer) {
    return Buffer.isBuffer(buffer) && buffer.length >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4b
        && ((buffer[2] === 0x03 && buffer[3] === 0x04) || (buffer[2] === 0x05 && buffer[3] === 0x06));
}

app.post('/api/plugins/upload', auth, express.raw({ type: 'application/java-archive', limit: '50mb' }), (req, res) => {
    let temporary = '';
    try {
        const name = pluginUploadName(req.query.filename);
        if (!isZipArchive(req.body)) return res.status(400).json({ error: 'JAR形式ではないため追加できません。' });
        const root = pluginsRoot();
        fs.mkdirSync(root, { recursive: true, mode: 0o700 });
        const destination = path.join(root, name);
        if (fs.existsSync(destination)) return res.status(409).json({ error: '同名のプラグインが既にあります。JAR名を変更するか、既存のプラグインを削除してください。' });
        temporary = path.join(root, `.${name}.${crypto.randomUUID()}.uploading`);
        fs.writeFileSync(temporary, req.body, { mode: 0o600 });
        const descriptor = pluginDescriptor(temporary);
        if (!descriptor?.name) return res.status(400).json({ error: 'plugin.yml または paper-plugin.yml が見つかりません。PaperプラグインJARのみ追加できます。' });
        fs.renameSync(temporary, destination);
        temporary = '';
        console.log(`[Plugins] Uploaded ${name} as ${descriptor.name} from ${clientAddress(req)}.`);
        return res.status(201).json({ success: true, file: name, plugin: descriptor, restartRequired: true });
    } catch (error) {
        if (temporary) try { fs.rmSync(temporary, { force: true }); } catch (_) {}
        return res.status(400).json({ error: error.message || 'プラグインを追加できませんでした。' });
    }
});

function resolvePluginConfig(relativePath) {
    const root = fs.realpathSync(path.resolve(pluginsRoot()));
    const resolved = path.resolve(root, String(relativePath || ''));
    if (!resolved.startsWith(root + path.sep)) throw new Error('Invalid plugin config path.');
    if (!PLUGIN_CONFIG_EXTENSIONS.has(path.extname(resolved).toLowerCase())) throw new Error('Unsupported plugin config format.');
    if (!fs.existsSync(resolved)) return resolved;
    const real = fs.realpathSync(resolved);
    if (!real.startsWith(root + path.sep)) throw new Error('Invalid plugin config path.');
    return real;
}

app.get('/api/plugin-config-files', auth, (req, res) => {
    const root = pluginsRoot();
    try { return res.json({ files: editablePluginFiles(root).sort() }); }
    catch (error) { return res.status(500).json({ error: 'プラグイン設定ファイルを検索できませんでした。' }); }
});

app.get('/api/plugin-config-file', auth, (req, res) => {
    try {
        const file = resolvePluginConfig(req.query.path);
        if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).json({ error: '設定ファイルが見つかりません。' });
        return res.json({ path: path.relative(pluginsRoot(), file), content: fs.readFileSync(file, 'utf8') });
    } catch (error) { return res.status(400).json({ error: error.message }); }
});

app.post('/api/plugin-config-file', auth, (req, res) => {
    try {
        const file = resolvePluginConfig(req.body.path);
        const content = String(req.body.content ?? '');
        if (Buffer.byteLength(content, 'utf8') > 1024 * 1024) return res.status(413).json({ error: '設定ファイルは1MB以内にしてください。' });
        if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).json({ error: '設定ファイルが見つかりません。' });
        fs.copyFileSync(file, file + '.bak');
        fs.writeFileSync(file, content, 'utf8');
        return res.json({ success: true, restartRequired: true, backup: path.basename(file) + '.bak' });
    } catch (error) { return res.status(400).json({ error: error.message }); }
});

// ----------------------------------------------------
// CONFIG.YML INTERACTIVE YAML READ/WRITE CONTROLLERS
// ----------------------------------------------------
function findConfigYmlPath() {
    const paths = [
        serverPath('plugins', 'GriefGuard', 'config.yml'),
        serverPath('plugins', 'GriefGuard_HighVertion', 'config.yml')
    ];
    for (const p of paths) {
        if (fs.existsSync(p)) return p;
    }
    return null;
}

function detectedBackupWorldCount() {
    try {
        const root = serverPath();
        return fs.readdirSync(root, { withFileTypes: true })
            .filter(entry => entry.isDirectory() && fs.existsSync(path.join(root, entry.name, 'level.dat')))
            .length;
    } catch (_) {
        return 0;
    }
}

function backupRetentionLimit(worldCount) {
    if (worldCount <= 3) return 20;
    if (worldCount === 4) return 15;
    return 10;
}

function validateBackupCustomDirectory(value) {
    const directory = String(value ?? '').trim().replace(/\\/g, '/');
    if (!directory || directory.length > 180 || path.isAbsolute(directory) || directory.split('/').some(part => !part || part === '.' || part === '..') || /[\0\r\n]/.test(directory)) {
        throw new Error('カスタム保存先はサーバーフォルダー内の相対パスで入力してください。');
    }
    return directory;
}

// JSON string syntax is valid YAML for the scalar values written by this API.
// Keep this declaration above the route: it is also used for backup settings.
const yamlString = value => JSON.stringify(String(value ?? '').replace(/[\r\n]/g, ' '));

app.get('/api/config', auth, (req, res) => {
    const configPath = findConfigYmlPath();
    if (!configPath) return res.status(404).json({ error: 'GriefGuard の config.yml が見つかりません。' });
    
    try {
        const content = fs.readFileSync(configPath, 'utf8');
        
        const autoBan = parseYamlField(content, 'auto-action.auto-ban') !== 'false';
        const autoRollback = parseYamlField(content, 'auto-action.auto-rollback') !== 'false';
        const banReason = parseYamlField(content, 'ban-reason') || "Suspicious behavior detected (Anti-Grief). If this is a mistake, contact the administrator.";
        const discordEnabled = parseYamlField(content, 'discord-bot.enabled') === 'true';
        const discordToken = parseYamlField(content, 'discord-bot.token') || "";
        const discordBridgeMode = parseYamlField(content, 'discord-bot.bridge-mode') === 'true';
        const discordVpsIp = parseYamlField(content, 'discord-bot.vps-ip') || '10.8.0.1';
        const discordBridgePort = parseInt(parseYamlField(content, 'discord-bot.bridge-port') || '25501');
        const discordWindowsIp = parseYamlField(content, 'discord-bot.windows-ip') || '10.8.0.2';
        const discordLauncherPort = parseInt(parseYamlField(content, 'discord-bot.launcher-port') || '25500');
        const discordProxyPort = parseInt(parseYamlField(content, 'discord-bot.proxy-port') || '25565');
        const discordMinecraftPort = parseInt(parseYamlField(content, 'discord-bot.minecraft-port') || '25565');
        const discordRestartScript = parseYamlField(content, 'discord-bot.restart-script') || 'start.bat';
        
        const integer = (key, fallback) => parseInt(parseYamlField(content, key) || String(fallback), 10);
        const thresholds = {};
        const thresholdKeys = { mobKills: 'friendly-mob-kills', itemDrops: 'item-drops-stacks', advancements: 'advancements', liquidPlacements: 'liquid-placements', tntPlacements: 'tnt-placements', explodedContainers: 'exploded-containers', arsonAttempts: 'arson-attempts', entityGriefing: 'entity-griefing', signPlacements: 'sign-placements', playerKills: 'player-kills', tamedMobKills: 'tamed-mob-kills', tamedMobDamage: 'tamed-mob-damage', endCrystalExplosions: 'end-crystal-explosions', rareBlockBreaks: 'rare-block-breaks', bedTraps: 'bed-traps' };
        Object.entries(thresholdKeys).forEach(([key, yamlKey]) => { thresholds[key] = integer(`grief-detection.thresholds.${yamlKey}`, 5); });
        const categories = {};
        ['MOB_KILL','ITEM_DROP','ADVANCEMENT','CONTAINER_BREAK','LIQUID_PLACE','TNT_PLACE','END_CRYSTAL_EXPLODE','ARSON','ENTITY_GRIEF','TAMED_MOB_KILL','TAMED_MOB_DAMAGE','RARE_BLOCK','SIGN_PLACE','PVP_KILL','BED_TRAP'].forEach(key => { categories[key] = parseYamlField(content, `grief-detection.enabled-categories.${key}`) !== 'false'; });
        const profile = name => ({
            timeWindowMinutes: integer(`grief-detection.profiles.${name}.time-window-minutes`, name === 'normal' ? integer('grief-detection.time-window-minutes', 15) : 5),
            maxWarnings: integer(`grief-detection.profiles.${name}.max-warnings`, name === 'normal' ? integer('grief-detection.max-warnings', 5) : 9),
            notifyAt: integer(`grief-detection.profiles.${name}.notify-at`, name === 'normal' ? 0 : 7),
            markAtWarnings: integer(`grief-detection.profiles.${name}.mark-at-warnings`, name === 'normal' ? 1 : 4),
            fastBanWarningsPerMinute: integer(`grief-detection.profiles.${name}.fast-ban-warnings-per-minute`, name === 'normal' ? 3 : 4)
        });
        const fastBan = { enabled: parseYamlField(content, 'grief-detection.fast-ban.enabled') === 'true', windowSeconds: integer('grief-detection.fast-ban.window-seconds', 60), requirePotentialDanger: parseYamlField(content, 'grief-detection.fast-ban.require-potential-danger') !== 'false' };
        const discordFeatureDefaults = { serverStatus: ['server-status','minecraft-information','everyone'], playerEvents: ['player-events','minecraft-information','everyone'], commandSync: ['command-sync','minecraft-cmd','admin'], griefAlerts: ['grief-alerts','minecraft-grief','admin'], serverErrors: ['server-errors','minecraft-serverdata','admin'] };
        const discordFeatures = {};
        Object.entries(discordFeatureDefaults).forEach(([key, [yamlKey, channel, access]]) => { discordFeatures[key] = { enabled: parseYamlField(content, `discord-bot.features.${yamlKey}.enabled`) === 'true', channel: parseYamlField(content, `discord-bot.features.${yamlKey}.channel`) || channel, access: parseYamlField(content, `discord-bot.features.${yamlKey}.access`) || access }; });
        const backupWorldCount = detectedBackupWorldCount();
        return res.json({ autoBan, autoRollback, backupStrategy: 'all-worlds', backupStorageLocation: parseYamlField(content, 'backup.storage-location') || 'server-root', backupCustomDirectory: parseYamlField(content, 'backup.custom-directory') || 'Backups', backupWorldCount, backupRetentionLimit: backupRetentionLimit(backupWorldCount), banReason, discordEnabled, discordTokenConfigured: Boolean(discordToken), discordFeatures, discordBridgeMode, discordVpsIp, discordBridgePort, discordWindowsIp, discordLauncherPort, discordProxyPort, discordMinecraftPort, discordRestartScript, rateLimitEnabled: parseYamlField(content, 'rate-limiting.enabled') !== 'false', ddosLimit: integer('rate-limiting.max-connections-per-second', 5), profiles: { normal: profile('normal'), relaxed: profile('relaxed') }, fastBan, thresholds, categories });
    } catch (e) {
        console.error("Failed to read config.yml:", e);
        return res.status(500).json({ error: "Failed to read configuration file." });
    }
});

app.post('/api/config', auth, (req, res) => {
    const configPath = findConfigYmlPath();
    if (!configPath) {
        return res.status(404).json({ error: "config.yml not found." });
    }
    
    try {
        const { autoBan, autoRollback, backupStorageLocation, backupCustomDirectory, banReason, discordEnabled, discordToken, discordFeatures = {}, discordBridgeMode, discordVpsIp, discordBridgePort, discordWindowsIp, discordLauncherPort, discordProxyPort, discordMinecraftPort, discordRestartScript, rateLimitEnabled, ddosLimit, profiles = {}, fastBan = {}, thresholds = {}, categories = {} } = req.body;
        const invalid = message => { const error = new Error(message); error.statusCode = 400; throw error; };
        const booleanValue = (value, label) => typeof value === 'boolean' ? value : invalid(`${label} のON/OFF値が不正です。`);
        const integerValue = (value, label, min, max) => {
            try { return schemaInteger(value, label, [min, max]); }
            catch (error) { invalid(error.message); }
        };
        const autoBanValue = booleanValue(autoBan, '自動BAN');
        const autoRollbackValue = booleanValue(autoRollback, '自動ロールバック');
        const backupStorageLocationValue = String(backupStorageLocation || '').trim();
        if (!['server-root', 'plugin-data', 'custom'].includes(backupStorageLocationValue)) invalid('バックアップ先の種類が不正です。');
        const backupCustomDirectoryValue = backupStorageLocationValue === 'custom'
            ? validateBackupCustomDirectory(backupCustomDirectory)
            : (String(backupCustomDirectory || 'Backups').trim() || 'Backups');
        const discordEnabledValue = booleanValue(discordEnabled, 'Discord Bot');
        const discordBridgeModeValue = booleanValue(discordBridgeMode, 'Agentブリッジ');
        const rateLimitEnabledValue = booleanValue(rateLimitEnabled, '接続レート制限');
        const banReasonValue = String(banReason ?? '').trim();
        if (!banReasonValue || Array.from(banReasonValue).length > 500) invalid('BANメッセージは1〜500文字で入力してください。');
        const bridgePortValue = integerValue(discordBridgePort, 'Bridge Port', 1, 65535);
        const launcherPortValue = integerValue(discordLauncherPort, 'Launcher Port', 1, 65535);
        const proxyPortValue = integerValue(discordProxyPort, '公開Proxy Port', 1, 65535);
        const minecraftPortValue = integerValue(discordMinecraftPort, 'Minecraft Port', 1, 65535);
        const ddosLimitValue = integerValue(ddosLimit, 'DDoS接続上限', 1, 100000);
        let content = fs.readFileSync(configPath, 'utf8');
        
        content = writeYamlField(content, 'auto-action.auto-ban', autoBanValue);
        content = writeYamlField(content, 'auto-action.auto-rollback', autoRollbackValue);
        content = writeYamlField(content, 'backup.storage-location', yamlString(backupStorageLocationValue));
        content = writeYamlField(content, 'backup.custom-directory', yamlString(backupCustomDirectoryValue));
        content = content.replace(/^  max-retention:.*\r?\n?/m, '');
        content = writeYamlField(content, 'ban-reason', yamlString(banReasonValue));
        content = writeYamlField(content, 'discord-bot.enabled', discordEnabledValue);
        // Secrets are write-only: a blank field means "keep the saved value".
        if (String(discordToken || '').trim()) content = writeYamlField(content, 'discord-bot.token', yamlString(discordToken));
        const discordFeatureKeys = { serverStatus: 'server-status', playerEvents: 'player-events', commandSync: 'command-sync', griefAlerts: 'grief-alerts', serverErrors: 'server-errors' };
        Object.entries(discordFeatureKeys).forEach(([key, yamlKey]) => {
            const feature = discordFeatures[key] || {};
            const channel = String(feature.channel || '').replace(/^#/, '').toLowerCase();
            if (!/^[a-z0-9_-]{1,100}$/.test(channel)) invalid(`Discordチャンネル名が不正です: ${key}`);
            if (!['everyone', 'admin'].includes(feature.access)) invalid(`Discord閲覧範囲が不正です: ${key}`);
            content = writeYamlField(content, `discord-bot.features.${yamlKey}.enabled`, booleanValue(feature.enabled, `${key}通知`));
            content = writeYamlField(content, `discord-bot.features.${yamlKey}.channel`, yamlString(channel));
            content = writeYamlField(content, `discord-bot.features.${yamlKey}.access`, yamlString(feature.access));
        });
        content = writeYamlField(content, 'discord-bot.bridge-mode', discordBridgeModeValue);
        content = writeYamlField(content, 'discord-bot.vps-ip', yamlString(discordVpsIp));
        content = writeYamlField(content, 'discord-bot.bridge-port', bridgePortValue);
        content = writeYamlField(content, 'discord-bot.windows-ip', yamlString(discordWindowsIp));
        content = writeYamlField(content, 'discord-bot.launcher-port', launcherPortValue);
        content = writeYamlField(content, 'discord-bot.proxy-port', proxyPortValue);
        content = writeYamlField(content, 'discord-bot.minecraft-port', minecraftPortValue);
        content = writeYamlField(content, 'discord-bot.restart-script', yamlString(discordRestartScript));
        
        for (const profileName of ['normal', 'relaxed']) {
            const values = profiles[profileName];
            if (!values) invalid(`${profileName}プレイヤー用の保護設定がありません。`);
            let profile;
            try { profile = validateProfile(profileName, values); }
            catch (error) { invalid(error.message); }
            const base = `grief-detection.profiles.${profileName}.`;
            content = writeYamlField(content, base + 'time-window-minutes', profile.timeWindowMinutes);
            content = writeYamlField(content, base + 'max-warnings', profile.maxWarnings);
            content = writeYamlField(content, base + 'notify-at', profile.notifyAt);
            content = writeYamlField(content, base + 'mark-at-warnings', profile.markAtWarnings);
            content = writeYamlField(content, base + 'fast-ban-warnings-per-minute', profile.fastBanWarningsPerMinute);
        }
        content = writeYamlField(content, 'grief-detection.fast-ban.enabled', booleanValue(fastBan.enabled, '高速BAN'));
        content = writeYamlField(content, 'grief-detection.fast-ban.window-seconds', integerValue(fastBan.windowSeconds, '高速BAN判定時間', 5, 3600));
        content = writeYamlField(content, 'grief-detection.fast-ban.require-potential-danger', booleanValue(fastBan.requirePotentialDanger, '高速BAN危険候補条件'));
        const thresholdKeys = { mobKills: 'friendly-mob-kills', itemDrops: 'item-drops-stacks', advancements: 'advancements', liquidPlacements: 'liquid-placements', tntPlacements: 'tnt-placements', explodedContainers: 'exploded-containers', arsonAttempts: 'arson-attempts', entityGriefing: 'entity-griefing', signPlacements: 'sign-placements', playerKills: 'player-kills', tamedMobKills: 'tamed-mob-kills', tamedMobDamage: 'tamed-mob-damage', endCrystalExplosions: 'end-crystal-explosions', rareBlockBreaks: 'rare-block-breaks', bedTraps: 'bed-traps' };
        Object.entries(thresholdKeys).forEach(([key, yamlKey]) => { if (thresholds[key] != null) content = writeYamlField(content, `grief-detection.thresholds.${yamlKey}`, integerValue(thresholds[key], `${key}しきい値`, 1, 1000000)); });
        Object.entries(categories).forEach(([key, value]) => { if (/^[A-Z_]+$/.test(key)) content = writeYamlField(content, `grief-detection.enabled-categories.${key}`, booleanValue(value, `${key}検知`)); });
        content = writeYamlField(content, 'rate-limiting.enabled', rateLimitEnabledValue);
        content = writeYamlField(content, 'rate-limiting.max-connections-per-second', ddosLimitValue);
        
        fs.writeFileSync(configPath, content, 'utf8');
        console.log(`[GriefGuard Mobile] Saved configuration updates to ${configPath}`);
        
        return res.json({ success: true });
    } catch (e) {
        console.error("Failed to update config.yml:", e);
        return res.status(e.statusCode || 500).json({ error: e.statusCode ? e.message : "Failed to write configuration file." });
    }
});

// ----------------------------------------------------
// SERVER.PROPERTIES INTERACTIVE CONTROLLERS
// ----------------------------------------------------
function getPropertiesPath() { return serverPath('server.properties'); }

const SERVER_PROPERTY_SCHEMA = [
    { key: 'difficulty', property: 'difficulty', label: '難易度', description: '敵の強さと空腹・ダメージの難易度', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'select', default: 'easy', options: [{ value: 'peaceful', label: 'ピースフル' }, { value: 'easy', label: 'イージー' }, { value: 'normal', label: 'ノーマル' }, { value: 'hard', label: 'ハード' }] },
    { key: 'gamemode', property: 'gamemode', label: 'デフォルトゲームモード', description: '新規参加プレイヤーの初期モード', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'select', default: 'survival', options: [{ value: 'survival', label: 'サバイバル' }, { value: 'creative', label: 'クリエイティブ' }, { value: 'adventure', label: 'アドベンチャー' }, { value: 'spectator', label: 'スペクテイター' }] },
    { key: 'forceGamemode', property: 'force-gamemode', label: 'ゲームモードを強制', description: '接続時にデフォルトモードへ戻す', info: 'ONにすると、管理者が個別に変更したゲームモードも再接続時にデフォルトへ戻る場合があります。', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'boolean', default: false },
    { key: 'hardcore', property: 'hardcore', label: 'ハードコア', description: '死亡時にスペクテイターモードへ移行', info: '既存ワールドで有効にすると、死亡したプレイヤーが通常のサバイバルへ戻れなくなります。運用開始後の変更は慎重に行ってください。', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'boolean', default: false },
    { key: 'pvp', property: 'pvp', label: 'PvPを許可', description: 'プレイヤー同士の攻撃を許可', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'boolean', default: true },
    { key: 'spawnProtection', property: 'spawn-protection', label: 'スポーン保護範囲', description: '初期スポーン周辺の保護半径（0で無効）', info: 'バニラのスポーン保護は主に非OPプレイヤーへ適用されます。保護プラグインを使用している場合は範囲が重複することがあります。', group: 'ゲームプレイ', groupDescription: '参加時の基本ルール', icon: '⚔️', type: 'number', default: 16, min: 0, max: 10000 },

    { key: 'motd', property: 'motd', label: 'サーバー説明 (MOTD)', description: 'サーバー一覧に表示するメッセージ', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'text', default: 'A Minecraft Server' },
    { key: 'maxPlayers', property: 'max-players', label: '最大プレイヤー数', description: '同時接続できる人数', info: 'ここで設定した人数はPaper側の上限です。実際に安定して接続できる人数は、Windows・LinuxなどのOS、レンタルサーバーのプラン、CPU・メモリ・回線速度、ファイアウォールやルーターの設定によって少なくなる場合があります。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'number', default: 20, min: 1, max: 1000 },
    { key: 'onlineMode', property: 'online-mode', label: '正規アカウント認証', description: 'Mojang / Microsoft の認証を必須にする', info: '通常はONを推奨します。OFFにすると名前の偽装で参加される危険があります。Velocityなどのプロキシ構成では、プロキシ側の認証・転送設定も必要です。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: true },
    { key: 'whitelist', property: 'white-list', label: 'ホワイトリスト', description: '許可済みプレイヤーのみ参加可能', info: 'ONにしただけでは誰も追加されません。下の許可プレイヤー一覧へJava版名、またはGeyserMC用の先頭「.」付き名を登録してください。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: false },
    { key: 'enforceWhitelist', property: 'enforce-whitelist', label: 'ホワイトリストを即時強制', description: '未登録プレイヤーをリロード時に退出させる', info: 'ONの場合、許可リストから削除されたオンラインプレイヤーはホワイトリスト再読み込み時に退出します。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: false },
    { key: 'allowFlight', property: 'allow-flight', label: '飛行を許可', description: '飛行判定による自動キックを無効化', info: 'クリエイティブ飛行を許可する設定ではなく、飛行を検知した際の自動キックを無効にする設定です。飛行系プラグインやMODを使う場合にONにします。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: false },
    { key: 'enableStatus', property: 'enable-status', label: 'サーバーステータスを公開', description: 'サーバー一覧からの状態照会に応答', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: true },
    { key: 'hideOnlinePlayers', property: 'hide-online-players', label: 'オンライン人数を非表示', description: 'ステータス応答のプレイヤー一覧を隠す', info: 'サーバー一覧の応答からプレイヤー情報を隠します。GriefGuard管理画面内のオンライン人数同期には影響しません。', group: '接続とアクセス', groupDescription: '公開範囲と参加制限', icon: '🔗', type: 'boolean', default: false },

    { key: 'viewDistance', property: 'view-distance', label: '描画距離', description: 'クライアントへ送信するチャンク半径', info: '大きいほど遠くまで見えますが、サーバーのメモリ使用量と通信量が増えます。人数が多い環境では小さめの値が安定します。', group: 'パフォーマンス', groupDescription: '負荷と通信量の調整', icon: '📊', type: 'number', default: 10, min: 2, max: 32 },
    { key: 'simulationDistance', property: 'simulation-distance', label: 'シミュレーション距離', description: 'Mobや作物を処理するチャンク半径', info: '描画距離とは別に、Mob・レッドストーン・作物などを動作させる範囲です。値を上げるとCPU負荷が増えます。', group: 'パフォーマンス', groupDescription: '負荷と通信量の調整', icon: '📊', type: 'number', default: 10, min: 2, max: 32 },
    { key: 'networkCompressionThreshold', property: 'network-compression-threshold', label: '圧縮しきい値', description: '通信圧縮を始めるパケットサイズ（byte）', info: '小さくすると通信量を減らせますがCPU負荷が増えます。-1は圧縮無効です。通常は初期値の256を推奨します。', group: 'パフォーマンス', groupDescription: '負荷と通信量の調整', icon: '📊', type: 'number', default: 256, min: -1, max: 65535 },
    { key: 'playerIdleTimeout', property: 'player-idle-timeout', label: '無操作タイムアウト', description: '自動退出までの分数（0で無効）', group: 'パフォーマンス', groupDescription: '負荷と通信量の調整', icon: '📊', type: 'number', default: 0, min: 0, max: 10080 },
    { key: 'syncChunkWrites', property: 'sync-chunk-writes', label: 'チャンクを同期保存', description: '安全性を優先してチャンクを書き込む', info: 'ONはクラッシュ時のデータ破損リスクを抑えますが、ストレージが遅い環境では保存時の負荷が増える場合があります。通常はONを推奨します。', group: 'パフォーマンス', groupDescription: '負荷と通信量の調整', icon: '📊', type: 'boolean', default: true }
];

function ensurePropertiesFile() {
    const propertiesPath = getPropertiesPath();
    if (!fs.existsSync(propertiesPath)) {
        const defaultProps = `# Minecraft server properties
difficulty=easy
gamemode=survival
pvp=true
white-list=false
allow-flight=false
max-players=20
`;
        fs.writeFileSync(propertiesPath, defaultProps, 'utf8');
        console.log("[GriefGuard Mobile] server.properties file initialized with default configuration.");
    }
}

function parseProperties(content) {
    const props = {};
    const lines = content.split(/\r?\n/);
    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('#') || trimmed === '') continue;
        const index = trimmed.indexOf('=');
        if (index !== -1) {
            const key = trimmed.substring(0, index).trim();
            const value = trimmed.substring(index + 1).trim();
            props[key] = value;
        }
    }
    return props;
}

function writeProperty(content, key, value) {
    const regex = new RegExp(`^(\\s*${key}\\s*=\\s*)(.*)$`, 'm');
    if (content.match(regex)) {
        return content.replace(regex, (match, prefix) => `${prefix}${value}`);
    } else {
        return content.trimEnd() + `\n${key}=${value}\n`;
    }
}

app.get('/api/server-properties/schema', (req, res) => {
    return res.json({ schema: SERVER_PROPERTY_SCHEMA.map(({ property, ...field }) => field) });
});

app.get('/api/server-properties', auth, (req, res) => {
    try {
        ensurePropertiesFile();
        const propertiesPath = getPropertiesPath();
        const content = fs.readFileSync(propertiesPath, 'utf8');
        const props = parseProperties(content);
        
        const values = {};
        for (const field of SERVER_PROPERTY_SCHEMA) {
            const raw = props[field.property];
            if (field.type === 'boolean') values[field.key] = raw === undefined ? field.default : raw === 'true';
            else if (field.type === 'number') values[field.key] = raw === undefined ? field.default : Number(raw);
            else {
                // Java properties may escape ':' as '\\:' (Paper writes
                // minecraft\\:normal). The UI uses the unescaped Minecraft ID.
                values[field.key] = raw === undefined ? field.default : (field.type === 'select' ? raw.replace(/\\:/g, ':') : raw);
            }
        }
        const levelName = props['level-name'] || 'world';
        const worldExists = fs.existsSync(serverPath(levelName, 'level.dat'));
        return res.json({ values, schema: SERVER_PROPERTY_SCHEMA.map(({ property, ...field }) => field), worldExists });
    } catch (e) {
        console.error("Failed to read server.properties:", e);
        return res.status(500).json({ error: "Failed to read server properties." });
    }
});

app.post('/api/server-properties', auth, (req, res) => {
    try {
        ensurePropertiesFile();
        const propertiesPath = getPropertiesPath();
        let content = fs.readFileSync(propertiesPath, 'utf8');

        for (const field of SERVER_PROPERTY_SCHEMA) {
            let value = req.body[field.key];
            if (value === undefined) return res.status(400).json({ error: `${field.label} が不足しています。` });
            if (field.type === 'boolean' && typeof value !== 'boolean') return res.status(400).json({ error: `${field.label} の値が不正です。` });
            if (field.type === 'number') {
                value = Number(value);
                if (!Number.isFinite(value) || value < field.min || value > field.max) return res.status(400).json({ error: `${field.label} は ${field.min}〜${field.max} の範囲で入力してください。` });
                value = Math.trunc(value);
            }
            if (field.type === 'select' && !field.options.some(option => option.value === value)) return res.status(400).json({ error: `${field.label} の選択値が不正です。` });
            if (field.type === 'text') {
                value = String(value).replace(/[\r\n]/g, ' ').trim();
                if (field.key === 'levelName' && !/^[a-zA-Z0-9._-]+$/.test(value)) return res.status(400).json({ error: 'ワールド名には英数字・ピリオド・ハイフン・アンダースコアのみ使用できます。' });
                if (value.length > 200) return res.status(400).json({ error: `${field.label} は200文字以内で入力してください。` });
            }
            content = writeProperty(content, field.property, value);
        }
        
        fs.writeFileSync(propertiesPath, content, 'utf8');
        console.log("[GriefGuard Mobile] server.properties updated successfully.");
        
        return res.json({ success: true });
    } catch (e) {
        console.error("Failed to update server.properties:", e);
        return res.status(500).json({ error: "Failed to write server properties." });
    }
});

const server = http.createServer(app);
wss = new WebSocket.Server({ server });

// A port conflict used to surface as an unhandled ws error and a long Node
// stack trace. The Agent cannot provide a management screen without its HTTP
// listener, so report a direct recovery action and exit cleanly instead.
let listenerFailureHandled = false;
function handleListenerFailure(error) {
    if (listenerFailureHandled) return;
    listenerFailureHandled = true;
    const detail = error.code === 'EADDRINUSE'
        ? 'ポート3000は既に別のGriefGuard Agentまたはアプリが使用しています。既存のAgentを終了してから再実行してください。'
        : `ポート3000を開始できません: ${error.message}`;
    console.error(`[Agent] ${detail}`);
    process.exitCode = 1;
    try { wss.close(); } catch (_) {}
    try { pluginBridge.server?.close(); } catch (_) {}
    setTimeout(() => process.exit(1), 50).unref();
}
server.on('error', handleListenerFailure);
wss.on('error', handleListenerFailure);

wss.on('connection', (ws, req) => {
    console.log("[WS] Client connected.");
    
    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            if (data.type === 'auth') {
                if (isActiveSession(data.token)) {
                    ws.isAuthorized = true;
                    ws.send(JSON.stringify({ type: 'status', message: "Authorized. Live logs streaming..." }));
                } else {
                    ws.send(JSON.stringify({ type: 'error', message: "Unauthorized token." }));
                    ws.close();
                }
            }
        } catch (e) {
            console.error("[WS] Error parsing message:", e);
        }
    });
    
    ws.on('close', () => {
        console.log("[WS] Client disconnected.");
    });
});

// Mobile browsers frequently suspend background WebSocket connections. A
// heartbeat removes dead sockets promptly and lets the normal reconnect path
// restore live progress after the device wakes up.
const websocketHeartbeat = setInterval(() => {
    if (!wss) return;
    wss.clients.forEach(ws => {
        if (ws.isAlive === false) return ws.terminate();
        ws.isAlive = false;
        try { ws.ping(); } catch (_) {}
    });
}, 30000);
websocketHeartbeat.unref();
wss.on('connection', ws => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
});

// A configurable port keeps the normal product URL stable while allowing the
// installer integration test to launch an isolated Agent without colliding
// with a user's running instance.
const PORT = Number(process.env.GRIEFGUARD_PORT || 3000);
server.listen(PORT, '0.0.0.0', () => {
    writeRuntimeMarker(PORT);
    console.log(`==================================================`);
    console.log(` GriefGuard Mobile Manager active on port ${PORT}`);
    console.log(` Access URL: http://localhost:${PORT}`);
    console.log(`==================================================`);
});
process.once('exit', removeRuntimeMarker);
process.once('SIGTERM', () => { removeRuntimeMarker(); process.exit(0); });
process.once('SIGINT', () => { removeRuntimeMarker(); process.exit(0); });
