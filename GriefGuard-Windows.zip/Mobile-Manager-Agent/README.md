# GriefGuard Mobile Manager Agent

GriefGuard Plugin と Paper サーバーを、スマートフォンまたは PC のブラウザーから安全に管理するための Agent です。配布版を使う場合は、先に `GriefGuard_Manual_JA.pdf` を読み、OS 用インストーラーを使ってください。この README は手動導入・保守用の補足です。

## 役割と接続の前提

Agent は管理画面、認証、Paper の起動停止、ログ収集、設定編集を担当します。Minecraft コマンドを実行するには **Agent / Paper / GriefGuard Plugin の3つが ONLINE** である必要があります。Agent だけが起動している状態では `/start` は使えても、`/say` や `/op` は送信できません。

```text
ブラウザー → Tailscale HTTPS または http://localhost:3000
          → Mobile Manager Agent → Bridge 25501 → GriefGuard Plugin → Paper
```

外部接続では 3000/25501 をルーター公開せず、サーバーPCと管理端末を同じ Tailscale tailnet に参加させます。Tailscale のログインと GriefGuard 管理パスワードは別の認証です。

## 配布版の導入

- Windows: `Installers/Windows/Start-GriefGuard-Setup.bat` だけを開きます。PS1を直接実行しません。
- macOS: `Installers/macOS/GriefGuard-Installer.pkg` を完了してから `GriefGuard-Setup.command` を開きます。
- 既存Paperを選ぶ時は、`paper.jar`、`server.properties`、`plugins`、`world` が直接入る最上位フォルダーをファイル選択画面から選びます。ターミナルやcmdに `cd` を入力しません。

インストール完了後、Paper の親フォルダーに `GriefGuard-HomeServer` が作られます。ここが AgentData、ログ、手動操作ファイルの場所です。`AgentData` は認証情報を含むため、削除・共有・クラウド同期・配布をしません。

詳しい説明:

- [Windows導入手順](docs/INSTALL_WINDOWS.md)
- [macOS導入手順](docs/INSTALL_MACOS.md)
- [ファイル生成・セキュリティ・確認表](docs/FILES_AND_SECURITY.md)

## 初回ログインと保守ファイル

新規環境では Agent が `GG-XXXX-XXXX` のセットアップコードを表示します。10分・1回限りのコードで管理パスワードを作成します。初回コードを見失った時、管理パスワードを忘れた時、または Agent を保守する時は、`GriefGuard-HomeServer` 内に作られた次のファイルを使います。

- `Show-GriefGuard-Setup-Code.<bat|command>`: 初回設定が未完了の時だけコードを再表示
- `Reset-GriefGuard-Admin-Password.<bat|command>`: パスワードリセット用 RS コードを発行
- `Start-GriefGuard-Agent.<bat|command>` / `Stop-GriefGuard-Agent.<bat|command>`: Agent の手動開始・正常停止
- `Restart-GriefGuard-Agent.<bat|command>` / `Agent-Status.<bat|command>` / `View-Agent-Log.<bat|command>`: 保守
- `Continue-Tailscale-Setup.<bat|command>`: Tailscale を後回しにした時だけ再開
- `Repair-BlueMap.<bat|command>`: BlueMap を未導入・同意待ち・破損状態から修復

OSログイン時の自動起動はインストーラーが登録します。同じ AgentData の Agent がすでに有効なら二重起動しません。通常は Agent を停止・再起動しても、既存の Tailscale HTTPS URL と管理パスワードは変わりません。

## 手動導入・開発時だけ

```bash
npm install
npm start
```

ローカル画面は `http://localhost:3000` です。管理パスワードを忘れた時だけ、Agent フォルダーで `npm run password-reset` を実行します。セットアップコード、RSコード、管理パスワード、Discord Bot Token を第三者に渡さないでください。

## 設定ファイルの扱い

導入済みPluginは `plugins/` のJARと設定フォルダーから検出します。`.yml`、`.yaml`、`.json`、`.toml`、`.conf`、`.properties`、`.txt` を折りたたみ画面で開けます。YAML/JSONの単純な値はフォーム編集、それ以外の複雑な構造は上級者向け直接編集を使います。保存時には `.bak` を作成します。

GriefGuard には専用UIがあります。通常・緩和プレイヤー、各検知カテゴリのすべてのしきい値、Flash BAN、自動BAN、自動ロールバック、バックアップ先を変更できます。数値のしきい値は0や負数に保存できません。変更後は「保存」、反映時期が不明な場合は「保存して再起動」を使います。

## Java・Paperの互換性

インストーラーと `Update-Paper` は必要Javaを判定し、OSに利用可能なJavaがあれば再利用します。不足時だけ `GriefGuard-HomeServer/runtime` にランタイムを置きます。

| Paper | Java | 実起動確認 |
| --- | --- | --- |
| 1.17.1〜1.20.4 | 17 | 1.17.1 / 1.20.4 |
| 1.20.5〜1.21.x | 21 | 1.21.11 |
| 26.x | 25 | 26.1.2 |

Paper更新では公式安定版だけを選びます。自動管理対象の GriefGuard、GeyserMC、Floodgate、ViaVersion、BlueMap は必要な時だけ互換版へ更新し、手動導入Pluginは削除せず注意を表示します。
