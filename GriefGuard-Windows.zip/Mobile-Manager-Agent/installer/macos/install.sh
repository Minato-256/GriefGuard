#!/bin/sh
# Run from the signed macOS release bundle. This is the functional installer
# fallback until the pkg is signed and notarized on macOS.
set -eu
printf '%s\n' 'GriefGuard Manager macOS installer'
printf 'Paper server folder: '
read -r SERVER_DIRECTORY
printf 'Workspace folder (recommended: /Users/Shared/GriefGuardServers/HomeServer): '
read -r WORKSPACE_DIRECTORY
printf 'Paper jar file name: '
read -r PAPER_JAR
SCRIPT_DIRECTORY="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
node "$SCRIPT_DIRECTORY/scripts/create-workspace.js" --workspace "$WORKSPACE_DIRECTORY" --server-dir "$SERVER_DIRECTORY" --paper-jar "$PAPER_JAR"
printf '%s\n' 'Workspace was created. Start the bundled Agent with GRIEFGUARD_AGENT_DATA_DIR set to Workspace/AgentData.'
