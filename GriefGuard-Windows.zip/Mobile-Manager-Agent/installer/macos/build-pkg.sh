#!/bin/sh
# Build only on macOS after signing identities and the release payload exist.
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PAYLOAD="$PACKAGE_ROOT/../../dist/macos-payload"
OUTPUT="$PACKAGE_ROOT/../../dist/GriefGuard-Installer.pkg"
pkgbuild --root "$PAYLOAD" --identifier "jp.griefguard.manager" --version "1.1.0" "$OUTPUT"
printf 'Created %s\n' "$OUTPUT"
