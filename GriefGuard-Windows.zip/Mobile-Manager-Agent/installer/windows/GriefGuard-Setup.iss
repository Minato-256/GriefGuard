; Inno Setup source. Build on Windows after placing the release Agent under
; dist\agent and GriefGuard.jar under dist\plugin. Do not ship node_modules as
; a user-managed dependency: the release package includes its pinned runtime.
#define ProductName "GriefGuard Manager"
#define ProductVersion "1.1.0"
[Setup]
AppName={#ProductName}
AppVersion={#ProductVersion}
DefaultDirName={autopf}\GriefGuard Manager
PrivilegesRequired=admin
OutputBaseFilename=GriefGuard-Setup
Compression=lzma2
SolidCompression=yes
[Files]
Source: "..\..\dist\agent\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
Source: "..\..\dist\plugin\GriefGuard.jar"; DestDir: "{code:GetServerPlugins}"; Flags: ignoreversion
[Code]
var ServerDirectory: String;
var ServerPage: TInputDirWizardPage;
function GetServerPlugins(Param: String): String;
begin
  Result := AddBackslash(ServerDirectory) + 'plugins';
end;
procedure InitializeWizard();
begin
  ServerPage := CreateInputDirPage(wpSelectDir,
    'Minecraftサーバーを選択',
    'Paperサーバーフォルダを指定してください',
    'server.properties、plugins、worldがあるPaperサーバーのフォルダを選択します。既存ワールドは移動しません。',
    False, '');
  ServerPage.Add('Paperサーバーフォルダ:');
end;
function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = ServerPage.ID then begin
    ServerDirectory := ServerPage.Values[0];
    if not FileExists(AddBackslash(ServerDirectory) + 'server.properties') then begin
      MsgBox('server.properties が見つかりません。Paperサーバーのフォルダを選択してください。', mbError, MB_OK);
      Result := False;
    end;
    if Result and not DirExists(AddBackslash(ServerDirectory) + 'plugins') then begin
      if not ForceDirectories(AddBackslash(ServerDirectory) + 'plugins') then begin
        MsgBox('pluginsフォルダを作成できません。書き込み権限を確認してください。', mbError, MB_OK);
        Result := False;
      end;
    end;
  end;
end;
