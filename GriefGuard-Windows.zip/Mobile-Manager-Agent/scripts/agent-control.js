#!/usr/bin/env node
'use strict';

// Local-only control client used by Stop-GriefGuard-Agent.bat/.command.
// It never looks up a process name or sends a signal to an arbitrary PID.
const fs = require('fs');
const http = require('http');
const path = require('path');

function fail(message) { console.error(`[ERROR] ${message}`); process.exitCode = 1; }
function argument(name) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? String(process.argv[index + 1] || '') : '';
}
function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function request(options, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, response => {
      let text = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { text += chunk; });
      response.on('end', () => resolve({ status: response.statusCode || 0, text }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}
async function main() {
  const action = argument('action');
  const agentData = argument('agent-data');
  const actions = {
    stop: '/api/local-control/stop',
    'setup-code': '/api/local-control/setup-code',
    'password-reset': '/api/local-control/password-reset-code',
    status: '/api/health'
  };
  if (!actions[action]) throw new Error('利用できる操作は stop、setup-code、password-reset、status です。');
  if (!agentData || !path.isAbsolute(agentData)) throw new Error('AgentDataの絶対パスが必要です。');
  const runtimeFile = path.join(agentData, 'runtime-instance.json');
  const tokenFile = path.join(agentData, 'agent-control-token');
  if (!fs.existsSync(runtimeFile)) throw new Error('Agentは起動していません（runtime-instance.jsonがありません）。');
  if (!fs.existsSync(tokenFile)) throw new Error('Agent制御情報が見つかりません。インストーラーを最新版で再実行してください。');
  const runtime = readJson(runtimeFile);
  const token = fs.readFileSync(tokenFile, 'utf8').trim();
  if (runtime.product !== 'GriefGuard Mobile Manager' || !/^[0-9a-f-]{36}$/i.test(String(runtime.instanceId || '')) || !Number.isInteger(Number(runtime.port))) throw new Error('Agent実行情報が不正です。安全のため停止しません。');
  const response = await request({ host: '127.0.0.1', port: Number(runtime.port), path: actions[action], method: action === 'status' ? 'GET' : 'POST', headers: action === 'status' ? {} : {
    'X-GriefGuard-Agent-Control': token,
    'X-GriefGuard-Agent-Instance': runtime.instanceId,
    'Content-Length': '0'
  }});
  let result = {};
  try { result = JSON.parse(response.text || '{}'); } catch (_) {}
  if (response.status !== 200) throw new Error(`${result.error || response.text || 'Agentから応答がありません。'} (${response.status})`);
  if (action === 'status') {
    if (result.product !== 'GriefGuard Mobile Manager' || result.instanceId !== runtime.instanceId) throw new Error('現在起動中のAgentが管理ワークスペースのものと一致しません。');
    console.log('==================================================');
    console.log(' GriefGuard Agent 状態');
    console.log(` 状態: ${result.agent}`);
    console.log(` ポート: ${result.port}`);
    console.log(` 初回設定: ${result.setupRequired ? '未完了' : '完了'}`);
    console.log(` Bridge: ${result.bridgeConnected ? '接続済み' : '未接続'}`);
    console.log('==================================================');
    return;
  }
  if (action === 'stop') {
    console.log('[OK] GriefGuard Agentへ正常停止を要求しました。');
    return;
  }
  const title = action === 'setup-code'
    ? 'GriefGuard 初回セットアップコード'
    : 'GriefGuard 管理パスワード・リセットコード';
  const next = action === 'setup-code'
    ? '管理画面でこのコードと新しい管理パスワードを入力してください。'
    : '管理画面の「パスワードを忘れた場合」でこのコードを入力してください。';
  console.log('==================================================');
  console.log(` ${title}`);
  console.log('');
  console.log(` ${result.code}`);
  console.log('');
  console.log(' 有効期限: 10分 / 1回限り / 最大5回まで');
  console.log(` ${next}`);
  console.log(` 管理画面: http://localhost:${runtime.port}`);
  console.log('==================================================');
}
main().catch(error => fail(error.message));
