#!/usr/bin/env node
/* Produces a clean, reviewable release staging directory. OS installers add
 * their signed runtime/service wrapper in CI; no live credentials are copied. */
const fs = require('fs');
const path = require('path');

const agentRoot = path.resolve(__dirname, '..');
const workspaceRoot = path.resolve(agentRoot, '..', '..');
// GriefGuard_setting/GriefGuard is the canonical Plugin project used by the
// installer. The workspace also contains an older sibling project named
// GriefGuard; packaging that JAR silently reintroduces legacy Bridge behavior.
const sourceJar = path.join(workspaceRoot, 'GriefGuard_setting', 'GriefGuard', 'target', 'GriefGuard-1.0.jar');
const dist = path.join(agentRoot, 'dist');
const destinationAgent = path.join(dist, 'agent');

if (!fs.existsSync(sourceJar)) {
    console.error('GriefGuard JARが見つかりません。先に GriefGuard_setting/GriefGuard で mvn package を実行してください。');
    process.exit(1);
}

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(destinationAgent, { recursive: true });
const releaseEntries = ['server.js', 'commands.json', 'package.json', 'package-lock.json', 'public', 'lib', 'scripts', 'docs', 'installer', 'README.md'];
for (const entry of releaseEntries) {
    const source = path.join(agentRoot, entry);
    if (!fs.existsSync(source)) continue;
    fs.cpSync(source, path.join(destinationAgent, entry), { recursive: fs.statSync(source).isDirectory() });
}
fs.mkdirSync(path.join(dist, 'plugin'), { recursive: true });
fs.copyFileSync(sourceJar, path.join(dist, 'plugin', 'GriefGuard.jar'));
fs.writeFileSync(path.join(dist, 'RELEASE-NOTES.txt'), [
    'GriefGuard release staging directory',
    'Installer builders must provide a pinned Node.js runtime and signed service wrapper.',
    'Do not add AgentData, sessions, passwords, Discord tokens, or real server data.',
    ''
].join('\n'));
console.log(`Release staging created: ${dist}`);
