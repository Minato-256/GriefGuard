#!/usr/bin/env node
/*
 * Portable Paper updater installed into each managed Paper server. It uses the
 * official Paper downloads API, verifies SHA-256 before replacement, and
 * preserves the previous runtime files for rollback.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const readline = require('readline');
const net = require('net');
const { spawnSync } = require('child_process');

const argv = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  if (process.argv[index]?.startsWith('--')) argv.set(process.argv[index].slice(2), process.argv[index + 1] || '');
}
const serverDir = path.resolve(argv.get('server-dir') || process.cwd());
const updaterDirectory = path.join(serverDir, '.griefguard');
const stateFile = path.join(updaterDirectory, 'paper-updater.json');
const policy = { minimumMinecraft: '1.21', minimumJava: 17, supportedApiVersion: '1.21' };

function exists(file) { return fs.existsSync(file); }
function fail(message) { throw new Error(message); }
function notice(message) { console.log(`[INFO] ${message}`); }
function ok(message) { console.log(`[OK] ${message}`); }
function warn(message) { console.warn(`[WARN] ${message}`); }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; } }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 }); fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 }); }
function compareVersions(left, right) { return String(left).localeCompare(String(right), undefined, { numeric: true }); }
function requiredJava(version) {
  const value = String(version || '');
  if (/^26\./.test(value)) return 25;
  if (/^1\.21\.11/.test(value)) return 21;
  if (/^1\.21\.(?:5|6|7|8|9|10)/.test(value)) return 21;
  if (/^1\.21/.test(value)) return 21;
  return 17;
}
function parseJavaMajor(executable) {
  const result = spawnSync(executable, ['-version'], { encoding: 'utf8', windowsHide: true });
  const text = `${result.stdout || ''}\n${result.stderr || ''}`;
  const match = text.match(/version\s+"?(\d+)(?:\.|"|\s)/i);
  return match ? Number(match[1]) : 0;
}
function shellQuote(value) { return `'${String(value).replace(/'/g, `'\\''`)}'`; }
function launcherText(jar, min, max, port, javaExecutable, managedUpdater = null) {
  const updateBat = '';
  const updateCommand = '';
  const bat = `@echo off\r\nrem GriefGuard managed Paper launcher\r\nsetlocal\r\nset "PAPER_JAR=${jar}"\r\nset "MIN_MEMORY=${min}"\r\nset "MAX_MEMORY=${max}"\r\nset "SERVER_PORT=${port}"\r\nset "JAVA_EXECUTABLE=${javaExecutable}"\r\ncd /d "%~dp0"\r\nif not exist "%PAPER_JAR%" exit /b 10\r\n${updateBat}"%JAVA_EXECUTABLE%" -Xms%MIN_MEMORY% -Xmx%MAX_MEMORY% -jar "%PAPER_JAR%" --nogui\r\nexit /b %ERRORLEVEL%\r\n`;
  const command = `#!/bin/sh\nPAPER_JAR="${jar}"\nMIN_MEMORY="${min}"\nMAX_MEMORY="${max}"\nSERVER_PORT="${port}"\nJAVA_EXECUTABLE="${javaExecutable}"\nset -eu\nSERVER_DIRECTORY="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"\ncd "$SERVER_DIRECTORY"\n[ -f "$PAPER_JAR" ] || exit 10\n${updateCommand}exec "$JAVA_EXECUTABLE" -Xms"$MIN_MEMORY" -Xmx"$MAX_MEMORY" -jar "$PAPER_JAR" --nogui\n`;
  return { bat, command };
}
async function ask(question, fallback = '') {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const answer = await new Promise(resolve => rl.question(`${question}${fallback ? ` [${fallback}]` : ''}: `, resolve));
  rl.close();
  return answer.trim() || fallback;
}
async function choose(question, choices, fallback) {
  console.log(`\n${question}`);
  choices.forEach(([number, label]) => console.log(`  ${number}. ${label}`));
  const result = await ask('番号を選択', fallback);
  return choices.some(([number]) => number === result) ? result : fallback;
}
async function fetchJson(url) {
  const response = await fetch(url, { headers: { 'User-Agent': 'GriefGuard-Paper-Updater/1.0', Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
  if (!response.ok) fail(`Paper公式APIへ接続できません: HTTP ${response.status}`);
  return response.json();
}
async function stableBuild(version) {
  const builds = await fetchJson(`https://fill.papermc.io/v3/projects/paper/versions/${encodeURIComponent(version)}/builds`);
  const stable = Array.isArray(builds) ? builds.filter(build => build.channel === 'STABLE').sort((a, b) => Number(b.id || 0) - Number(a.id || 0))[0] : null;
  const asset = stable?.downloads?.['server:default'];
  if (!asset?.url || !asset?.checksums?.sha256) return null;
  return { version, build: stable.id, url: asset.url, sha256: asset.checksums.sha256, size: asset.size || 0 };
}
async function stableVersions() {
  const project = await fetchJson('https://fill.papermc.io/v3/projects/paper');
  const versions = [...new Set(Object.values(project.versions || {}).flat())]
    .filter(version => /^\d+(?:\.\d+){1,2}$/.test(version) && compareVersions(version, policy.minimumMinecraft) >= 0)
    .sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
  const candidates = await Promise.all(versions.slice(0, 40).map(stableBuild));
  return candidates.filter(Boolean);
}
function serverPort() {
  const properties = path.join(serverDir, 'server.properties');
  const match = exists(properties) && fs.readFileSync(properties, 'utf8').match(/^server-port=(\d+)$/m);
  return match ? Number(match[1]) : 25565;
}
async function portInUse(port) {
  return new Promise(resolve => {
    const socket = net.createConnection({ host: '127.0.0.1', port });
    socket.setTimeout(700);
    socket.once('connect', () => { socket.destroy(); resolve(true); });
    socket.once('error', () => resolve(false));
    socket.once('timeout', () => { socket.destroy(); resolve(false); });
  });
}
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function backupRuntime(state) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const directory = path.join(updaterDirectory, 'update-backups', stamp);
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const files = ['paper.jar', 'start.bat', 'start.command', 'server.properties'];
  const manifest = { createdAt: new Date().toISOString(), files: [] };
  for (const name of files) {
    const source = path.join(serverDir, name);
    if (!exists(source)) continue;
    const destination = path.join(directory, name);
    fs.copyFileSync(source, destination);
    manifest.files.push({ name, sha256: sha256(destination) });
  }
  writeJson(path.join(directory, 'update-manifest.json'), manifest);
  return directory;
}
function jarTool(javaExecutable) {
  if (javaExecutable && javaExecutable !== 'java') {
    const candidate = path.join(path.dirname(javaExecutable), process.platform === 'win32' ? 'jar.exe' : 'jar');
    if (exists(candidate)) return candidate;
  }
  return process.platform === 'win32' ? 'jar.exe' : 'jar';
}
function parseDescriptor(text) {
  const field = name => (text.match(new RegExp(`^${name}:\\s*['\"]?([^\\n'\"]+)`, 'mi')) || [])[1]?.trim() || '';
  return { name: field('name'), version: field('version'), apiVersion: field('api-version') };
}
function inspectPlugins(targetVersion, javaExecutable) {
  const directory = path.join(serverDir, 'plugins');
  if (!exists(directory)) return [];
  const tool = jarTool(javaExecutable);
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'griefguard-plugin-inspect-'));
  const results = [];
  try {
    for (const file of fs.readdirSync(directory).filter(name => /\.jar$/i.test(name))) {
      const source = path.join(directory, file);
      const listed = spawnSync(tool, ['tf', source], { encoding: 'utf8', windowsHide: true });
      const names = String(listed.stdout || '').split(/\r?\n/);
      const descriptorName = names.includes('paper-plugin.yml') ? 'paper-plugin.yml' : names.includes('plugin.yml') ? 'plugin.yml' : '';
      if (!descriptorName) { results.push({ file, level: 'unknown', reason: 'plugin.ymlを確認できません' }); continue; }
      const perPlugin = path.join(temporary, crypto.randomUUID());
      fs.mkdirSync(perPlugin);
      const extracted = spawnSync(tool, ['xf', source, descriptorName], { cwd: perPlugin, encoding: 'utf8', windowsHide: true });
      const descriptor = extracted.status === 0 ? parseDescriptor(fs.readFileSync(path.join(perPlugin, descriptorName), 'utf8')) : {};
      const apiVersion = descriptor.apiVersion || '';
      const level = apiVersion && compareVersions(apiVersion, targetVersion) > 0 ? 'warning' : 'unknown';
      results.push({ file, name: descriptor.name || file, version: descriptor.version || '', apiVersion, level, reason: level === 'warning' ? `API ${apiVersion} は更新先Minecraft ${targetVersion}より新しいため非互換の可能性があります` : apiVersion ? `API ${apiVersion}。上限互換性はJAR内から判定できません` : 'api-versionがないため互換性を判定できません' });
    }
  } finally { fs.rmSync(temporary, { recursive: true, force: true }); }
  return results;
}
async function downloadBuild(build, destination) {
  const temporary = `${destination}.download`;
  const response = await fetch(build.url, { headers: { 'User-Agent': 'GriefGuard-Paper-Updater/1.0' }, signal: AbortSignal.timeout(120000) });
  if (!response.ok || !response.body) fail(`Paperのダウンロードに失敗しました: HTTP ${response.status}`);
  const data = Buffer.from(await response.arrayBuffer());
  const actual = crypto.createHash('sha256').update(data).digest('hex');
  if (actual.toLowerCase() !== String(build.sha256).toLowerCase()) fail('PaperのSHA-256検証に失敗しました。現在のPaperは変更していません。');
  fs.writeFileSync(temporary, data, { mode: 0o600 });
  fs.renameSync(temporary, destination);
}
async function main() {
  if (!exists(path.join(serverDir, 'paper.jar'))) fail(`paper.jarが見つかりません: ${serverDir}`);
  const state = readJson(stateFile, {});
  const port = Number(state.serverPort || serverPort());
  if (await portInUse(port)) fail(`Java版ポート ${port} は使用中です。Paperコンソールで stop を実行し、完全に停止してから更新してください。`);
  const javaExecutable = state.javaExecutable || 'java';
  const currentJava = parseJavaMajor(javaExecutable);
  if (!currentJava) fail(`Javaを確認できません: ${javaExecutable}`);
  const candidates = await stableVersions();
  if (!candidates.length) fail('対応する公式安定版Paperを取得できませんでした。ネットワークを確認してください。');
  console.log(`\nGriefGuard対応の公式安定版（Minecraft ${policy.minimumMinecraft}以上）:`);
  candidates.slice(0, 15).forEach((build, index) => console.log(`  ${index + 1}. Minecraft ${build.version}（Paper build ${build.build} / Java ${requiredJava(build.version)}以上）`));
  console.log(`  ${Math.min(candidates.length, 15) + 1}. 更新しない`);
  const cancel = String(Math.min(candidates.length, 15) + 1);
  const choice = await choose('更新先を選択', [...candidates.slice(0, 15).map((build, index) => [String(index + 1), `Minecraft ${build.version}`]), [cancel, '更新しない']], '1');
  if (choice === cancel) { notice('更新を中止しました。'); return; }
  const selected = candidates[Number(choice) - 1] || candidates[0];
  const required = requiredJava(selected.version);
  if (currentJava < required) fail(`更新先Minecraft ${selected.version}にはJava ${required}以上が必要です。現在のJavaは ${currentJava} です。メインインストーラーでJavaを導入してから再実行してください。`);
  const plugins = inspectPlugins(selected.version, javaExecutable);
  console.log('\nプラグイン互換性の注意:');
  if (!plugins.length) console.log('  （pluginsフォルダにプラグインJARはありません）');
  plugins.forEach(plugin => console.log(`  ${plugin.level === 'warning' ? '!' : '△'} ${plugin.name || plugin.file}${plugin.version ? ` ${plugin.version}` : ''} — ${plugin.reason}`));
  if (plugins.some(plugin => plugin.level === 'warning')) {
    const proceed = await choose('注意があるプラグインを確認しました。更新を続けますか？', [['1', '更新する'], ['2', '中止する']], '2');
    if (proceed !== '1') { notice('更新を中止しました。'); return; }
  }
  const backup = backupRuntime(state);
  ok(`更新前ファイルを退避: ${backup}`);
  await downloadBuild(selected, path.join(serverDir, 'paper.jar'));
  const managedScript = path.join(updaterDirectory, 'Managed-Plugin-Updater.js');
  if (exists(managedScript)) {
    const managed = spawnSync(process.execPath, [managedScript, '--server-dir', serverDir, '--paper-version', selected.version], { cwd: serverDir, encoding: 'utf8', windowsHide: true });
    if (managed.stdout) process.stdout.write(managed.stdout);
    if (managed.status !== 0) warn(`管理対象Pluginの互換性確認に失敗しました。既存JARを保持しています。${managed.stderr ? ` ${managed.stderr.trim()}` : ''}`);
  }
  const blueMapStateFile = path.join(updaterDirectory, 'bluemap.json');
  const blueMapState = readJson(blueMapStateFile, {});
  const blueMapInstaller = path.join(updaterDirectory, 'BlueMap-Installer.js');
  // BlueMap fixes can be released for the same Paper version. Always check the
  // managed plugin; its installer keeps an identical verified JAR untouched.
  if (blueMapState.managed && exists(blueMapInstaller)) {
    const blueMap = spawnSync(process.execPath, [blueMapInstaller, '--server-dir', serverDir, '--paper-version', selected.version, '--java-major', String(currentJava)], { cwd: serverDir, encoding: 'utf8', windowsHide: true });
    if (blueMap.stdout) process.stdout.write(blueMap.stdout);
    if (blueMap.status !== 0) warn(`BlueMapは更新先Paperとの互換性を自動確認できませんでした。既存JARを保持しています。${blueMap.stderr ? ` ${blueMap.stderr.trim()}` : ''}`);
  }
  const launchers = launcherText('paper.jar', state.minMemory || '1G', state.maxMemory || '4G', port, javaExecutable, exists(managedScript) ? { script: managedScript, node: process.execPath } : null);
  const nativeKind = process.platform === 'win32' ? 'bat' : 'command';
  const nativeFile = path.join(serverDir, nativeKind === 'bat' ? 'start.bat' : 'start.command');
  const oppositeFile = path.join(serverDir, nativeKind === 'bat' ? 'start.command' : 'start.bat');
  fs.writeFileSync(nativeFile, nativeKind === 'bat' ? launchers.bat : launchers.command, { encoding: 'utf8', mode: nativeKind === 'command' ? 0o755 : 0o600 });
  try { fs.chmodSync(nativeFile, nativeKind === 'command' ? 0o755 : 0o600); } catch (_) {}
  // Remove only the alternate launcher previously generated by GriefGuard.
  // A user-authored cross-platform file is left untouched.
  try {
    if (exists(oppositeFile) && fs.readFileSync(oppositeFile, 'utf8').includes('GriefGuard managed Paper launcher')) fs.rmSync(oppositeFile, { force: true });
  } catch (_) {}
  writeJson(path.join(serverDir, 'paper.jar.griefguard-paper.json'), { ...selected, updatedAt: new Date().toISOString(), backup });
  writeJson(stateFile, { ...state, serverPort: port, javaExecutable, updatedAt: new Date().toISOString(), lastPaper: selected, lastBackup: backup });
  ok(`PaperをMinecraft ${selected.version} / build ${selected.build}へ更新しました。`);
  console.log(`${path.basename(nativeFile)} を更新しました。次回は通常の起動ファイルからPaperを起動してください。`);
}

if (require.main === module) {
  main().catch(error => { console.error(`\n[ERROR] ${error.message}`); process.exitCode = 1; });
} else {
  module.exports = { requiredJava, compareVersions, launcherText, parseDescriptor };
}
