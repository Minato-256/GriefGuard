#!/usr/bin/env node
'use strict';

/*
 * Updates only Geyser/Floodgate/ViaVersion JARs that the GriefGuard installer owns.
 * It is copied into <Paper>/.griefguard and runs before Paper is launched.
 * Startup mode is deliberately fail-open: an unavailable update service must
 * never prevent an existing Minecraft server from starting.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const argv = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  if (process.argv[index]?.startsWith('--')) argv.set(process.argv[index].slice(2), process.argv[index + 1] || '');
}
const serverDir = path.resolve(argv.get('server-dir') || process.cwd());
const managedDirectory = path.join(serverDir, '.griefguard');
const stateFile = path.join(managedDirectory, 'managed-plugins.json');
const startupMode = argv.has('startup');
const targetPaperVersion = String(argv.get('paper-version') || '').trim();
const quiet = argv.has('quiet');
const USER_AGENT = 'GriefGuard-Managed-Plugin-Updater/1.0';
const projects = [
  { id: 'geyser', download: 'spigot', file: 'Geyser-Spigot.jar', source: 'geyser' },
  { id: 'floodgate', download: 'spigot', file: 'floodgate-spigot.jar', source: 'geyser' },
  // Geyser currently emulates a newer Java client. ViaVersion is required
  // when a managed Paper server is behind that protocol version. Keeping it
  // in the managed compatibility set is safe on current Paper versions too.
  { id: 'viaversion', file: 'ViaVersion.jar', source: 'modrinth-release' }
];

function exists(file) { return fs.existsSync(file); }
function log(level, message) { if (!quiet || level !== 'INFO') console.log(`[${level}] ${message}`); }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; } }
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const temporary = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temporary, file);
  try { fs.chmodSync(file, 0o600); } catch (_) {}
}
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function validateJar(data, name) {
  if (!Buffer.isBuffer(data) || data.length < 4 || data.subarray(0, 2).toString('ascii') !== 'PK') throw new Error(`${name}のダウンロード結果がJAR形式ではありません。`);
}
function endpoint(project) {
  return `https://download.geysermc.org/v2/projects/${project.id}/versions/latest/builds/latest/downloads/${project.download}`;
}
async function viaVersionRelease() {
  const response = await fetch('https://api.modrinth.com/v2/project/viaversion/version?loaders=["paper"]', {
    headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' }, signal: AbortSignal.timeout(30000)
  });
  if (!response.ok) throw new Error(`ViaVersionの公式配布情報を取得できませんでした: HTTP ${response.status}`);
  const versions = await response.json();
  const release = Array.isArray(versions) && versions.find(version => version.version_type === 'release' && Array.isArray(version.files) && version.files.some(file => file.primary || /\.jar$/i.test(file.filename || '')));
  const file = release?.files?.find(item => item.primary) || release?.files?.find(item => /\.jar$/i.test(item.filename || ''));
  if (!file?.url) throw new Error('Paper用の安定版ViaVersion JARが見つかりません。');
  return { url: file.url, version: release.version_number || release.name || '', sha512: file.hashes?.sha512 || '' };
}
async function downloadProject(project, previous = {}) {
  const headers = { 'User-Agent': USER_AGENT, Accept: 'application/java-archive, application/octet-stream' };
  const release = project.source === 'modrinth-release' ? await viaVersionRelease() : null;
  const url = release?.url || endpoint(project);
  // Modrinth release URLs are immutable version assets. Do not reuse a stale
  // ETag from a previous release URL.
  if (previous.etag && previous.url === url) headers['If-None-Match'] = previous.etag;
  const response = await fetch(url, { headers, redirect: 'follow', signal: AbortSignal.timeout(30000) });
  if (response.status === 304) return { unchanged: true, etag: previous.etag || '', url: endpoint(project) };
  if (!response.ok) throw new Error(`${project.id}の公式ダウンロードに失敗しました: HTTP ${response.status}`);
  const data = Buffer.from(await response.arrayBuffer());
  validateJar(data, project.file);
  const digest = sha256(data);
  return {
    unchanged: false,
    data,
    sha256: digest,
    etag: response.headers.get('etag') || '',
    url: response.url || url,
    version: release?.version || '',
    downloadedAt: new Date().toISOString()
  };
}
function backupExisting(file, stamp) {
  if (!exists(file)) return '';
  const directory = path.join(managedDirectory, 'managed-plugin-backups', stamp);
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const destination = path.join(directory, path.basename(file));
  fs.copyFileSync(file, destination);
  return destination;
}
function replaceAtomically(file, data) {
  const temporary = `${file}.download-${process.pid}`;
  fs.writeFileSync(temporary, data, { mode: 0o600 });
  fs.renameSync(temporary, file);
}
async function updateManagedPlugins(options = {}) {
  const state = readJson(stateFile, { version: 1, enabled: false, plugins: {} });
  if (!state.enabled) return { skipped: true, reason: 'disabled' };
  // Regular Paper starts must not update plugins.  On Update-Paper, a managed
  // plugin is reconsidered only when the target Paper version changed.
  if (!options.install && (!targetPaperVersion || state.lastCheckedPaperVersion === targetPaperVersion)) {
    return { skipped: true, reason: targetPaperVersion ? 'already-compatible-check' : 'paper-update-only' };
  }
  const pluginsDirectory = path.join(serverDir, 'plugins');
  fs.mkdirSync(pluginsDirectory, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const next = { ...state, version: 1, plugins: { ...(state.plugins || {}) }, lastCheckedPaperVersion: targetPaperVersion || state.lastCheckedPaperVersion || '', updatedAt: new Date().toISOString() };
  const results = [];
  for (const project of projects) {
    const previous = next.plugins[project.id] || {};
    const target = path.join(pluginsDirectory, project.file);
    try {
      // Do not accept a 304 response when a user has removed the managed JAR.
      // In that case the full official archive must be downloaded again.
      const downloaded = await downloadProject(project, exists(target) ? previous : {});
      if (downloaded.unchanged) {
        results.push({ project: project.id, status: 'unchanged' });
        continue;
      }
      const currentHash = exists(target) ? sha256(fs.readFileSync(target)) : '';
      if (currentHash === downloaded.sha256) {
        next.plugins[project.id] = { ...previous, ...downloaded, file: project.file, managed: true, installedAt: previous.installedAt || new Date().toISOString() };
        delete next.plugins[project.id].data;
        results.push({ project: project.id, status: 'already-current' });
        continue;
      }
      const backup = backupExisting(target, stamp);
      replaceAtomically(target, downloaded.data);
      next.plugins[project.id] = { file: project.file, managed: true, sha256: downloaded.sha256, etag: downloaded.etag, url: downloaded.url, installedAt: new Date().toISOString(), backup: backup || null };
      results.push({ project: project.id, status: backup ? 'updated' : 'installed', backup: backup || null });
    } catch (error) {
      results.push({ project: project.id, status: 'failed', error: error.message });
      if (options.strict) throw error;
      log('WARN', `${project.id}は更新できませんでした。既存JARのままPaperを起動します: ${error.message}`);
    }
  }
  writeJson(stateFile, next);
  return { skipped: false, results };
}

async function main() {
  const strict = argv.has('install');
  const result = await updateManagedPlugins({ strict, install: strict });
  if (result.skipped) { log('INFO', 'Geyser/Floodgate/ViaVersionの自動管理は無効です。'); return; }
  for (const item of result.results) {
    const suffix = item.error ? `: ${item.error}` : item.backup ? `（旧版退避: ${item.backup}）` : '';
    log(item.status === 'failed' ? 'WARN' : 'OK', `${item.project}: ${item.status}${suffix}`);
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error(`[ERROR] ${error.message}`);
    process.exitCode = 1;
  });
} else {
  module.exports = { endpoint, validateJar, updateManagedPlugins, projects };
}
