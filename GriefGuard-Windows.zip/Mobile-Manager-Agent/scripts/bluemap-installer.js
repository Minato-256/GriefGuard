#!/usr/bin/env node
'use strict';

/* Installs only a stable, Java-compatible BlueMap Paper JAR.  BlueMap changes
 * its Java/Paper support independently from Paper, so the installer stores the
 * selected release instead of silently using a "latest" file on every start. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const args = new Map();
for (let i = 2; i < process.argv.length; i += 2) if (process.argv[i]?.startsWith('--')) args.set(process.argv[i].slice(2), process.argv[i + 1] || '');
const serverDir = path.resolve(args.get('server-dir') || process.cwd());
const javaMajor = Number(args.get('java-major') || 0);
const paperVersion = String(args.get('paper-version') || '');
const stateFile = path.join(serverDir, '.griefguard', 'bluemap.json');

function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function writeState(state) { fs.mkdirSync(path.dirname(stateFile), { recursive: true, mode: 0o700 }); fs.writeFileSync(stateFile, JSON.stringify(state, null, 2) + '\n', { mode: 0o600 }); }
function releaseJava(release) { const match = String(release.body || '').match(/Java:\s*(\d+)/i); return match ? Number(match[1]) : 17; }
function supportsPaper(release, version) {
  if (!version) return true;
  const body = String(release.body || '');
  // Release notes contain the supported Paper range. Unknown metadata is not
  // treated as compatibility; this prevents a blind unsafe replacement.
  if (new RegExp(`Paper[^\\n]*${version.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i').test(body)) return true;
  // BlueMap publishes ranges rather than every patch version. Treat a release
  // that explicitly targets Paper for the same Minecraft minor as a candidate;
  // Paper validates it at the first startup and leaves the old JAR recoverable.
  return /^1\.21\./.test(version) && /Paper(?:\/Folia)?\s+1\.21/i.test(body);
}
async function releases() {
  const response = await fetch('https://api.github.com/repos/BlueMap-Minecraft/BlueMap/releases?per_page=50', { headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'GriefGuard-BlueMap-Installer/1.0' }, signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new Error(`BlueMap公式配布情報を取得できませんでした: HTTP ${response.status}`);
  return response.json();
}
async function install() {
  if (!Number.isInteger(javaMajor) || javaMajor < 17) throw new Error('BlueMap導入には使用中Javaのバージョン情報が必要です。');
  const candidates = (await releases()).filter(release => !release.draft && !release.prerelease)
    .map(release => ({ release, asset: (release.assets || []).find(asset => /-paper\.jar$/i.test(asset.name || '')) }))
    .filter(item => item.asset && releaseJava(item.release) <= javaMajor && supportsPaper(item.release, paperVersion));
  const selected = candidates[0];
  if (!selected) throw new Error(`Java ${javaMajor} とPaper ${paperVersion || '現在の版'} の両方に対応すると公式情報で確認できるBlueMap安定版が見つかりません。PaperまたはJavaを更新してから再試行してください。`);
  const response = await fetch(selected.asset.browser_download_url, { headers: { 'User-Agent': 'GriefGuard-BlueMap-Installer/1.0' }, signal: AbortSignal.timeout(60000) });
  if (!response.ok) throw new Error(`BlueMap JARのダウンロードに失敗しました: HTTP ${response.status}`);
  const data = Buffer.from(await response.arrayBuffer());
  if (data.subarray(0, 2).toString('ascii') !== 'PK') throw new Error('BlueMapのダウンロード結果がJAR形式ではありません。');
  const pluginDir = path.join(serverDir, 'plugins');
  fs.mkdirSync(pluginDir, { recursive: true });
  const target = path.join(pluginDir, 'BlueMap.jar');
  const previous = (() => { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (_) { return {}; } })();
  const nextHash = sha256(data);
  const previousHash = fs.existsSync(target) ? sha256(fs.readFileSync(target)) : '';
  const release = selected.release.tag_name || selected.release.name;
  const changed = previousHash !== nextHash;
  if (changed && fs.existsSync(target)) fs.copyFileSync(target, `${target}.before-griefguard-${Date.now()}.bak`);
  if (changed) {
    const temporary = `${target}.download-${process.pid}`;
    fs.writeFileSync(temporary, data, { mode: 0o600 });
    fs.renameSync(temporary, target);
  }
  // Do not erase rendered map data. A later offline repair will only move the
  // web entry point aside so BlueMap can regenerate a compatible WebApp.
  const state = {
    ...previous,
    version: 2, managed: true, source: 'BlueMap official GitHub release', release,
    paperVersion, javaMajor, file: 'BlueMap.jar', sha256: nextHash, host: '127.0.0.1', port: 8100,
    installedAt: previous.installedAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
    acceptDownloadRequired: true, updated: changed,
    webAppRefreshRequired: changed ? Boolean(previousHash || previous.release) : previous.webAppRefreshRequired === true,
    webAppRefreshReason: changed && Boolean(previousHash || previous.release)
      ? 'BlueMap JAR was updated; regenerate only the WebApp entry point before next start.'
      : (previous.webAppRefreshReason || null)
  };
  writeState(state);
  return state;
}

if (require.main === module) install().then(state => console.log(`[OK] BlueMap ${state.release} を${state.updated ? '更新' : '確認'}しました。Paper初回起動後にplugins/BlueMap/core.confでaccept-downloadを確認してください。`)).catch(error => { console.error(`[ERROR] ${error.message}`); process.exitCode = 1; });
module.exports = { install, releaseJava, supportsPaper };
