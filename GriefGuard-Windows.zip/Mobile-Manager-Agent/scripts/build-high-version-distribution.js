#!/usr/bin/env node
/* Build a separate HighVersion deliverable without changing Standard release files. */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const agentRoot = path.resolve(__dirname, '..');
const workspaceRoot = path.resolve(agentRoot, '..', '..');
const standard = path.join(workspaceRoot, 'GriefGuard_Distribution');
const high = path.join(workspaceRoot, 'GriefGuard_HighVersion_Distribution');
const highJar = path.join(workspaceRoot, 'GriefGuard_setting', 'GriefGuard', 'target', 'GriefGuard-HighVersion-1.0.jar');

function required(file) {
  if (!fs.existsSync(file)) throw new Error(`必要なファイルが見つかりません: ${file}`);
}

try {
  required(standard);
  required(highJar);
  fs.rmSync(high, { recursive: true, force: true });
  fs.cpSync(standard, high, { recursive: true, force: true });
  fs.copyFileSync(highJar, path.join(high, 'GriefGuard.jar'));
  // The macOS package contains its own plugin copy under Applications. Rebuild
  // it with the HighVersion JAR so every supported entry point installs the
  // same edition, rather than silently falling back to Standard.
  if (process.platform === 'darwin') {
    const pkgScript = path.join(agentRoot, 'installer', 'macos', 'build-pkg.sh');
    const pkgOutput = path.join(high, 'Installers', 'macOS', 'GriefGuard-Installer.pkg');
    const packageResult = spawnSync('/bin/sh', [pkgScript], {
      env: {
        ...process.env,
        GRIEFGUARD_PLUGIN_JAR: highJar,
        GRIEFGUARD_PKG_OUTPUT: pkgOutput,
        // `node` may have been launched through nvm and not be present in
        // non-interactive shell PATH. The package must embed the same runtime.
        GRIEFGUARD_NODE_RUNTIME: process.execPath
      },
      stdio: 'inherit'
    });
    if (packageResult.status !== 0) throw new Error('HighVersion macOS PKGの作成に失敗しました。');
  }
  fs.writeFileSync(path.join(high, 'README_FIRST.txt'), `GriefGuard HighVersion Preview: 最初にお読みください\n\nこのフォルダーはStandard版とは別のHighVersion配布物です。Standard版と同じPaperへ同時導入しません。\n\n1. ZIPを必ず展開してから使います。\n2. Paperを stop で完全停止します。session.lockを削除しません。\n3. Windowsは Installers\\Windows\\Start-GriefGuard-Setup.bat、macOSは Installers/macOS/GriefGuard-Installer.pkg の後に GriefGuard-Setup.command を開きます。\n4. 既存Paperを選ぶ場合は、paper.jar、server.properties、plugins、worldが直接入る最上位フォルダーを選択します。\n\nHighVersionで追加されるもの:\n- 接続履歴（マスク表示）\n- 同一接続元の関連アカウント候補\n- 接続保護の詳細表示\n\n重要:\n- 外部GeoIP照会、直接Discord Bot、調査レポート、Fake Crash、永久IP BAN自動化は含みません。\n- 関連アカウント候補は処罰の自動根拠ではありません。\n- 初回のHighVersion接続後、管理画面の上部に HIGH VERSION と表示され、プレイヤー一覧に「接続保護」ボタンが現れます。\n\n設計書: Mobile-Manager-Agent/docs/HIGH_VERSION_EDITION_DESIGN_2026-07-26.md\n`);
  const zip = process.platform === 'win32' ? null : 'zip';
  if (zip) {
    const archive = path.join(workspaceRoot, 'GriefGuard-HighVersion.zip');
    fs.rmSync(archive, { force: true });
    const result = spawnSync(zip, ['-X', '-q', '-r', archive, '.'], { cwd: high, stdio: 'inherit' });
    if (result.status !== 0) throw new Error('HighVersion ZIPの作成に失敗しました。');
  }
  console.log(`HighVersion distribution assembled: ${high}`);
} catch (error) {
  console.error(`[ERROR] ${error.message}`);
  process.exitCode = 1;
}
