#!/usr/bin/env node
/* Assemble only installer deliverables into the user-facing distribution tree. */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const agentRoot = path.resolve(__dirname, '..');
const workspaceRoot = path.resolve(agentRoot, '..', '..');
const distribution = path.join(workspaceRoot, 'GriefGuard_Distribution');
const windows = path.join(distribution, 'Installers', 'Windows');
const macos = path.join(distribution, 'Installers', 'macOS');
const macPkg = path.join(agentRoot, 'dist', 'installers', 'macos', 'GriefGuard-Installer-unsigned.pkg');
// The mobile Agent and canonical Plugin source live under GriefGuard_setting.
// Never package the legacy sibling project, which has different Bridge rules.
const builtPluginJar = path.join(workspaceRoot, 'GriefGuard_setting', 'GriefGuard', 'target', 'GriefGuard-1.0.jar');
const manualPdf = path.join(workspaceRoot, 'output', 'pdf', 'GriefGuard_導入・機能説明書.pdf');
const setupWizardSource = path.join(agentRoot, 'scripts', 'setup-wizard.js');
const macSetupSource = path.join(agentRoot, 'installer', 'macos', '2_インストール後のセットアップ.command');

function installerRelease() {
  const source = fs.readFileSync(setupWizardSource, 'utf8');
  const match = source.match(/const INSTALLER_RELEASE = '([^']+)'/);
  if (!match) throw new Error('setup-wizard.jsからインストーラーのリリース番号を取得できません。');
  return match[1];
}

function assertReleaseConsistency(release) {
  const publicSetup = fs.readFileSync(macSetupSource, 'utf8');
  const buildPackage = fs.readFileSync(path.join(agentRoot, 'installer', 'macos', 'build-pkg.sh'), 'utf8');
  if (!publicSetup.includes(`EXPECTED_RELEASE="${release}"`)) throw new Error(`macOSセットアップコマンドの期待リリースが不一致です。必要: ${release}`);
  if (!buildPackage.includes(`INSTALLER_RELEASE="${release}"`)) throw new Error(`macOS PKGのリリース番号が不一致です。必要: ${release}`);
}

function copy(source, destination) {
  if (!fs.existsSync(source)) throw new Error(`必要なファイルが見つかりません: ${source}`);
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.cpSync(source, destination, { recursive: fs.statSync(source).isDirectory(), force: true });
  console.log(`[COPY] ${destination}`);
}

function normalizeWindowsBatch(file) {
  // cmd.exe launchers are distributed as ASCII with one, consistent CRLF line
  // ending. This prevents partial command parsing after ZIP extraction or a
  // cross-platform edit of the source launcher.
  const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').replace(/\r\n|\n|\r/g, '\r\n');
  fs.writeFileSync(file, text, { encoding: 'ascii', mode: 0o644 });
}

function removeMacMetadata(root) {
  if (!fs.existsSync(root)) return;
  for (const name of fs.readdirSync(root)) {
    const entry = path.join(root, name);
    if (name === '.DS_Store' || name === '__MACOSX') {
      fs.rmSync(entry, { recursive: true, force: true });
    } else if (fs.statSync(entry).isDirectory()) {
      removeMacMetadata(entry);
    }
  }
}

try {
  if (!fs.existsSync(distribution)) throw new Error(`配布フォルダが見つかりません: ${distribution}`);
  const release = installerRelease();
  assertReleaseConsistency(release);
  // Remove only old generated entry points whose names invited users to run a
  // post-install command before the macOS package had installed its runtime.
  for (const oldFile of [
    path.join(macos, 'GriefGuard Setup.command'),
    path.join(macos, 'GriefGuard-Installer-unsigned.pkg'),
    path.join(macos, 'build-pkg.sh'),
    path.join(macos, '1_GriefGuardをインストール.pkg'),
    path.join(macos, '2_インストール後のセットアップ.command'),
    path.join(windows, '1_GriefGuardセットアップ.ps1'),
    path.join(windows, 'GriefGuard-Setup.iss'),
    path.join(windows, 'Start-GriefGuard-Setup.bat')
  ]) fs.rmSync(oldFile, { force: true });
  // Keep the distributable plugin synchronized with the verified Maven build.
  // This deliberately replaces only the generated release JAR, never a user's
  // server-side plugins/GriefGuard.jar or configuration.
  copy(builtPluginJar, path.join(distribution, 'GriefGuard.jar'));
  copy(manualPdf, path.join(distribution, 'GriefGuard_Manual_JA.pdf'));
  copy(path.join(agentRoot, 'installer', 'windows', 'GriefGuard-Setup.ps1'), path.join(windows, 'GriefGuard-Setup.ps1'));
  copy(path.join(agentRoot, 'installer', 'windows', 'Start-GriefGuard-Setup.bat'), path.join(windows, 'Start-GriefGuard-Setup.bat'));
  // Both OS launchers read the same signed-by-hash runtime manifest. The
  // manifest is tiny; Node.js itself is intentionally not bundled.
  copy(path.join(agentRoot, 'installer', 'runtime-manifest.json'), path.join(distribution, 'Installers', 'runtime-manifest.json'));
  normalizeWindowsBatch(path.join(windows, 'Start-GriefGuard-Setup.bat'));
  copy(path.join(agentRoot, 'installer', 'macos', '2_インストール後のセットアップ.command'), path.join(macos, 'GriefGuard-Setup.command'));
  fs.chmodSync(path.join(macos, 'GriefGuard-Setup.command'), 0o755);
  copy(macPkg, path.join(macos, 'GriefGuard-Installer.pkg'));
  // Synchronize executable Agent code, but deliberately do not copy the
  // developer's agent-config.json, sessions, reset files, or any other local
  // credential-bearing state into a distributable archive.
  const distributedAgent = path.join(distribution, 'Mobile-Manager-Agent');
  copy(path.join(agentRoot, 'server.js'), path.join(distributedAgent, 'server.js'));
  copy(path.join(agentRoot, 'commands.json'), path.join(distributedAgent, 'commands.json'));
  copy(path.join(agentRoot, 'lib'), path.join(distributedAgent, 'lib'));
  copy(path.join(agentRoot, 'public'), path.join(distributedAgent, 'public'));
  copy(path.join(agentRoot, 'scripts'), path.join(distributedAgent, 'scripts'));
  copy(path.join(agentRoot, 'docs'), path.join(distributedAgent, 'docs'));
  copy(path.join(agentRoot, 'README.md'), path.join(distributedAgent, 'README.md'));
  copy(path.join(agentRoot, 'package.json'), path.join(distributedAgent, 'package.json'));
  copy(path.join(agentRoot, 'package-lock.json'), path.join(distributedAgent, 'package-lock.json'));
  // The Windows preview launcher uses the normal Agent directory. Bundle JS
  // dependencies there so it does not need npm install after Node.js is present.
  copy(path.join(agentRoot, 'node_modules'), path.join(distributedAgent, 'node_modules'));
  removeMacMetadata(distribution);
  for (const oldRootFile of ['はじめにお読みください.txt', 'GriefGuard_導入・機能説明書.pdf']) fs.rmSync(path.join(distribution, oldRootFile), { force: true });
  fs.writeFileSync(path.join(distribution, 'README_FIRST.txt'), `GriefGuard 配布物: 最初にお読みください\n\n版: ${release}\n\n1. ZIPは必ず「すべて展開」してから操作します。ZIPを開いたまま実行しません。\n2. すでにPaperが起動中なら、Paperコンソールで stop を実行して完全に停止します。session.lockは削除しません。\n3. 使用するOSの開始ファイルだけを開きます。\n\nWindows:\n  Installers\\Windows\\Start-GriefGuard-Setup.bat\n  このBATファイルをダブルクリックします。PS1を右クリックして直接実行する必要はありません。\n\nmacOS:\n  Installers/macOS/GriefGuard-Installer.pkg\n  PKGが完了してから、Installers/macOS/GriefGuard-Setup.command を開きます。\n\n実行環境について:\n  Node.jsとJavaはPCに互換版があれば再利用します。無い場合だけ公式配布元から取得し、SHA-256確認後にOSのGriefGuard共有キャッシュへ保存します。次回のStandard版・HighVersion版・別サーバーでは再ダウンロードしません。\n\n既存Paperは、ファイル選択画面で paper.jar、server.properties、plugins、world が直接入る最上位フォルダーを選びます。cmdやターミナルにcdを入力しません。\n\n重要: Setupは初回導入・修復用です。日常操作では管理ワークスペースの Agent-Manual-Controls.txt を開き、Open-GriefGuard-App、Start-GriefGuard-Agent、Stop-GriefGuard-Agent を使います。\n\n詳しい手順: GriefGuard_Manual_JA.pdf（第3〜5章: 導入とTailscale、第6〜10章: アプリ、第11〜14章: 更新・復旧）\n`);
  fs.writeFileSync(path.join(distribution, 'Installers', 'README.md'), `# GriefGuard インストーラー\n\nWindowsの配布ファイル名は、ZIP展開時の文字化けを防ぐため英数字を使用しています。詳細は配布物直下の\`GriefGuard_Manual_JA.pdf\`を先に開いてください。\n\n## Windows\n\n1. ZIPをエクスプローラーの「すべて展開」で展開します。\n2. \`Installers/Windows/Start-GriefGuard-Setup.bat\`をダブルクリックします。\`GriefGuard-Setup.ps1\`は直接実行しません。\n3. Node.jsがなければ、セットアップが自動取得して続行します。手動のnpm installや再ログインは不要です。\n\n## macOS\n\n1. \`macOS/GriefGuard-Installer.pkg\`を実行します。\n2. 完了後に\`macOS/GriefGuard-Setup.command\`を開きます。\n\n## 入力する内容\n\n- 既存Paper: Finder/エクスプローラーで、\`paper.jar\`、\`server.properties\`、\`plugins\`、\`world\`が直接入る最上位フォルダーを選びます。パスや\`cd\`は入力しません。\n- 新規Paper: MinecraftServerを作る親フォルダーを選びます。配布フォルダーやInstallersの中には作成しません。\n- メモリー: 初回はインストーラーの推奨値を使います。OSとAgentのため2GB以上を空けます。\n- 接続方式: Java版は25565/TCP。統合版も参加させる時だけJava＋統合版を選び、GeyserMC/Floodgateと19132/UDPを設定します。\n\n## 生成後の操作\n\n管理ワークスペース\`GriefGuard-HomeServer\`はPaperと同じ親に作成されます。\`Agent-Manual-Controls.txt\`を開くと、Agent起動・停止、アプリを開く、初回コード再表示、Tailscale再開、BlueMap修復の用途が分かります。AgentDataは認証情報なので削除・共有しません。\n`);
  fs.appendFileSync(path.join(distribution, 'README_FIRST.txt'), `\nTailscaleを後回しにした場合:\n- GriefGuard-HomeServer内の Continue-Tailscale-Setup.bat または Continue-Tailscale-Setup.command を実行します。最初からセットアップをやり直す必要はありません。\n- HTTPS URLはPaper親フォルダーの GriefGuard-Access.txt に保存されます。\n`);
  fs.appendFileSync(path.join(distribution, 'Installers', 'README.md'), `\n## Node.js / Java の扱い\n\nNode.jsとJavaは配布ZIPへ大容量で同梱しません。まずOSにある互換版を再利用し、無い時だけ公式配布元から取得してSHA-256確認後に保存します。\n\n- WindowsのNode.js: \`%LOCALAPPDATA%\\GriefGuard\\runtimes\\node\`\n- macOSのNode.js: \`~/Library/Application Support/GriefGuard/runtimes/node\`\n- Java: 同じ\`runtimes/java\`配下（Paper世代ごとの必要Javaを共有）\n\nこれらはStandard版／HighVersion版／複数サーバーで再利用されます。削除すると次回セットアップ時に再取得されます。\n\n> 最新版では既存Paperを自動検索します。候補にない時も、フォルダのパスを入力せず、paper.jar、server.properties、start.bat、start.commandのどれか一つを選んでください。新しいPaperはDocuments/GriefGuardServers/MinecraftServerへ自動作成されます。\n`);
  fs.appendFileSync(path.join(distribution, 'README_FIRST.txt'), `\nPaperを更新する場合:\n- Paperサーバーをstopで完全に停止します。\n- Paperサーバー直下の Update-Paper.bat（Windows）または Update-Paper.command（macOS）を実行します。\n- 公式安定版だけが表示されます。更新前のpaper.jarと起動ファイルは .griefguard/update-backups に保存されます。\n`);
  fs.appendFileSync(path.join(distribution, 'Installers', 'README.md'), `\n## TailscaleとPaper更新\n\nTailscaleを後回しにした場合は、管理ワークスペース内の\`Continue-Tailscale-Setup.bat\`または\`Continue-Tailscale-Setup.command\`を実行します。最初からセットアップを実行し直す必要はありません。\n\nPaperを停止してから、Paperサーバー直下の\`Update-Paper.bat\`（Windows）または\`Update-Paper.command\`（macOS）を実行します。公式安定版のみが表示され、更新前のPaperと起動ファイルは\`.griefguard/update-backups\`へ退避されます。自動管理対象Pluginは必要な時だけ対応版へ更新し、手動導入Pluginは削除せず注意を表示します。\n`);
  const zip = process.platform === 'win32' ? null : 'zip';
  if (zip) {
    for (const archive of ['GriefGuard-Windows.zip', 'GriefGuard-macOS.zip']) fs.rmSync(path.join(workspaceRoot, archive), { force: true });
    const zipWindows = spawnSync(zip, ['-X', '-q', '-r', path.join(workspaceRoot, 'GriefGuard-Windows.zip'), 'GriefGuard.jar', 'README_FIRST.txt', 'GriefGuard_Manual_JA.pdf', 'Installers/Windows', 'Mobile-Manager-Agent'], { cwd: distribution, stdio: 'inherit' });
    if (zipWindows.status !== 0) throw new Error('Windows ZIPの作成に失敗しました。');
    const zipMac = spawnSync(zip, ['-X', '-q', '-r', path.join(workspaceRoot, 'GriefGuard-macOS.zip'), 'GriefGuard.jar', 'README_FIRST.txt', 'GriefGuard_Manual_JA.pdf', 'Installers/macOS', 'Mobile-Manager-Agent'], { cwd: distribution, stdio: 'inherit' });
    if (zipMac.status !== 0) throw new Error('macOS ZIPの作成に失敗しました。');
  }
  console.log('Installer distribution assembled.');
} catch (error) {
  console.error(`[ERROR] ${error.message}`);
  process.exitCode = 1;
}
