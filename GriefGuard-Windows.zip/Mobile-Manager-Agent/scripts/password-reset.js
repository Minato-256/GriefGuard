const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA_DIRECTORY = process.env.GRIEFGUARD_AGENT_DATA_DIR
    ? path.resolve(process.env.GRIEFGUARD_AGENT_DATA_DIR)
    : path.join(__dirname, '..');
fs.mkdirSync(DATA_DIRECTORY, { recursive: true, mode: 0o700 });
const RESET_FILE = path.join(DATA_DIRECTORY, '.password-reset.json');
const TTL_MS = 10 * 60 * 1000;
const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function generateCode() {
    let value = '';
    for (let index = 0; index < 8; index++) value += alphabet[crypto.randomInt(alphabet.length)];
    return `RS-${value.slice(0, 4)}-${value.slice(4)}`;
}

function sha256(value) {
    return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

const code = generateCode();
const challenge = {
    version: 1,
    hash: sha256(code),
    expiresAt: Date.now() + TTL_MS,
    attempts: 0
};
const temporaryFile = `${RESET_FILE}.${process.pid}.tmp`;

fs.writeFileSync(temporaryFile, JSON.stringify(challenge, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
try { fs.chmodSync(temporaryFile, 0o600); } catch (_) {}
try {
    fs.renameSync(temporaryFile, RESET_FILE);
} catch (error) {
    // Windows may not replace an existing destination with renameSync.
    if (!['EEXIST', 'EPERM'].includes(error.code)) throw error;
    try { fs.unlinkSync(RESET_FILE); } catch (unlinkError) {
        if (unlinkError.code !== 'ENOENT') throw unlinkError;
    }
    fs.renameSync(temporaryFile, RESET_FILE);
}
try { fs.chmodSync(RESET_FILE, 0o600); } catch (_) {}

console.log('==================================================');
console.log(' GriefGuard 管理パスワード・リセットコード');
console.log(` Code: ${code}`);
console.log(' 有効期限: 10分 / 1回限り / 最大5回まで');
console.log(' アプリの「パスワードを忘れた場合」から入力してください。');
console.log(' このコードはチャットや第三者へ公開しないでください。');
console.log('==================================================');
