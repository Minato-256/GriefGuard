#!/usr/bin/env node
/*
 * Shared installer core for Windows and macOS.
 * Existing worlds and launchers are preserved unless the user explicitly
 * chooses the recommended launcher migration.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');
const crypto = require('crypto');
const zlib = require('zlib');
const { spawn, spawnSync } = require('child_process');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { parseYamlField, writeYamlField } = require('../lib/yaml-scalar');
const { validateHighVersion } = require('../lib/griefguard-schema');
const { detailsFor: blueMapDetailsFor, mapCoverage, blankCoverage, mapGenerationHealth } = require('../lib/bluemap-diagnostics');

const agentRoot = path.resolve(__dirname, '..');
const argv = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  if (process.argv[i]?.startsWith('--')) argv.set(process.argv[i].slice(2), process.argv[i + 1] || '');
}
const nonInteractive = argv.has('server-dir') || argv.get('mode') === 'create';
const INSTALLER_RELEASE = '2026.07.28.1';
const USER_AGENT = 'GriefGuard-Installer/1.2.0 (local-distribution)';
const GIB = 1024 ** 3;
let activePaperBootstrap = null;

function step(index, title, state = 'RUN') { console.log(`\n[${state}] ${index}/16 ${title}`); }
function ok(text) { console.log(`[OK] ${text}`); }
function warn(text) { console.warn(`[WARN] ${text}`); }
function fail(text) { throw new Error(text); }
function exists(file) { return fs.existsSync(file); }
function timestamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }

// Paper launched for the first-run bootstrap must never be silently left
// running when the installer is interrupted. This only tracks the child
// process started by this installer, never an arbitrary Java process.
function stopActiveBootstrapOnSignal(signal) {
  if (!activePaperBootstrap?.child || activePaperBootstrap.child.exitCode !== null) return;
  warn(`インストーラーを中断しました。起動中のPaperへ${signal}の安全停止を送信します。`);
  requestPaperTermination(activePaperBootstrap.child);
}
process.once('SIGINT', () => stopActiveBootstrapOnSignal('SIGINT'));
process.once('SIGTERM', () => stopActiveBootstrapOnSignal('SIGTERM'));
function mergeSettings(base, update) {
  const result = { ...(base || {}) };
  for (const [key, value] of Object.entries(update || {})) {
    result[key] = value && typeof value === 'object' && !Array.isArray(value)
      ? mergeSettings(result[key], value)
      : value;
  }
  return result;
}
function readJsonObject(file) {
  try {
    const value = JSON.parse(fs.readFileSync(file, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch (_) { return null; }
}
function provisionAgentConfig(existing, details) {
  const initial = {
    version: 1,
    mode: 'plugin-only',
    displayName: path.basename(details.workspace),
    serverDirectory: details.serverDir,
    auth: { password: null, passwordHash: '', allowLocalNetwork: true, allowTailscale: true },
    access: { tailscaleDnsName: '', https: true },
    bridge: { host: '127.0.0.1', port: details.bridgePort || 25501 },
    local: {
      startScript: process.platform === 'win32' ? 'start.bat' : 'start.command',
      serverPort: details.connection.javaPort,
      javaPath: details.java.executable,
      javaSource: details.java.downloaded ? 'temurin-portable' : 'system',
      memory: { min: details.minMemory || '', max: details.maxMemory || '', source: 'GriefGuard Installer' }
    },
    connection: { editionMode: details.connection.mode, java: { port: details.connection.javaPort, protocol: 'tcp' }, bedrock: details.connection.bedrockPort ? { port: details.connection.bedrockPort, protocol: 'udp', geyserDetected: details.connection.geyserDetected, floodgateDetected: details.connection.floodgateDetected } : null },
    windows: { launcherHost: '127.0.0.1', launcherPort: 25500 },
    linux: { serviceName: 'minecraft' },
    panel: { type: 'pterodactyl', url: '', apiKey: '', serverId: '' }
  };
  if (!existing) return { config: initial, preserved: false };
  // Authentication and remote access settings belong to the administrator.
  // Preserve them while refreshing the selected Paper server details.
  const preserved = {
    auth: existing.auth,
    access: existing.access,
    displayName: typeof existing.displayName === 'string' && existing.displayName.trim() ? existing.displayName : initial.displayName,
    panel: existing.panel
  };
  return { config: mergeSettings(initial, preserved), preserved: true };
}
function formatGiB(bytes) { return `${(bytes / GIB).toFixed(1)}GB`; }
function parseMemory(value) {
  const match = String(value).trim().match(/^(\d+(?:\.\d+)?)\s*([mMgG])(?:i?[bB])?$/);
  if (!match) return 0;
  return Math.round(Number(match[1]) * (match[2].toLowerCase() === 'g' ? GIB : 1024 ** 2));
}
function reserveMemory(total) {
  const gib = total / GIB;
  if (gib <= 4) return 2 * GIB;
  if (gib <= 8) return 3 * GIB;
  if (gib <= 16) return 4 * GIB;
  if (gib <= 32) return 6 * GIB;
  return 8 * GIB;
}
function recommendedMemory(total) {
  const gib = total / GIB;
  if (gib <= 4) return { min: '1G', max: '2G' };
  if (gib <= 8) return { min: '1G', max: '4G' };
  if (gib <= 16) return { min: '2G', max: '8G' };
  if (gib <= 32) return { min: '2G', max: '16G' };
  return { min: '4G', max: '24G' };
}
function assessMemory(min, max, options = {}) {
  const total = os.totalmem();
  const available = os.freemem();
  const reserve = reserveMemory(total);
  const minBytes = parseMemory(min), maxBytes = parseMemory(max);
  if (!minBytes || !maxBytes) fail('メモリーは 1G または 1024M の形式で指定してください。');
  if (minBytes > maxBytes) fail('起動時メモリーは最大メモリー以下にしてください。');
  const stableLimit = Math.max(0, total - reserve);
  const immediateLimit = Math.max(0, available - GIB);
  // The durable allocation is based on installed RAM, but the installer must
  // not hide a temporary low-memory condition. A zero means "do not start a
  // new server until other applications have been closed", not "use the
  // stable limit".
  const recommendedLimit = Math.min(stableLimit, immediateLimit);
  const remaining = total - maxBytes;
  if ((maxBytes >= total || remaining < 2 * GIB) && !options.preserveExisting) fail(`最大メモリー ${max} は危険です。OSとAgent用に最低2GBを残してください。`);
  const level = maxBytes > stableLimit || maxBytes > total * 0.7 || remaining < 4 * GIB || maxBytes > immediateLimit ? 'warning' : 'safe';
  return { total, available, reserve, stableLimit, immediateLimit, recommendedLimit, remaining, level };
}
function readMemoryFromText(text) {
  const value = String(text || '');
  const variable = name => (value.match(new RegExp(`^\\s*(?:set\\s+)?["']?${name}["']?\\s*=\\s*["']?([0-9.]+(?:[mMgG])(?:i?[bB])?)`, 'mi')) || [])[1] || '';
  const flag = name => (value.match(new RegExp(`-${name}\\s*[= ]\\s*["']?([0-9.]+(?:[mMgG])(?:i?[bB])?)`, 'i')) || [])[1] || '';
  const min = variable('MIN_MEMORY') || flag('Xms');
  const max = variable('MAX_MEMORY') || flag('Xmx');
  return parseMemory(min) && parseMemory(max) ? { min, max } : null;
}
function detectExistingMemory(serverDir) {
  const candidates = [path.join(serverDir, 'start.bat'), path.join(serverDir, 'start.command')];
  for (const file of candidates) {
    if (!exists(file)) continue;
    const settings = readMemoryFromText(fs.readFileSync(file, 'utf8'));
    if (settings) return { ...settings, source: path.basename(file) };
  }
  const updater = readJsonObject(path.join(serverDir, '.griefguard', 'paper-updater.json'));
  if (updater && parseMemory(updater.minMemory) && parseMemory(updater.maxMemory)) return { min: updater.minMemory, max: updater.maxMemory, source: '.griefguard/paper-updater.json' };
  return null;
}
async function chooseMemorySettings(serverDir, paper, defaults) {
  const existing = !paper.newServer ? detectExistingMemory(serverDir) : null;
  const suppliedMin = argv.get('min-memory');
  const suppliedMax = argv.get('max-memory');
  if (suppliedMin || suppliedMax) return { min: suppliedMin || existing?.min || defaults.min, max: suppliedMax || existing?.max || defaults.max, preserved: Boolean(existing && !suppliedMin && !suppliedMax) };
  if (existing) {
    ok(`既存のメモリー設定を検出: -Xms ${existing.min} / -Xmx ${existing.max}（${existing.source}）`);
    if (nonInteractive || await choose('既存のメモリー設定を使いますか？', [['1', 'そのまま使用する（推奨）'], ['2', '変更する']], '1') === '1') return { ...existing, preserved: true };
  }
  return {
    min: await ask('起動時メモリー (-Xms)', existing?.min || defaults.min),
    max: await ask('最大メモリー (-Xmx)', existing?.max || defaults.max),
    preserved: false
  };
}
function playerGuide(max) {
  const gib = parseMemory(max) / GIB;
  if (gib <= 2) return '軽量構成で1〜5人が目安';
  if (gib <= 4) return '軽量構成で5〜15人が目安';
  if (gib <= 6) return '軽量構成で10〜25人が目安';
  if (gib <= 8) return '軽量構成で20〜40人が目安';
  if (gib <= 12) return '軽量構成で30〜60人が目安';
  return '50人以上も可能ですが、CPU・回線・Plugin・描画距離の影響が大きい';
}
function findPaperJar(serverDir) {
  if (!exists(serverDir)) return '';
  let entries = [];
  try { entries = fs.readdirSync(serverDir); } catch (_) { return ''; }
  const jars = entries.filter(name => /\.jar$/i.test(name) && !/griefguard/i.test(name));
  return jars.find(name => /^paper[-.]/i.test(name)) || jars.find(name => /paper/i.test(name)) || jars[0] || '';
}
function isInside(child, parent) {
  const relative = path.relative(path.resolve(parent), path.resolve(child));
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}
function isPaperServerDirectory(directory) {
  if (!exists(directory)) return false;
  try {
    if (!fs.statSync(directory).isDirectory() || !findPaperJar(directory)) return false;
    return exists(path.join(directory, 'server.properties')) || exists(path.join(directory, 'plugins')) || exists(path.join(directory, 'world')) || exists(path.join(directory, 'start.bat')) || exists(path.join(directory, 'start.command'));
  } catch (_) { return false; }
}
function defaultServerParent() {
  return path.join(os.homedir(), 'Documents', 'GriefGuardServers');
}
function nextAvailableServerDirectory(parent, preferredName = 'MinecraftServer') {
  const base = path.join(parent, preferredName);
  if (!exists(base)) return base;
  for (let index = 2; index <= 100; index += 1) {
    const candidate = path.join(parent, `${preferredName}-${index}`);
    if (!exists(candidate)) return candidate;
  }
  fail(`新規サーバー用の空きフォルダを作れませんでした: ${parent}`);
}
function normalizeSearchRoots(candidates) {
  return [...new Set(candidates
    .filter(candidate => typeof candidate === 'string' && candidate.trim())
    // Do not pass path.resolve directly to Array#map. map supplies value,
    // index, and the complete array; Node.js 24 correctly rejects the array
    // as a third path argument.
    .map(candidate => path.resolve(candidate))
    .filter(exists))];
}
function searchExistingPaperServers() {
  const distributionRoot = path.resolve(agentRoot, '..');
  const roots = normalizeSearchRoots([
    process.cwd(), distributionRoot, path.dirname(distributionRoot),
    path.join(os.homedir(), 'Desktop'), path.join(os.homedir(), 'Documents'),
    path.join(os.homedir(), 'Documents', 'Minecraft'), path.join(os.homedir(), 'Documents', 'GriefGuardServers'),
  ]);
  const ignored = new Set(['node_modules', '.git', '.svn', 'Backups', 'logs', 'cache', 'libraries']);
  const found = new Set();
  let visited = 0;
  function visit(directory, depth) {
    if (visited >= 1200 || depth > 4 || ignored.has(path.basename(directory))) return;
    visited += 1;
    if (isPaperServerDirectory(directory)) { found.add(path.resolve(directory)); return; }
    let entries = [];
    try { entries = fs.readdirSync(directory, { withFileTypes: true }); } catch (_) { return; }
    for (const entry of entries) {
      if (entry.isDirectory() && !ignored.has(entry.name) && !entry.name.startsWith('.')) visit(path.join(directory, entry.name), depth + 1);
    }
  }
  roots.forEach(root => visit(root, 0));
  return [...found].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}
function inspectPaperServer(serverDir) {
  const directory = exists(serverDir) && fs.statSync(serverDir).isDirectory();
  const properties = directory && exists(path.join(serverDir, 'server.properties'));
  const jar = directory ? findPaperJar(serverDir) : '';
  const plugins = directory && exists(path.join(serverDir, 'plugins'));
  const world = directory && exists(path.join(serverDir, 'world'));
  return {
    serverDir,
    directory,
    properties,
    jar,
    plugins,
    world,
    valid: directory && Boolean(jar),
    initialized: directory && Boolean(jar) && properties,
  };
}
function normalizePastedPath(value) {
  let input = String(value || '').trim();
  // A frequent support issue was pasting a terminal command ("cd …") into a
  // path field. Normal setup no longer asks for a path, but this keeps the
  // advanced CLI option forgiving and avoids treating `cd` as a directory.
  input = input.replace(/^cd\s+(?:--\s+)?/i, '').trim();
  if ((input.startsWith('"') && input.endsWith('"')) || (input.startsWith("'") && input.endsWith("'"))) input = input.slice(1, -1);
  if (input.startsWith('file://')) {
    try { input = decodeURIComponent(new URL(input).pathname); } catch (_) {}
  }
  if (process.platform !== 'win32') input = input.replace(/\\ /g, ' ').replace(/\\(["'\\])/g, '$1');
  return input;
}
function normalizePaperServerSelection(selectedPath) {
  if (!selectedPath) return { serverDir: '', corrected: false };
  let resolved = path.resolve(normalizePastedPath(selectedPath));
  if (exists(resolved) && fs.statSync(resolved).isFile()) resolved = path.dirname(resolved);
  const direct = inspectPaperServer(resolved);
  if (direct.valid) return { serverDir: resolved, corrected: false };

  // A frequent mistake is selecting plugins/, world/, or the GriefGuard
  // configuration folder. When the immediately enclosing folder is a valid
  // Paper root, use it automatically instead of making the user type a path.
  const parent = path.dirname(resolved);
  const parentInfo = inspectPaperServer(parent);
  if (parentInfo.valid) return { serverDir: parent, corrected: true };
  return { serverDir: resolved, corrected: false };
}
function printPaperInspection(info) {
  console.log(`\n選択したフォルダ: ${info.serverDir}`);
  console.log(`  ${info.directory ? '✓' : '×'} フォルダとして存在`);
  console.log(`  ${info.jar ? '✓' : '×'} Paper JAR${info.jar ? `: ${info.jar}` : ''}`);
  console.log(`  ${info.properties ? '✓' : '△'} server.properties${info.properties ? '' : '（初回起動前なら未作成で問題ありません）'}`);
  console.log(`  ${info.plugins ? '✓' : '△'} plugins${info.plugins ? '' : '（インストーラーが作成します）'}`);
  console.log(`  ${info.world ? '✓' : '△'} world${info.world ? '' : '（初回起動時に生成されます）'}`);
}
function chooseFolderDialog(prompt, allowNewFolder = false) {
  if (process.platform === 'darwin') {
    const escaped = String(prompt).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const result = spawnSync('osascript', ['-e', `POSIX path of (choose folder with prompt "${escaped}")`], { encoding: 'utf8' });
    return result.status === 0 ? String(result.stdout || '').trim() : '';
  }
  if (process.platform === 'win32') {
    const escaped = String(prompt).replace(/'/g, "''");
    const command = [
      'Add-Type -AssemblyName System.Windows.Forms',
      '$dialog = New-Object System.Windows.Forms.FolderBrowserDialog',
      `$dialog.Description = '${escaped}'`,
      `$dialog.ShowNewFolderButton = $${allowNewFolder ? 'true' : 'false'}`,
      'if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) }',
    ].join('; ');
    const result = spawnSync('powershell.exe', ['-NoProfile', '-STA', '-Command', command], { encoding: 'utf8' });
    return result.status === 0 ? String(result.stdout || '').trim() : '';
  }
  return '';
}
function choosePaperFileDialog(prompt) {
  if (process.platform === 'darwin') {
    const escaped = String(prompt).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const result = spawnSync('osascript', ['-e', `POSIX path of (choose file with prompt "${escaped}")`], { encoding: 'utf8' });
    return result.status === 0 ? String(result.stdout || '').trim() : '';
  }
  if (process.platform === 'win32') {
    const escaped = String(prompt).replace(/'/g, "''");
    const command = [
      'Add-Type -AssemblyName System.Windows.Forms',
      '$dialog = New-Object System.Windows.Forms.OpenFileDialog',
      `$dialog.Title = '${escaped}'`,
      "$dialog.Filter = 'Paper または server.properties|*.jar;server.properties;start.bat;start.command|すべてのファイル|*.*'",
      'if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }',
    ].join('; ');
    const result = spawnSync('powershell.exe', ['-NoProfile', '-STA', '-Command', command], { encoding: 'utf8' });
    return result.status === 0 ? String(result.stdout || '').trim() : '';
  }
  return '';
}
async function selectExistingPaperFolder() {
  // Selecting a known server must be a direct Explorer/Finder operation. The
  // automatic scan is retained only as a recovery option for people who do
  // not know where their Paper folder is located.
  console.log('\nExplorer / Finderを開きます。');
  console.log('paper.jar、plugins、world、server.propertiesが入るPaperサーバーの一番上のフォルダを選んでください。');
  let selectedFolder = chooseFolderDialog('Paperサーバーの一番上のフォルダを選択してください。paper.jar、plugins、worldが入るフォルダです。');
  if (selectedFolder) return selectedFolder;
  const fallback = await choose('フォルダの選択を取り消しました。次に行う操作', [
    ['1', 'Explorer / Finderをもう一度開く'],
    ['2', 'PC内のPaperサーバーを自動検索する'],
  ], '1');
  if (fallback === '1') {
    selectedFolder = chooseFolderDialog('Paperサーバーの一番上のフォルダを選択してください。');
    if (selectedFolder) return selectedFolder;
    fail('Paperサーバーが選択されませんでした。セットアップを終了します。');
  }
  let candidates = [];
  try {
    console.log('既存Paperサーバーを検索しています…');
    candidates = searchExistingPaperServers();
    console.log(`検索完了: ${candidates.length}件`);
  } catch (error) {
    // A discovery failure must never terminate setup. The native picker is a
    // complete fallback and keeps implementation details out of the UI.
    warn('既存Paperの自動検索を完了できませんでした。ファイル選択画面から選択できます。');
    console.log('[INFO] 検索をスキップして、Paperファイルの選択へ進みます。');
  }
  if (candidates.length === 1) {
    ok(`既存Paperサーバーを自動検出: ${candidates[0]}`);
    return candidates[0];
  }
  if (candidates.length > 1) {
    const shown = candidates.slice(0, 12);
    console.log('\n既存のPaperサーバーを自動検出しました。番号を選んでください。');
    shown.forEach((candidate, index) => console.log(`  ${index + 1}. ${candidate}`));
    console.log(`  ${shown.length + 1}. 一覧にない（ファイル選択画面を開く）`);
    const choice = await choose('使用するPaperサーバー', [...shown.map((candidate, index) => [String(index + 1), candidate]), [String(shown.length + 1), 'ファイル選択画面を開く']], '1');
    const number = Number(choice);
    if (number >= 1 && number <= shown.length) return shown[number - 1];
  }
  console.log('\nPaperの場所を自動検出できませんでした。');
  console.log('開く画面では「paper.jar」「server.properties」「start.bat / start.command」のどれか一つを選ぶだけで大丈夫です。');
  const selectedFile = choosePaperFileDialog('Paper JAR、server.properties、または start ファイルを一つ選択してください。');
  if (selectedFile) return selectedFile;
  selectedFolder = chooseFolderDialog('Paperサーバーの一番上のフォルダを選択してください。paper.jar、plugins、worldが入るフォルダです。');
  if (selectedFolder) return selectedFolder;
  fail('Paperサーバーを選択できませんでした。もう一度実行して、Paper JARまたはserver.propertiesを選択してください。');
}
async function chooseNewPaperDirectory() {
  if (argv.get('create-parent')) {
    const parent = path.resolve(argv.get('create-parent'));
    const name = argv.get('server-name') || 'MinecraftServer';
    return { parent, serverDir: path.join(parent, name) };
  }
  if (nonInteractive) {
    const parent = defaultServerParent();
    return { parent, serverDir: nextAvailableServerDirectory(parent) };
  }
  while (true) {
    console.log('\nExplorer / Finderを開きます。新しいMinecraftサーバーを置く親フォルダを選んでください。');
    console.log('例: D:\\MinecraftServers を選ぶと、その中にMinecraftServerが作成されます。');
    const parent = chooseFolderDialog('新しいMinecraftServerを作る親フォルダを選択してください。', true);
    if (!parent) fail('作成先フォルダが選択されませんでした。セットアップを終了します。');
    const serverDir = nextAvailableServerDirectory(parent);
    console.log(`\n新規Paperサーバーの作成先:\n  ${serverDir}`);
    const confirm = await choose('この場所にPaperサーバーを作成しますか？', [
      ['1', 'この場所に作成する'],
      ['2', 'Explorer / Finderで選び直す'],
    ], '1');
    if (confirm === '1') return { parent, serverDir };
  }
}
async function chooseExistingPaperServer() {
  let selected = argv.get('server-dir') || await selectExistingPaperFolder();
  while (true) {
    const normalized = normalizePaperServerSelection(selected);
    const inspection = inspectPaperServer(normalized.serverDir);
    if (normalized.corrected) ok(`選択した子フォルダからPaperサーバーフォルダを自動判定: ${normalized.serverDir}`);
    printPaperInspection(inspection);
    if (!inspection.valid) fail(`Paper JARが見つかりません: ${normalized.serverDir}\n「paper.jar」または「paper-<version>.jar」が直接入っているPaperサーバーの一番上のフォルダを選択してください。`);
    if (!inspection.initialized) warn('server.properties はまだありません。Paperを一度も起動していない新規サーバーとしてセットアップします。');
    if (nonInteractive || await choose('このPaperサーバーを使用しますか？', [['1', 'この場所を使用する'], ['2', 'Finder / エクスプローラーで選び直す']], '1') === '1') return { serverDir: normalized.serverDir, inspection };
    selected = choosePaperFileDialog('Paper JAR、server.properties、または start ファイルを一つ選択してください。');
    if (!selected) selected = chooseFolderDialog('Paperサーバーの一番上のフォルダを選択してください。paper.jar、plugins、worldが入るフォルダです。');
    if (!selected) fail('Paperサーバーを選択できませんでした。選択画面でpaper.jarまたはserver.propertiesを選んでください。');
  }
}
async function chooseWorkspaceFolder(serverDir) {
  const recommended = defaultWorkspace(serverDir);
  // Agent files do not exist until this point.  Choosing their location before
  // Paper is selected made the first-run flow needlessly circular, so normal
  // setup always creates the adjacent recommended workspace automatically.
  ok(`管理ワークスペースを自動作成: ${recommended}`);
  return recommended;
}
function defaultWorkspace(serverDir) { return path.join(path.dirname(serverDir), 'GriefGuard-HomeServer'); }
function findPluginByPrefix(serverDir, prefix) {
  const plugins = path.join(serverDir, 'plugins');
  if (!exists(plugins)) return '';
  return fs.readdirSync(plugins).find(name => new RegExp(`^${prefix}.*\\.jar$`, 'i').test(name)) || '';
}
function validatePort(value, label) {
  if (!/^\d+$/.test(String(value)) || Number(value) < 1 || Number(value) > 65535) fail(`${label}は1〜65535で指定してください。`);
  return Number(value);
}
function writeServerPort(serverDir, port) {
  const file = path.join(serverDir, 'server.properties');
  const next = `server-port=${port}`;
  if (!exists(file)) {
    fs.writeFileSync(file, `# GriefGuard installer setting\n${next}\n`, 'utf8');
    ok(`server.propertiesを作成し、Java版ポートを設定: ${port}`);
    return;
  }
  const previous = fs.readFileSync(file, 'utf8');
  const updated = /^server-port=.*/m.test(previous)
    ? previous.replace(/^server-port=.*/m, next)
    : `${previous.endsWith('\n') ? previous : `${previous}\n`}${next}\n`;
  if (updated !== previous) fs.writeFileSync(file, updated, 'utf8');
  ok(`server.propertiesのJava版ポートを設定: ${port}`);
}
function pluginJar() {
  const candidates = [path.join(agentRoot, '..', 'GriefGuard.jar'), path.join(agentRoot, '..', 'plugin', 'GriefGuard.jar'), path.join(agentRoot, 'GriefGuard.jar')];
  return candidates.find(exists) || '';
}
function readZipEntry(file, wantedName) {
  const data = fs.readFileSync(file);
  // Read the central directory first. Maven JARs commonly use a data
  // descriptor, so the local header can legitimately contain zero sizes.
  for (let offset = 0; offset + 46 <= data.length; offset += 1) {
    if (data.readUInt32LE(offset) !== 0x02014b50) continue;
    const method = data.readUInt16LE(offset + 10);
    const compressedSize = data.readUInt32LE(offset + 20);
    const nameLength = data.readUInt16LE(offset + 28);
    const extraLength = data.readUInt16LE(offset + 30);
    const commentLength = data.readUInt16LE(offset + 32);
    const localOffset = data.readUInt32LE(offset + 42);
    const name = data.subarray(offset + 46, offset + 46 + nameLength).toString('utf8');
    if (name === wantedName && localOffset + 30 <= data.length) {
      const localNameLength = data.readUInt16LE(localOffset + 26);
      const localExtraLength = data.readUInt16LE(localOffset + 28);
      const contentStart = localOffset + 30 + localNameLength + localExtraLength;
      const compressed = data.subarray(contentStart, contentStart + compressedSize);
      if (method === 0) return compressed.toString('utf8');
      if (method === 8) return zlib.inflateRawSync(compressed).toString('utf8');
      return '';
    }
    offset += 45 + nameLength + extraLength + commentLength;
  }
  // Fallback for small hand-built ZIPs without a conventional central scan.
  let offset = 0;
  while (offset + 30 <= data.length) {
    if (data.readUInt32LE(offset) !== 0x04034b50) { offset += 1; continue; }
    const flags = data.readUInt16LE(offset + 6);
    const method = data.readUInt16LE(offset + 8);
    const compressedSize = data.readUInt32LE(offset + 18);
    const nameLength = data.readUInt16LE(offset + 26);
    const extraLength = data.readUInt16LE(offset + 28);
    const nameStart = offset + 30;
    const contentStart = nameStart + nameLength + extraLength;
    const name = data.subarray(nameStart, nameStart + nameLength).toString('utf8');
    if (name === wantedName && !(flags & 0x08) && contentStart + compressedSize <= data.length) {
      const compressed = data.subarray(contentStart, contentStart + compressedSize);
      if (method === 0) return compressed.toString('utf8');
      if (method === 8) return zlib.inflateRawSync(compressed).toString('utf8');
      return '';
    }
    offset = contentStart + Math.max(0, compressedSize);
  }
  return '';
}
function detectPluginEdition(file) {
  try {
    const properties = readZipEntry(file, 'edition.properties');
    return /^edition=high\s*$/mi.test(properties) ? 'high' : 'standard';
  } catch (_) { return 'standard'; }
}
function highDefaults() {
  return {
    connectionHistory: true, accountCorrelation: false, connectionDefense: true,
    autoRelaxation: false, requiredEligibleDays: 14,
    minimumActiveMinutesPerDay: 30, warningFreeDays: 7,
    countExistingHistory: false, notifyPlayer: true
  };
}
function readHighVersionSettings(serverDir) {
  const file = path.join(serverDir, 'plugins', 'GriefGuard', 'config.yml');
  if (!exists(file)) return highDefaults();
  const content = fs.readFileSync(file, 'utf8');
  const bool = (key, fallback) => {
    const value = parseYamlField(content, key);
    return value == null || value === '' ? fallback : value === 'true';
  };
  const number = (key, fallback) => {
    const value = Number(parseYamlField(content, key));
    return Number.isInteger(value) ? value : fallback;
  };
  return {
    connectionHistory: bool('high-version.connection-history.enabled', true),
    accountCorrelation: bool('high-version.account-correlation.enabled', false),
    connectionDefense: bool('high-version.connection-defense.enabled', true),
    autoRelaxation: bool('high-version.auto-relaxation.enabled', false),
    requiredEligibleDays: number('high-version.auto-relaxation.required-eligible-days', 14),
    minimumActiveMinutesPerDay: number('high-version.auto-relaxation.minimum-active-minutes-per-day', 30),
    warningFreeDays: number('high-version.auto-relaxation.warning-free-days', 7),
    countExistingHistory: bool('high-version.auto-relaxation.count-existing-history', false),
    notifyPlayer: bool('high-version.auto-relaxation.notify-player', true)
  };
}
async function chooseHighVersionSettings(serverDir, edition) {
  if (edition !== 'high') return null;
  step(12, 'HighVersion専用機能');
  const current = readHighVersionSettings(serverDir);
  const enabled = async (label, value, argument) => {
    const supplied = argv.get(argument);
    if (supplied === 'yes' || supplied === 'no') return supplied === 'yes';
    return (await choose(label, [['1', 'ON'], ['2', 'OFF']], value ? '1' : '2')) === '1';
  };
  const settings = { ...current };
  settings.connectionHistory = await enabled('接続履歴を保存しますか？', current.connectionHistory, 'high-history');
  settings.accountCorrelation = settings.connectionHistory
    ? await enabled('関連アカウント候補を表示しますか？', current.accountCorrelation, 'high-correlation')
    : false;
  settings.connectionDefense = await enabled('HighVersion接続防御を有効にしますか？', current.connectionDefense, 'high-defense');
  settings.autoRelaxation = await enabled('安全なプレイヤーを日数で自動的に緩和しますか？', current.autoRelaxation, 'high-auto-relax');
  if (settings.autoRelaxation) {
    settings.requiredEligibleDays = Number(argv.get('high-relax-days')
      || await ask('緩和までの有効プレイ日数（1〜365）', String(current.requiredEligibleDays)));
    settings.minimumActiveMinutesPerDay = Number(argv.get('high-active-minutes')
      || await ask('1日として数える最低プレイ時間（分）', String(current.minimumActiveMinutesPerDay)));
  }
  const validated = validateHighVersion(settings);
  console.log('\nHighVersion専用設定:');
  console.log(`  接続履歴: ${validated.connectionHistory ? 'ON' : 'OFF'}`);
  console.log(`  関連アカウント候補: ${validated.accountCorrelation ? 'ON' : 'OFF'}`);
  console.log(`  接続防御: ${validated.connectionDefense ? 'ON' : 'OFF'}`);
  console.log(`  自動緩和: ${validated.autoRelaxation ? `ON（${validated.requiredEligibleDays}有効日）` : 'OFF'}`);
  return validated;
}
function applyHighVersionSettings(serverDir, settings) {
  if (!settings) return { applied: false, reason: 'standard-edition' };
  const file = path.join(serverDir, 'plugins', 'GriefGuard', 'config.yml');
  if (!exists(file)) return { applied: false, pending: true, reason: 'config.ymlはPaper初回起動後に生成されます。' };
  const original = fs.readFileSync(file, 'utf8');
  let content = original;
  if (parseYamlField(content, 'high-version.connection-history.enabled') == null) {
    const block = [
      '', 'high-version:', '  connection-history:', '    enabled: true',
      '    retention-days: 30', '    banned-attempt-retention-days: 90',
      '  account-correlation:', '    enabled: false', '    same-address: true',
      '  connection-defense:', '    enabled: true', '    per-second-limit: 8',
      '    per-ten-seconds-limit: 30', '    initial-block-seconds: 5',
      '    permanent-ip-ban: false', '  auto-relaxation:', '    enabled: false',
      '    required-eligible-days: 14', '    minimum-active-minutes-per-day: 30',
      '    warning-free-days: 7', '    count-existing-history: false',
      '    notify-player: true', ''
    ].join(content.includes('\r\n') ? '\r\n' : '\n');
    content = `${content.replace(/\s*$/, '')}${block}`;
  } else if (parseYamlField(content, 'high-version.auto-relaxation.enabled') == null) {
    const newline = content.includes('\r\n') ? '\r\n' : '\n';
    const lines = content.split(/\r?\n/);
    const highIndex = lines.findIndex(line => /^high-version:\s*(?:#.*)?$/.test(line));
    let insertAt = lines.length;
    for (let index = highIndex + 1; index < lines.length; index++) {
      if (/^[^\s#][^:]*:/.test(lines[index])) { insertAt = index; break; }
    }
    lines.splice(insertAt, 0,
      '  auto-relaxation:', '    enabled: false',
      '    required-eligible-days: 14', '    minimum-active-minutes-per-day: 30',
      '    warning-free-days: 7', '    count-existing-history: false',
      '    notify-player: true');
    content = lines.join(newline);
  }
  const fields = {
    'high-version.connection-history.enabled': settings.connectionHistory,
    'high-version.account-correlation.enabled': settings.accountCorrelation,
    'high-version.connection-defense.enabled': settings.connectionDefense,
    'high-version.auto-relaxation.enabled': settings.autoRelaxation,
    'high-version.auto-relaxation.required-eligible-days': settings.requiredEligibleDays,
    'high-version.auto-relaxation.minimum-active-minutes-per-day': settings.minimumActiveMinutesPerDay,
    'high-version.auto-relaxation.warning-free-days': settings.warningFreeDays,
    'high-version.auto-relaxation.count-existing-history': settings.countExistingHistory,
    'high-version.auto-relaxation.notify-player': settings.notifyPlayer
  };
  for (const [key, value] of Object.entries(fields)) content = writeYamlField(content, key, value);
  if (content !== original) {
    const backup = `${file}.before-high-version-${timestamp()}.bak`;
    fs.copyFileSync(file, backup);
    fs.writeFileSync(file, content, 'utf8');
  }
  for (const [key, value] of Object.entries(fields)) {
    if (String(parseYamlField(content, key)) !== String(value)) fail(`HighVersion設定を確認できません: ${key}`);
  }
  return { applied: true, file, changed: content !== original };
}
function requiredJava(version) {
  if (/^26\./.test(version)) return 25;
  if (/^1\.21(?:\.|$)/.test(version)) return 21;
  if (/^1\.20\.(?:5|6)$/.test(version)) return 21;
  if (/^1\.(17|18|19)(?:\.|$)/.test(version) || /^1\.20(?:\.[0-4])?$/.test(version)) return 17;
  if (/^1\.16\.5$/.test(version)) return 16;
  if (/^1\.(12|13|14|15|16)/.test(version)) return 11;
  // An existing server does not reliably expose its Minecraft version before
  // Paper has started. GriefGuard itself requires Java 17, so use that safe
  // lower bound and tell the operator to follow Paper's own requirement.
  return 17;
}
function detectedJava(executable = 'java') {
  const result = spawnSync(executable, ['-version'], { encoding: 'utf8' });
  const output = `${result.stdout || ''}\n${result.stderr || ''}`;
  const match = output.match(/version\s+"(\d+)(?:\.|\")/);
  return { found: result.status === 0, major: match ? Number(match[1]) : 0, output: output.trim().split('\n')[0] || '', executable };
}
function temurinPlatform() {
  const osName = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'mac' : 'linux';
  const architecture = process.arch === 'arm64' ? 'aarch64' : process.arch === 'x64' ? 'x64' : '';
  if (!architecture) fail(`このCPUアーキテクチャの自動Java導入には対応していません: ${process.arch}`);
  return { osName, architecture };
}
function findJavaExecutable(directory, depth = 0) {
  if (depth > 5 || !exists(directory)) return '';
  const name = process.platform === 'win32' ? 'java.exe' : 'java';
  const direct = path.join(directory, 'bin', name);
  if (exists(direct)) return direct;
  let entries = [];
  try { entries = fs.readdirSync(directory, { withFileTypes: true }); } catch (_) { return ''; }
  for (const entry of entries) {
    if (entry.isDirectory()) {
      const result = findJavaExecutable(path.join(directory, entry.name), depth + 1);
      if (result) return result;
    }
  }
  return '';
}
function powerShellQuote(value) { return `'${String(value).replace(/'/g, "''")}'`; }
function extractJavaArchive(archive, destination) {
  let result;
  if (process.platform === 'win32') {
    if (/\.zip$/i.test(archive)) {
      const command = `Expand-Archive -LiteralPath ${powerShellQuote(archive)} -DestinationPath ${powerShellQuote(destination)} -Force`;
      result = spawnSync('powershell.exe', ['-NoProfile', '-Command', command], { encoding: 'utf8' });
    } else result = spawnSync('tar.exe', ['-xf', archive, '-C', destination], { encoding: 'utf8' });
  } else result = spawnSync('tar', ['-xf', archive, '-C', destination], { encoding: 'utf8' });
  if (result.status !== 0) fail(`Temurin JDKの展開に失敗しました: ${(result.stderr || result.stdout || '').trim() || '展開コマンドが失敗しました。'}`);
}
async function temurinAsset(required) {
  const { osName, architecture } = temurinPlatform();
  const endpoint = `https://api.adoptium.net/v3/assets/latest/${required}/hotspot?architecture=${architecture}&image_type=jdk&os=${osName}&vendor=eclipse`;
  const response = await fetch(endpoint, { headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' }, signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new Error(`Temurin公式APIへの接続に失敗しました: HTTP ${response.status}`);
  const releases = await response.json();
  const packageInfo = Array.isArray(releases)
    ? releases.map(release => release?.binary?.package).find(candidate => candidate?.link && candidate?.checksum)
    : null;
  if (!packageInfo) throw new Error(`Java ${required}用の公式Temurin JDKを取得できませんでした。`);
  const archiveName = path.basename(new URL(packageInfo.link).pathname);
  if (!/\.(zip|tar\.gz|tgz)$/i.test(archiveName)) throw new Error(`自動展開できないTemurin形式です: ${archiveName}`);
  return { ...packageInfo, archiveName, osName, architecture };
}
async function downloadPortableJava(required, workspace) {
  const asset = await temurinAsset(required);
  const runtimeRoot = path.join(workspace, 'runtime');
  fs.mkdirSync(runtimeRoot, { recursive: true, mode: 0o700 });
  const extractionRoot = fs.mkdtempSync(path.join(runtimeRoot, `temurin-${required}-`));
  const archive = path.join(extractionRoot, asset.archiveName);
  const temporary = `${archive}.download`;
  console.log(`公式Temurin JDK ${required}をダウンロードしています…`);
  const response = await fetch(asset.link, { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(300000) });
  if (!response.ok || !response.body) throw new Error(`Temurin JDKのダウンロードに失敗しました: HTTP ${response.status}`);
  const hash = crypto.createHash('sha256');
  const hashing = new Transform({ transform(chunk, encoding, callback) { hash.update(chunk); callback(null, chunk); } });
  await pipeline(Readable.fromWeb(response.body), hashing, fs.createWriteStream(temporary, { mode: 0o600 }));
  const actual = hash.digest('hex').toLowerCase();
  if (actual !== String(asset.checksum).toLowerCase()) {
    fs.renameSync(temporary, `${temporary}.checksum-failed`);
    throw new Error('Temurin JDKのSHA-256検証に失敗しました。ダウンロードしたファイルは使用しません。');
  }
  fs.renameSync(temporary, archive);
  ok(`Temurin JDKのSHA-256を検証: ${asset.archiveName}`);
  extractJavaArchive(archive, extractionRoot);
  const executable = findJavaExecutable(extractionRoot);
  if (!executable) throw new Error('展開したTemurin JDK内にjava実行ファイルが見つかりません。');
  const detected = detectedJava(executable);
  if (!detected.found || detected.major < required) throw new Error(`展開したTemurin JDKがJava ${required}以上として実行できません。`);
  fs.writeFileSync(path.join(extractionRoot, 'griefguard-runtime.json'), JSON.stringify({ required, executable, asset: { name: asset.archiveName, link: asset.link, checksum: asset.checksum }, installedAt: new Date().toISOString() }, null, 2));
  ok(`Temurin Java ${detected.major}をワークスペースへ導入: ${executable}`);
  return { ...detected, executable, downloaded: true };
}
function findCachedPortableJava(required, workspace) {
  const runtimeRoot = path.join(workspace, 'runtime');
  if (!exists(runtimeRoot)) return null;
  let entries;
  try {
    entries = fs.readdirSync(runtimeRoot, { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .sort((a, b) => fs.statSync(path.join(runtimeRoot, b.name)).mtimeMs - fs.statSync(path.join(runtimeRoot, a.name)).mtimeMs);
  } catch (_) { return null; }
  for (const entry of entries) {
    const root = path.join(runtimeRoot, entry.name);
    const marker = readJsonObject(path.join(root, 'griefguard-runtime.json'));
    const executable = marker?.executable && exists(marker.executable) ? marker.executable : findJavaExecutable(root);
    if (!executable) continue;
    const detected = detectedJava(executable);
    // Paper's requirement is not simply a lower bound. For example, Paper
    // 1.17 rejects Java 21 even though it is numerically newer than Java 17.
    // Reuse only the runtime matching the Paper generation selected above.
    if (detected.found && detected.major === required) {
      return { ...detected, executable, downloaded: true, cached: true };
    }
  }
  return null;
}
async function ensureJava(required, workspace) {
  const installed = detectedJava();
  // See findCachedPortableJava: older Paper builds can refuse a newer JVM.
  if (installed.found && installed.major === required) {
    ok(`Java ${installed.major}を検出`);
    return { ...installed, executable: 'java', downloaded: false };
  }
  const cached = findCachedPortableJava(required, workspace);
  if (cached) {
    ok(`ワークスペース内の既存Temurin Java ${cached.major}を再利用: ${cached.executable}`);
    return cached;
  }
  if (argv.get('skip-java-download') === 'yes') {
    fail(`Java ${required}以上が必要です。--skip-java-download を指定したため自動導入を行いません。`);
  }
  warn(installed.found ? `検出Java ${installed.major}は選択したPaperと互換ではありません。Java ${required}を自動導入します。` : `Javaが見つかりません。Java ${required}を自動導入します。`);
  try { return await downloadPortableJava(required, workspace); }
  catch (error) { fail(`${error.message}\nネットワーク接続を確認してセットアップを再実行してください。`); }
}
async function ask(question, fallback = '') {
  if (nonInteractive) return fallback;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const answer = await new Promise(resolve => rl.question(`${question}${fallback ? ` [${fallback}]` : ''}: `, resolve));
  rl.close();
  return answer.trim() || fallback;
}
async function choose(question, options, fallback) {
  if (nonInteractive) return fallback;
  console.log(`\n${question}`);
  options.forEach(([key, label]) => console.log(`  ${key}. ${label}`));
  const answer = await ask('番号を選択', fallback);
  return options.some(([key]) => key === answer) ? answer : fallback;
}
async function json(url) {
  const response = await fetch(url, { headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' }, signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new Error(`PaperMCへの接続に失敗しました: HTTP ${response.status}`);
  return response.json();
}
async function stablePaperVersions() {
  const project = await json('https://fill.papermc.io/v3/projects/paper');
  // The project catalogue also contains snapshots, pre-releases and release
  // candidates.  A version is shown only after its newest build is explicitly
  // marked STABLE by Paper's downloads API.
  const versions = [...new Set(Object.values(project.versions || {}).flat())]
    .filter(version => /^\d+(?:\.\d+){1,2}$/.test(version))
    .sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
  const checks = await Promise.all(versions.slice(0, 40).map(async version => {
    try { return await stableBuild(version); } catch (_) { return null; }
  }));
  return checks.filter(Boolean);
}
async function stableBuild(version) {
  const builds = await json(`https://fill.papermc.io/v3/projects/paper/versions/${encodeURIComponent(version)}/builds`);
  const stable = Array.isArray(builds)
    ? builds.filter(build => build.channel === 'STABLE').sort((a, b) => Number(b.id || b.number || 0) - Number(a.id || a.number || 0))[0]
    : null;
  const download = stable?.downloads?.['server:default'];
  if (!download?.url || !download?.checksums?.sha256) throw new Error(`${version}の安定版Paperビルドが見つかりません。`);
  return { version, id: stable.id || stable.number, url: download.url, sha256: download.checksums.sha256, size: download.size || 0, name: download.name || 'paper.jar' };
}
async function downloadPaper(build, destination) {
  const temporary = `${destination}.download`;
  const response = await fetch(build.url, { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(120000) });
  if (!response.ok || !response.body) throw new Error(`Paperのダウンロードに失敗しました: HTTP ${response.status}`);
  const content = Buffer.from(await response.arrayBuffer());
  const downloaded = content.length;
  fs.writeFileSync(temporary, content, { mode: 0o600 });
  const actual = crypto.createHash('sha256').update(content).digest('hex').toLowerCase();
  if (actual !== build.sha256.toLowerCase()) { fs.renameSync(temporary, `${temporary}.checksum-failed`); throw new Error('PaperのSHA-256検証に失敗しました。ファイルは採用していません。'); }
  if (build.size && downloaded !== build.size) warn(`Paperのサイズ情報が一致しません。公式SHA-256は一致しました。`);
  fs.renameSync(temporary, destination);
  fs.writeFileSync(`${destination}.griefguard-paper.json`, JSON.stringify({ ...build, downloadedAt: new Date().toISOString() }, null, 2));
  ok(`Paperを検証して保存: ${destination}`);
}
function diagnoseLauncher(file, kind) {
  if (!exists(file)) return { exists: false, level: 'missing', issues: [] };
  const text = fs.readFileSync(file, 'utf8');
  const issues = [];
  const add = (pattern, message, level = 'attention') => { if (pattern.test(text)) issues.push({ message, level }); };
  add(/\bpause\b/i, 'pauseにより自動停止後も黒い画面が残る', 'incompatible');
  add(/cmd\s+\/k|start\s+(?:cmd|powershell)/i, '別のcmdまたはPowerShellを開くため、Agentが状態を追跡しにくい', 'incompatible');
  add(/open\s+-a\s+terminal|osascript/i, '新しいTerminalタブを開くため、Agent運用に不向き', 'incompatible');
  add(/\bjavaw\b/i, 'javawはコンソールログを見えなくする', 'attention');
  add(/^\s*read\b/m, '入力待ちがあるため、停止後にタブが残る', 'incompatible');
  if (!/-jar\s+/i.test(text)) issues.push({ message: '-jar が見つからず、Paper JARを安全に起動できない', level: 'incompatible' });
  if (kind === 'command' && !/\bexec\s+(?:java|"\$JAVA_EXECUTABLE")/i.test(text)) issues.push({ message: 'exec javaがなく、Paper停止後にシェルが残る可能性がある', level: 'attention' });
  const level = issues.some(issue => issue.level === 'incompatible') ? 'incompatible' : issues.length ? 'attention' : 'compatible';
  return { exists: true, level, issues };
}
function backup(file) {
  const destination = `${file}.before-griefguard-${timestamp()}.bak`;
  fs.copyFileSync(file, destination);
  ok(`既存起動ファイルを退避: ${destination}`);
  return destination;
}
function launcherContent(jar, min, max, port, javaExecutable = 'java', managedUpdater = null) {
  // Managed plugins are checked by Update-Paper only. Starting Paper must be
  // deterministic and must not replace plugin JARs behind the administrator's back.
  const updateBat = '';
  const updateCommand = '';
  const bat = `@echo off\r\nrem GriefGuard recommended Agent launcher\r\nsetlocal\r\nset "PAPER_JAR=${jar}"\r\nset "MIN_MEMORY=${min}"\r\nset "MAX_MEMORY=${max}"\r\nset "SERVER_PORT=${port}"\r\nset "JAVA_EXECUTABLE=${javaExecutable}"\r\ncd /d "%~dp0"\r\nif not exist "%PAPER_JAR%" exit /b 10\r\nif /I "%JAVA_EXECUTABLE%"=="java" (\r\n  where java >nul 2>&1 || exit /b 11\r\n) else (\r\n  if not exist "%JAVA_EXECUTABLE%" exit /b 11\r\n)\r\npowershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort %SERVER_PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"\r\nif not errorlevel 1 (echo [INFO] Paper is already running. Skipping duplicate start.& exit /b 0)\r\n${updateBat}"%JAVA_EXECUTABLE%" -Xms%MIN_MEMORY% -Xmx%MAX_MEMORY% -jar "%PAPER_JAR%" --nogui\r\nexit /b %ERRORLEVEL%\r\n`;
  const manualBat = `${bat.replace('exit /b %ERRORLEVEL%\r\n', 'if errorlevel 1 pause\r\nexit /b %ERRORLEVEL%\r\n')}`;
  const command = `#!/bin/sh\n# GriefGuard recommended Agent launcher\nPAPER_JAR="${jar}"\nMIN_MEMORY="${min}"\nMAX_MEMORY="${max}"\nSERVER_PORT="${port}"\nJAVA_EXECUTABLE="${javaExecutable}"\nset -eu\nSERVER_DIRECTORY="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"\ncd "$SERVER_DIRECTORY"\n[ -f "$PAPER_JAR" ] || exit 10\nif [ "$JAVA_EXECUTABLE" = "java" ]; then command -v java >/dev/null 2>&1 || exit 11; else [ -x "$JAVA_EXECUTABLE" ] || exit 11; fi\nif command -v lsof >/dev/null 2>&1 && lsof -nP -iTCP:"$SERVER_PORT" -sTCP:LISTEN >/dev/null 2>&1; then printf '%s\\n' "[INFO] Paperは既に起動中です。二重起動をスキップします。"; exit 0; fi\n${updateCommand}exec "$JAVA_EXECUTABLE" -Xms"$MIN_MEMORY" -Xmx"$MAX_MEMORY" -jar "$PAPER_JAR" --nogui\n`;
  const manualCommand = command.replace('exec "$JAVA_EXECUTABLE"', '"$JAVA_EXECUTABLE"').replace(' --nogui\n', ' --nogui\nprintf "\\nPaper stopped. Press Enter to close.\\n"\nread -r _\n');
  return { bat, manualBat, command, manualCommand };
}
function shellQuote(value) { return `'${String(value).replace(/'/g, `'\\''`)}'`; }
function batchQuote(value) { return `"${String(value).replace(/"/g, '""')}"`; }
function createAgentLauncher(workspace, agentData, port = 3000) {
  const name = process.platform === 'win32' ? 'Start-GriefGuard-Agent.bat' : 'Start-GriefGuard-Agent.command';
  const destination = path.join(workspace, name);
  const node = process.execPath;
  const entry = path.join(agentRoot, 'server.js');
  let content;
  if (process.platform === 'win32') {
    content = `@echo off\r\nrem Starts GriefGuard Mobile Manager. Keep this window open while using the app.\r\nsetlocal\r\nset "GRIEFGUARD_AGENT_DATA_DIR=${agentData}"\r\nset "GRIEFGUARD_PORT=${port}"\r\ncd /d ${batchQuote(agentRoot)}\r\n${batchQuote(node)} ${batchQuote(entry)}\r\nif errorlevel 1 pause\r\n`;
  } else {
    content = `#!/bin/sh\n# Starts GriefGuard Mobile Manager. Keep this Terminal window open while using the app.\nexport GRIEFGUARD_AGENT_DATA_DIR=${shellQuote(agentData)}\nexport GRIEFGUARD_PORT=${shellQuote(port)}\ncd ${shellQuote(agentRoot)}\nexec ${shellQuote(node)} ${shellQuote(entry)}\n`;
  }
  fs.writeFileSync(destination, content, { encoding: 'utf8', mode: 0o700 });
  try { fs.chmodSync(destination, 0o755); } catch (_) {}
  ok(`Agent起動用ファイルを作成: ${destination}`);
  return destination;
}
function createAgentControlLaunchers(workspace, agentData) {
  const script = path.join(agentRoot, 'scripts', 'agent-control.js');
  const node = process.execPath;
  const definitions = process.platform === 'win32'
    ? [
        ['stop', 'Stop-GriefGuard-Agent.bat', 'Stops only the GriefGuard Agent owned by this workspace.'],
        ['setup-code', 'Show-GriefGuard-Setup-Code.bat', 'Issues a new one-time initial setup code on this PC.'],
        ['password-reset', 'Reset-GriefGuard-Admin-Password.bat', 'Issues a password reset code on this PC.']
      ]
    : [
        ['stop', 'Stop-GriefGuard-Agent.command', 'Stops only the GriefGuard Agent owned by this workspace.'],
        ['setup-code', 'Show-GriefGuard-Setup-Code.command', 'Issues a new one-time initial setup code on this Mac.'],
        ['password-reset', 'Reset-GriefGuard-Admin-Password.command', 'Issues a password reset code on this Mac.']
      ];
  const created = {};
  for (const [action, name, description] of definitions) {
    const file = path.join(workspace, name);
    const content = process.platform === 'win32'
      ? `@echo off\r\nrem ${description}\r\nsetlocal\r\n${batchQuote(node)} ${batchQuote(script)} --action ${action} --agent-data ${batchQuote(agentData)}\r\necho.\r\npause\r\n`
      : `#!/bin/sh\n# ${description}\nset -u\n${shellQuote(node)} ${shellQuote(script)} --action ${shellQuote(action)} --agent-data ${shellQuote(agentData)}\nSTATUS=$?\nprintf '\\nPress Return to close.\\n'\nread -r _\nexit "$STATUS"\n`;
    fs.writeFileSync(file, content, { encoding: 'utf8', mode: 0o700 });
    try { fs.chmodSync(file, 0o755); } catch (_) {}
    created[action === 'setup-code' ? 'setupCode' : action === 'password-reset' ? 'passwordReset' : 'stop'] = file;
  }
  ok(`Agent停止用ファイルを作成: ${created.stop}`);
  ok(`初回コード再発行用ファイルを作成: ${created.setupCode}`);
  ok(`管理パスワードリセット用ファイルを作成: ${created.passwordReset}`);
  return created;
}
function createAgentMaintenanceLaunchers(workspace, agentData, agentLauncher) {
  const script = path.join(agentRoot, 'scripts', 'agent-control.js');
  const node = process.execPath;
  const isWindows = process.platform === 'win32';
  const extension = isWindows ? 'bat' : 'command';
  const status = path.join(workspace, `Agent-Status.${extension}`);
  const restart = path.join(workspace, `Restart-GriefGuard-Agent.${extension}`);
  const logs = path.join(workspace, `View-Agent-Log.${extension}`);
  const openApp = path.join(workspace, `Open-GriefGuard-App.${extension}`);
  const guide = path.join(workspace, 'Agent-Manual-Controls.txt');
  const statusContent = isWindows
    ? `@echo off\r\nsetlocal\r\n${batchQuote(node)} ${batchQuote(script)} --action status --agent-data ${batchQuote(agentData)}\r\necho.\r\npause\r\n`
    : `#!/bin/sh\nset -u\n${shellQuote(node)} ${shellQuote(script)} --action status --agent-data ${shellQuote(agentData)}\nSTATUS=$?\nprintf '\\nPress Return to close.\\n'\nread -r _\nexit "$STATUS"\n`;
  const restartContent = isWindows
    ? `@echo off\r\nsetlocal\r\n${batchQuote(node)} ${batchQuote(script)} --action stop --agent-data ${batchQuote(agentData)}\r\ntimeout /t 2 /nobreak >nul\r\nstart "GriefGuard Agent" ${batchQuote(agentLauncher)}\r\necho [OK] Agentを再起動しました。\r\npause\r\n`
    : `#!/bin/sh\nset -u\n${shellQuote(node)} ${shellQuote(script)} --action stop --agent-data ${shellQuote(agentData)}\nSTATUS=$?\nif [ "$STATUS" -eq 0 ]; then\n  sleep 2\n  open ${shellQuote(agentLauncher)}\n  printf '%s\\n' '[OK] Agentを再起動しました。'\nfi\nprintf '\\nPress Return to close.\\n'\nread -r _\nexit "$STATUS"\n`;
  const logsContent = isWindows
    ? `@echo off\r\nexplorer ${batchQuote(path.join(workspace, 'agent-log'))}\r\n`
    : `#!/bin/sh\nopen ${shellQuote(path.join(workspace, 'agent-log'))}\n`;
  const openAppContent = isWindows
    ? `@echo off\r\nrem Daily use only. This does not run the installer or change Agent settings.\r\nstart \"GriefGuard Mobile Manager\" \"http://localhost:3000\"\r\n`
    : `#!/bin/sh\n# Daily use only. This does not run the installer or change Agent settings.\nopen \"http://localhost:3000\"\n`;
  fs.writeFileSync(status, statusContent, { encoding: 'utf8', mode: 0o700 });
  fs.writeFileSync(restart, restartContent, { encoding: 'utf8', mode: 0o700 });
  fs.writeFileSync(logs, logsContent, { encoding: 'utf8', mode: 0o700 });
  fs.writeFileSync(openApp, openAppContent, { encoding: 'utf8', mode: 0o700 });
  fs.writeFileSync(guide, [
    'GriefGuard Agent 手動管理', '',
    '日常の利用では、この管理ワークスペース内のファイルだけを使用してください。',
    '配布フォルダ内の GriefGuard-Setup / Start-GriefGuard-Setup は、インストーラーを再実行するためのファイルです。日常操作には使用しません。', '',
    `${path.basename(openApp)}: 保存済みの管理画面（ローカル）を開きます。Agentは自動起動設定で起動します。`,
    `Start-GriefGuard-Agent.${extension}: Agentを手動起動します。`,
    `Stop-GriefGuard-Agent.${extension}: この管理ワークスペースのAgentだけを正常停止します。`,
    `${path.basename(restart)}: Agentを停止してから再起動します。`,
    `${path.basename(status)}: Agent、初回設定、Bridgeの状態を確認します。`,
    `${path.basename(logs)}: Agentログのフォルダを開きます。`,
    `Show-GriefGuard-Setup-Code.${extension}: 初回設定コードを再発行します。`,
    `Reset-GriefGuard-Admin-Password.${extension}: 管理パスワードのリセットコードを発行します。`,
    '', 'AgentData、トークン、初回コード、パスワードを共有しないでください。'
  ].join('\n') + '\n', { encoding: 'utf8', mode: 0o600 });
  try { [status, restart, logs, openApp].forEach(file => fs.chmodSync(file, 0o755)); } catch (_) {}
  ok(`Agent手動管理ファイルを作成: ${guide}`);
  return { status, restart, logs, openApp, guide };
}
function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function writePrivateJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(file, 0o600); } catch (_) {}
}
function writeSetupState(file, value) {
  const temporary = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temporary, file);
  try { fs.chmodSync(file, 0o600); } catch (_) {}
}
function createTailscaleResumeLauncher(workspace, stateFile) {
  const name = process.platform === 'win32' ? 'Continue-Tailscale-Setup.bat' : 'Continue-Tailscale-Setup.command';
  const file = path.join(workspace, name);
  const script = path.join(agentRoot, 'scripts', 'setup-wizard.js');
  const content = process.platform === 'win32'
    ? `@echo off\r\nrem Resume only the pending Tailscale step.\r\n"${process.execPath}" "${script}" --resume-tailscale "${stateFile}"\r\npause\r\n`
    : `#!/bin/sh\n# Resume only the pending Tailscale step.\nexec ${shellQuote(process.execPath)} ${shellQuote(script)} --resume-tailscale ${shellQuote(stateFile)}\n`;
  fs.writeFileSync(file, content, { encoding: 'utf8', mode: 0o700 });
  try { fs.chmodSync(file, 0o755); } catch (_) {}
  return file;
}
function createPaperResumeLauncher(workspace, stateFile) {
  const name = process.platform === 'win32' ? 'Continue-Paper-Setup.bat' : 'Continue-Paper-Setup.command';
  const file = path.join(workspace, name);
  const script = path.join(agentRoot, 'scripts', 'setup-wizard.js');
  const content = process.platform === 'win32'
    ? `@echo off\r\nrem Resume only the pending Paper first-run step.\r\n"${process.execPath}" "${script}" --resume-paper "${stateFile}"\r\npause\r\n`
    : `#!/bin/sh\n# Resume only the pending Paper first-run step.\nexec ${shellQuote(process.execPath)} ${shellQuote(script)} --resume-paper ${shellQuote(stateFile)}\n`;
  fs.writeFileSync(file, content, { encoding: 'utf8', mode: 0o700 });
  try { fs.chmodSync(file, 0o755); } catch (_) {}
  return file;
}
function createBlueMapRepairLauncher(workspace, stateFile) {
  const name = process.platform === 'win32' ? 'Repair-BlueMap.bat' : 'Repair-BlueMap.command';
  const file = path.join(workspace, name);
  const script = path.join(agentRoot, 'scripts', 'setup-wizard.js');
  const content = process.platform === 'win32'
    ? `@echo off\r\nrem Repair only the BlueMap installation for this workspace.\r\n"${process.execPath}" "${script}" --repair-bluemap "${stateFile}"\r\npause\r\n`
    : `#!/bin/sh\n# Repair only the BlueMap installation for this workspace.\nexec ${shellQuote(process.execPath)} ${shellQuote(script)} --repair-bluemap ${shellQuote(stateFile)}\n`;
  fs.writeFileSync(file, content, { encoding: 'utf8', mode: 0o700 });
  try { fs.chmodSync(file, 0o755); } catch (_) {}
  return file;
}

function blueMapRenderSummary(serverDir) {
  const details = blueMapDetailsFor(serverDir);
  let ids = [];
  try {
    ids = fs.readdirSync(details.mapConfigDirectory)
      .filter(name => name.endsWith('.conf'))
      .map(name => path.basename(name, '.conf'));
  } catch (_) {}
  const coverage = mapCoverage(details.webroot, ids);
  const health = mapGenerationHealth(serverDir, details, coverage, ids);
  const overworld = health.maps.find(map => map.id === 'world') || health.maps[0] || null;
  return { details, ids, coverage: health.maps, overworld, health, blank: blankCoverage(health.maps) };
}

function blueMapResourceFingerprint(serverDir) {
  const summary = blueMapRenderSummary(serverDir);
  const digest = crypto.createHash('sha256');
  for (const map of summary.health.maps) {
    digest.update(`${map.id}:${map.config.world}:${map.config.dimension}:`);
    const texture = path.join(summary.details.webroot, 'maps', map.id, 'textures.json.gz');
    try { digest.update(fs.readFileSync(texture)); } catch (_) {}
    const worldGen = map.regionDirectory ? path.join(path.dirname(map.regionDirectory), 'data', 'minecraft', 'world_gen_settings.dat') : '';
    try { digest.update(fs.readFileSync(worldGen)); } catch (_) {}
  }
  return digest.digest('hex').slice(0, 20);
}

function archiveProblemBlueMapMaps(serverDir, { force = false } = {}) {
  const summary = blueMapRenderSummary(serverDir);
  const previous = summary.details.installerState?.resourceFingerprint || '';
  const fingerprint = blueMapResourceFingerprint(serverDir);
  const worldOrResourceChanged = Boolean(previous && previous !== fingerprint);
  const problemIds = new Set([
    ...summary.health.missingMaps,
    ...summary.health.mixedMaps,
    ...summary.coverage.filter(map => map.sample && map.sample.visibleRatio <= 0.002).map(map => map.id),
    ...(force || worldOrResourceChanged ? summary.ids : [])
  ]);
  const maps = summary.coverage.filter(map => problemIds.has(map.id));
  if (!maps.length) return { summary, moved: [], fingerprint, worldOrResourceChanged };
  const backupRoot = path.join(serverDir, 'bluemap', 'backups', `render-generation-${timestamp()}`);
  const moved = [];
  for (const map of maps) {
    const source = path.join(summary.details.webroot, 'maps', map.id);
    const destination = path.join(backupRoot, map.id);
    try {
      fs.mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
      // rename is atomic on the usual server-root webroot and never touches
      // Minecraft's world data. If a custom webroot is on another volume, do
      // not risk a copy-and-delete during automated repair.
      fs.renameSync(source, destination);
      moved.push({ id: map.id, source, destination });
    } catch (error) {
      warn(`BlueMap描画データの退避をスキップしました (${map.id}): ${error.message}`);
    }
  }
  return { summary, moved, backupRoot: moved.length ? backupRoot : null, fingerprint, worldOrResourceChanged };
}

function requestBlueMapSeedRender(child, serverDir, radius = 256) {
  const summary = blueMapRenderSummary(serverDir);
  const commands = summary.ids.map(id => `bluemap force-update ${id} 0 0 ${radius}`);
  for (const command of commands) {
    try { child.stdin.write(`${command}\n`); } catch (_) {}
  }
  return { ...summary, commands };
}

async function waitForBlueMapRenderable(serverDir, timeoutMs = 300000) {
  const started = Date.now();
  let last = blueMapRenderSummary(serverDir);
  while (Date.now() - started < timeoutMs) {
    last = blueMapRenderSummary(serverDir);
    const targets = [last.overworld].filter(Boolean);
    const pending = targets.filter(map => map.modelTiles === 0 || (map.id === 'world' && map.sample?.visibleRatio <= 0.002));
    if (!pending.length) return { ready: true, elapsedMs: Date.now() - started, summary: last, required: targets.map(map => map.id) };
    await delay(1000);
  }
  const targets = [last.overworld].filter(Boolean);
  return { ready: false, elapsedMs: Date.now() - started, summary: last, required: targets.map(map => map.id), pending: targets.filter(map => map.modelTiles === 0 || (map.id === 'world' && map.sample?.visibleRatio <= 0.002)).map(map => map.id) };
}
function nativeLauncherKind(platform = process.platform) {
  return platform === 'win32' ? 'bat' : 'command';
}
function removeGeneratedOppositeLaunchers(serverDir, nativeKind) {
  // A server can be moved between operating systems, so never remove a
  // user-authored alternate launcher. Only clean up files we generated and
  // can identify from their marker comment.
  const oppositeKind = nativeKind === 'bat' ? 'command' : 'bat';
  const candidates = oppositeKind === 'bat'
    ? ['start.bat', 'start-manual.bat']
    : ['start.command', 'start-manual.command'];
  const removed = [];
  for (const name of candidates) {
    const file = path.join(serverDir, name);
    try {
      if (exists(file) && fs.readFileSync(file, 'utf8').includes('GriefGuard recommended Agent launcher')) {
        fs.rmSync(file, { force: true });
        removed.push(file);
      }
    } catch (_) {}
  }
  return removed;
}
function installPaperUpdater(serverDir, workspace, java, min, max, port) {
  const directory = path.join(serverDir, '.griefguard');
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const updater = path.join(directory, 'GriefGuard-Paper-Updater.js');
  fs.copyFileSync(path.join(agentRoot, 'scripts', 'paper-updater.js'), updater);
  fs.copyFileSync(path.join(agentRoot, 'scripts', 'bluemap-installer.js'), path.join(directory, 'BlueMap-Installer.js'));
  const state = path.join(directory, 'paper-updater.json');
  writeSetupState(state, { version: 1, serverDirectory: serverDir, workspace, javaExecutable: java.executable, minMemory: min, maxMemory: max, serverPort: port, installedAt: new Date().toISOString() });
  const bat = `@echo off\r\nrem GriefGuard Paper updater\r\ncd /d "%~dp0"\r\n"${process.execPath}" ".griefguard\\GriefGuard-Paper-Updater.js" --server-dir "%~dp0"\r\npause\r\n`;
  const command = `#!/bin/sh\n# GriefGuard Paper updater\nSERVER_DIRECTORY="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"\ncd "$SERVER_DIRECTORY"\nexec ${shellQuote(process.execPath)} ".griefguard/GriefGuard-Paper-Updater.js" --server-dir "$SERVER_DIRECTORY"\n`;
  const nativeKind = nativeLauncherKind();
  const nativeFile = path.join(serverDir, nativeKind === 'bat' ? 'Update-Paper.bat' : 'Update-Paper.command');
  const oppositeFile = path.join(serverDir, nativeKind === 'bat' ? 'Update-Paper.command' : 'Update-Paper.bat');
  fs.writeFileSync(nativeFile, nativeKind === 'bat' ? bat : command, { encoding: 'utf8', mode: nativeKind === 'command' ? 0o755 : 0o600 });
  try { fs.chmodSync(nativeFile, nativeKind === 'command' ? 0o755 : 0o600); } catch (_) {}
  try {
    if (exists(oppositeFile) && fs.readFileSync(oppositeFile, 'utf8').includes('GriefGuard Paper updater')) fs.rmSync(oppositeFile, { force: true });
  } catch (_) {}
  return { updater, state, file: nativeFile, kind: nativeKind };
}
function installManagedPluginUpdater(serverDir, connection) {
  const directory = path.join(serverDir, '.griefguard');
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const script = path.join(directory, 'Managed-Plugin-Updater.js');
  fs.copyFileSync(path.join(agentRoot, 'scripts', 'managed-plugin-updater.js'), script);
  const state = path.join(directory, 'managed-plugins.json');
  const existing = readJsonObject(state) || {};
  const enabled = connection.mode === 'java-bedrock';
  const managed = {
    version: 1,
    enabled,
    platform: 'spigot',
    bedrockPort: connection.bedrockPort || null,
    projects: enabled ? ['geyser', 'floodgate', 'viaversion'] : [],
    compatibility: enabled ? { viaVersionRequired: true, reason: 'Geyser互換のため、PaperとGeyserのバージョン差をViaVersionで変換します。' } : null,
    plugins: existing.plugins || {},
    updatedAt: new Date().toISOString()
  };
  writeSetupState(state, managed);
  return { script, state, enabled, node: process.execPath };
}
async function installBedrockPlugins(updater) {
  if (!updater.enabled) return { skipped: true, reason: 'java-only' };
  const result = await new Promise(resolve => {
    const child = spawn(process.execPath, [updater.script, '--server-dir', path.dirname(path.dirname(updater.script)), '--install'], {
      cwd: path.dirname(path.dirname(updater.script)), windowsHide: true, stdio: 'inherit'
    });
    child.once('error', error => resolve({ ok: false, error: error.message }));
    child.once('exit', code => resolve({ ok: code === 0, code }));
  });
  if (!result.ok) fail(`GeyserMCとFloodgateを公式サイトから導入できませんでした。ネットワークを確認して再試行してください。終了コード: ${result.code ?? result.error}`);
  return result;
}

async function installBlueMap(serverDir, paperVersion, java) {
  // BlueMap is part of the normal mobile-management experience.  It is now
  // installed by default for both new and existing Paper choices; users can
  // explicitly opt out with option 2 or --bluemap no.
  const enabled = argv.get('bluemap') || (nonInteractive ? 'yes' : await choose('BlueMapのWebマップを導入しますか？（推奨）', [['1', '導入する（初回描画はCPU・容量を使用）'], ['2', '導入しない']], '1'));
  if (!['1', 'yes', 'true', 'auto'].includes(String(enabled).toLowerCase())) return { enabled: false, skipped: true, status: 'skipped-by-user' };
  const script = path.join(agentRoot, 'scripts', 'bluemap-installer.js');
  const child = spawn(process.execPath, [script, '--server-dir', serverDir, '--paper-version', String(paperVersion || ''), '--java-major', String(java.major || 0)], { cwd: serverDir, windowsHide: true, stdio: 'inherit' });
  const result = await new Promise(resolve => { child.once('error', error => resolve({ ok: false, error: error.message })); child.once('exit', code => resolve({ ok: code === 0, code })); });
  if (!result.ok) {
    warn(`BlueMapは導入できませんでした。PaperとJavaの対応状況を確認してから、後で再実行できます。${result.error ? ` ${result.error}` : ''}`);
    return { enabled: false, failed: true, status: 'install-failed', ...result };
  }
  const acceptedValue = String(argv.get('bluemap-accept-download') || '').toLowerCase();
  // The installer spells out this download, but pressing Enter keeps the
  // recommended automatic configuration.  --bluemap-accept-download no is
  // available for unattended deployments that must defer the consent.
  const accept = ['yes', 'true', '1'].includes(acceptedValue) || (!acceptedValue && (nonInteractive || await choose('BlueMapが地図描画用にMojangリソースを取得することへ同意しますか？', [['1', '同意して初回設定へ反映（推奨）'], ['2', '同意しない（導入済み・同意待ちとして保存）']], '1') === '1'));
  const stateFile = path.join(serverDir, '.griefguard', 'bluemap.json');
  const state = readJsonObject(stateFile) || {};
  const status = accept ? 'installed-awaiting-config' : 'installed-awaiting-consent';
  writeSetupState(stateFile, { ...state, managed: true, acceptDownload: accept, status, updatedAt: new Date().toISOString() });
  return { enabled: true, acceptDownload: accept, status, state: stateFile };
}

function configureBlueMapConfig(serverDir, blueMap) {
  if (!blueMap?.enabled) return { skipped: true };
  const directory = path.join(serverDir, 'plugins', 'BlueMap');
  const core = path.join(directory, 'core.conf');
  const webserver = path.join(directory, 'webserver.conf');
  if (!exists(core) || !exists(webserver)) return { pending: true, status: blueMap.acceptDownload ? 'installed-awaiting-config' : 'installed-awaiting-consent', reason: 'BlueMapの設定ファイルはPaper起動後に生成されます。' };
  const writeHocon = (file, key, value) => {
    const original = fs.readFileSync(file, 'utf8');
    const pattern = new RegExp(`^(\\s*${key}\\s*[:=]\\s*).*$`, 'm');
    const next = pattern.test(original) ? original.replace(pattern, `$1${value}`) : `${original.trimEnd()}\n${key}: ${value}\n`;
    if (next !== original) fs.writeFileSync(file, next, 'utf8');
  };
  writeHocon(webserver, 'ip', '"127.0.0.1"');
  writeHocon(webserver, 'port', '8100');
  if (blueMap.acceptDownload) writeHocon(core, 'accept-download', 'true');
  const stateFile = path.join(serverDir, '.griefguard', 'bluemap.json');
  const state = readJsonObject(stateFile) || {};
  const status = blueMap.acceptDownload ? 'configured-awaiting-render' : 'configured-awaiting-consent';
  writeSetupState(stateFile, { ...state, managed: true, acceptDownload: Boolean(blueMap.acceptDownload), host: '127.0.0.1', port: 8100, status, configuredAt: new Date().toISOString() });
  return { configured: true, status, core, webserver, port: 8100, accepted: Boolean(blueMap.acceptDownload) };
}
function refreshBlueMapWebAppIfRequired(serverDir) {
  const stateFile = path.join(serverDir, '.griefguard', 'bluemap.json');
  const state = readJsonObject(stateFile) || {};
  if (!state.webAppRefreshRequired) return { skipped: true };
  const pluginDirectory = path.join(serverDir, 'plugins', 'BlueMap');
  const safeRead = file => { try { return fs.readFileSync(file, 'utf8'); } catch (_) { return ''; } };
  const webserver = safeRead(path.join(pluginDirectory, 'webserver.conf'));
  const webapp = safeRead(path.join(pluginDirectory, 'webapp.conf'));
  const value = (text, key) => {
    const match = String(text).match(new RegExp(`^\\s*${key}\\s*[:=]\\s*"?([^"\\s#]+)"?`, 'm'));
    return match ? match[1] : '';
  };
  const webrootValue = value(webserver, 'webroot') || value(webapp, 'webroot') || 'bluemap/web';
  // BlueMap evaluates a relative webroot from the Paper server root. Using
  // pluginDirectory here silently skipped the real web application during a
  // repair, leaving the browser with an incompatible/stale bundle.
  const webroot = path.isAbsolute(webrootValue) ? webrootValue : path.resolve(serverDir, webrootValue);
  const index = path.join(webroot, 'index.html');
  const backups = path.join(serverDir, '.griefguard', 'bluemap-webapp-backups');
  let backup = null;
  if (exists(index)) {
    fs.mkdirSync(backups, { recursive: true, mode: 0o700 });
    backup = path.join(backups, `index.html.before-bluemap-${Date.now()}.bak`);
    fs.copyFileSync(index, backup);
    fs.unlinkSync(index);
  }
  writeSetupState(stateFile, {
    ...state,
    webAppRefreshRequired: false,
    webAppRefreshRequestedAt: new Date().toISOString(),
    webAppEntryBackup: backup,
    status: 'webapp-refresh-pending-start'
  });
  return { refreshed: true, webroot, index, backup };
}
function blueMapEulaAccepted(serverDir) {
  try { return /^eula\s*=\s*true\s*$/im.test(fs.readFileSync(path.join(serverDir, 'eula.txt'), 'utf8')); }
  catch (_) { return false; }
}
async function waitForBlueMapWebServer(log, port = 8100, timeoutMs = 120000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const state = readPaperLogState(log);
    if (state.fatal) return { ready: false, reason: state.fatal };
    const blueMapStarted = /\[BlueMap\].*WebServer started\.|WebServer bound to:/i.test(state.text);
    if (blueMapStarted && await isPortListening(port)) return { ready: true };
    await delay(500);
  }
  return { ready: false, reason: `BlueMap WebServer (${port}) の起動を${Math.round(timeoutMs / 1000)}秒以内に確認できませんでした。` };
}
// A BlueMap JAR alone is not a completed map setup: its configuration exists
// only after Paper loads it once. This helper performs that first run, applies
// the local-only web configuration, then verifies it on a second run.
async function completeBlueMapSetup(serverDir, workspace, port, blueMap, options = {}) {
  if (!blueMap?.enabled) return { state: 'skipped', verified: false };
  const logDirectory = path.join(workspace, 'installer-log');
  if (options.paperRunning) return { state: 'restart-required', verified: false, reason: '起動中PaperではBlueMapの設定・WebAppを変更しません。Paperを停止してからRepair-BlueMapを再実行してください。' };
  let configuration = configureBlueMapConfig(serverDir, blueMap);
  let generatedConfig = null;
  if (!configuration.configured) {
    if (!blueMapEulaAccepted(serverDir)) return { state: 'eula-required', verified: false, configuration, reason: 'BlueMap設定を生成するには、先にMinecraft EULAへ同意してPaperを起動する必要があります。' };
    generatedConfig = await bootstrapNewPaper(serverDir, port, logDirectory, { paperVersion: options.paperVersion || '' });
    configuration = configureBlueMapConfig(serverDir, blueMap);
  }
  if (!configuration.configured) return { state: 'config-pending', verified: false, configuration, generatedConfig, reason: configuration.reason || 'BlueMap設定ファイルを生成できませんでした。' };
  const webAppRefresh = refreshBlueMapWebAppIfRequired(serverDir);
  // A BlueMap map id is stable even when Paper's world or its texture atlas
  // changes. Reusing its old model tiles would show a different world or
  // completely wrong block textures after zooming. Move only generated map
  // data aside (never Minecraft's world data) before a clean render.
  const renderArchive = archiveProblemBlueMapMaps(serverDir, { force: options.forceBlueMapRenderReset === true });
  if (renderArchive.moved.length) ok(`BlueMap旧描画を退避: ${renderArchive.moved.map(item => item.id).join(', ')}`);
  const verification = await bootstrapNewPaper(serverDir, port, logDirectory, {
    paperVersion: options.paperVersion || '',
    waitForBlueMap: true,
    blueMapPort: Number(configuration.port || 8100),
    seedBlueMapRender: true,
    blueMapRenderRadius: 256,
    blueMapRenderTimeoutMs: Number(options.blueMapRenderTimeoutMs || 300000)
  });
  if (!verification.blueMapReady) return { state: 'verification-failed', verified: false, configuration, generatedConfig, verification, reason: verification.blueMapReason || 'BlueMap Webサーバーを確認できませんでした。' };
  if (!verification.blueMapRender?.ready) {
    return {
      state: 'rendering-pending', verified: false, configuration, generatedConfig, verification, renderArchive,
      reason: `BlueMapの全ワールド描画を確認できませんでした${verification.blueMapRender.pending?.length ? `（未完了: ${verification.blueMapRender.pending.join(', ')}）` : ''}。Paperを通常起動して描画を続行するか、Repair-BlueMapを再実行してください。`
    };
  }
  const stateFile = path.join(serverDir, '.griefguard', 'bluemap.json');
  const index = webAppRefresh.index;
  if (webAppRefresh.refreshed && !exists(index)) return { state: 'webapp-regeneration-failed', verified: false, configuration, generatedConfig, verification, webAppRefresh, reason: 'BlueMap WebAppのindex.htmlが再生成されませんでした。バックアップを保持して停止しました。' };
  writeSetupState(stateFile, {
    ...(readJsonObject(stateFile) || {}), managed: true, acceptDownload: Boolean(blueMap.acceptDownload),
    host: '127.0.0.1', port: Number(configuration.port || 8100), status: 'ready-verified',
    verifiedAt: new Date().toISOString(), renderGeneration: crypto.randomBytes(12).toString('hex'),
    resourceFingerprint: blueMapResourceFingerprint(serverDir),
    webAppRefreshedAt: webAppRefresh.refreshed ? new Date().toISOString() : undefined
  });
  return { state: 'ready-verified', verified: true, configuration, generatedConfig, verification, webAppRefresh, renderArchive };
}
function installerBootstrap(agentData) {
  const file = path.join(agentData, 'installer-bootstrap.json');
  const token = crypto.randomBytes(32).toString('base64url');
  writePrivateJson(file, { token, createdAt: new Date().toISOString(), expiresAt: Date.now() + 30 * 60 * 1000 });
  return { file, token };
}
function isGriefGuardHealth(health) { return Boolean(health && health.product === 'GriefGuard Mobile Manager' && health.agent === 'online'); }
function agentDataId(agentData) {
  // This is only an ownership fingerprint. It prevents the installer from
  // mistaking another local GriefGuard workspace for the selected one without
  // exposing the actual AgentData path through /api/health.
  return crypto.createHash('sha256').update(path.resolve(agentData)).digest('hex').slice(0, 24);
}
async function agentHealth(port = 3000, timeoutMs = 20000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1200) });
      if (response.ok) return response.json();
    } catch (_) {}
    await delay(400);
  }
  return null;
}
async function waitForAgentOffline(port = 3000, timeoutMs = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (!await agentHealth(port, 800)) return true;
    await delay(250);
  }
  return false;
}
async function requestLocalAgentControl(agentData, action, expectedHealth = null) {
  const routes = {
    stop: '/api/local-control/stop',
    'setup-code': '/api/local-control/setup-code'
  };
  if (!routes[action]) throw new Error(`未対応のAgent制御操作です: ${action}`);
  const runtimeFile = path.join(agentData, 'runtime-instance.json');
  const tokenFile = path.join(agentData, 'agent-control-token');
  if (!exists(runtimeFile) || !exists(tokenFile)) return { ok: false, reason: 'AgentDataに現在のAgent制御情報がありません。' };
  const runtime = readJsonObject(runtimeFile);
  const token = fs.readFileSync(tokenFile, 'utf8').trim();
  if (!runtime || runtime.product !== 'GriefGuard Mobile Manager' || !/^[0-9a-f-]{36}$/i.test(String(runtime.instanceId || '')) || !Number.isInteger(Number(runtime.port)) || token.length < 40) {
    return { ok: false, reason: 'AgentDataの制御情報が不正です。' };
  }
  if (expectedHealth && (runtime.instanceId !== expectedHealth.instanceId || Number(runtime.port) !== Number(expectedHealth.port))) {
    return { ok: false, reason: 'Agentの起動情報が更新されたため、安全のため操作を中止しました。' };
  }
  try {
    const response = await fetch(`http://127.0.0.1:${runtime.port}${routes[action]}`, {
      method: 'POST',
      headers: {
        'X-GriefGuard-Agent-Control': token,
        'X-GriefGuard-Agent-Instance': runtime.instanceId,
        'Content-Length': '0'
      },
      signal: AbortSignal.timeout(2500)
    });
    const body = await response.json().catch(() => ({}));
    return response.ok ? { ok: true, ...body } : { ok: false, reason: body.error || `Agentが操作を拒否しました (${response.status})` };
  } catch (error) {
    return { ok: false, reason: `Agent制御に失敗しました: ${error.message}` };
  }
}
function unloadMacLaunchAgent() {
  if (process.platform !== 'darwin') return false;
  const file = path.join(os.homedir(), 'Library', 'LaunchAgents', 'jp.griefguard.mobile-manager.plist');
  if (!exists(file)) return false;
  spawnSync('launchctl', ['bootout', `gui/${process.getuid()}`, file], { stdio: 'ignore' });
  return true;
}
function agentLogDirectory(workspace) {
  const directory = path.join(workspace, 'agent-log');
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  return directory;
}
async function startAgentBackground(workspace, agentData, bootstrap, options = {}) {
  const port = Number(options.port || 3000);
  const active = await agentHealth(port, 1200);
  if (isGriefGuardHealth(active)) { ok('有効なGriefGuard Agentを検出し、そのまま使用します。'); return { reused: true, health: active, log: null }; }
  if (active) fail(`ポート ${port} は別のアプリケーションが使用しています。GriefGuard Agentのポートを変更するか、使用中のアプリを停止してください。`);
  const log = path.join(agentLogDirectory(workspace), 'agent-startup.log');
  const logFd = fs.openSync(log, 'a');
  const entry = path.join(agentRoot, 'server.js');
  const child = spawn(process.execPath, [entry], {
    cwd: agentRoot,
    detached: true,
    windowsHide: true,
    stdio: ['ignore', logFd, logFd],
    env: { ...process.env, GRIEFGUARD_AGENT_DATA_DIR: agentData, GRIEFGUARD_INSTALLER_BOOTSTRAP_FILE: bootstrap.file, GRIEFGUARD_PORT: String(port), ...(options.testLabSession ? { GRIEFGUARD_TESTLAB_SESSION_ID: options.testLabSession, GRIEFGUARD_TESTLAB_CLEANUP_TOKEN: options.testLabToken } : {}) },
  });
  child.unref();
  fs.closeSync(logFd);
  const health = await agentHealth(port);
  if (!health) fail(`Agentを起動できませんでした。ログを確認してください: ${log}`);
  ok(`Agentをバックグラウンドで起動: PID ${child.pid}`);
  return { reused: false, pid: child.pid, health, log };
}
function openBrowser(url) {
  try {
    if (process.platform === 'win32') spawn('cmd.exe', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    else if (process.platform === 'darwin') spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
    else spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
    return true;
  } catch (_) { return false; }
}
function createMacLaunchAgent(workspace, agentData, bootstrapFile = '', port = 3000) {
  const directory = path.join(os.homedir(), 'Library', 'LaunchAgents');
  const file = path.join(directory, 'jp.griefguard.mobile-manager.plist');
  const logDirectory = agentLogDirectory(workspace);
  const escaped = value => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const bootstrap = bootstrapFile ? `<key>GRIEFGUARD_INSTALLER_BOOTSTRAP_FILE</key><string>${escaped(bootstrapFile)}</string>` : '';
  const plist = `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n<key>Label</key><string>jp.griefguard.mobile-manager</string>\n<key>ProgramArguments</key><array><string>${escaped(process.execPath)}</string><string>${escaped(path.join(agentRoot, 'server.js'))}</string></array>\n<key>WorkingDirectory</key><string>${escaped(agentRoot)}</string>\n<key>EnvironmentVariables</key><dict><key>GRIEFGUARD_AGENT_DATA_DIR</key><string>${escaped(agentData)}</string><key>GRIEFGUARD_PORT</key><string>${port}</string>${bootstrap}</dict>\n<key>RunAtLoad</key><true/>\n<key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>\n<key>ThrottleInterval</key><integer>30</integer>\n<key>StandardOutPath</key><string>${escaped(path.join(logDirectory, 'agent.log'))}</string>\n<key>StandardErrorPath</key><string>${escaped(path.join(logDirectory, 'agent-error.log'))}</string>\n</dict></plist>\n`;
  fs.mkdirSync(directory, { recursive: true });
  fs.writeFileSync(file, plist, { encoding: 'utf8', mode: 0o600 });
  const domain = `gui/${process.getuid()}`;
  spawnSync('launchctl', ['bootout', domain, file], { stdio: 'ignore' });
  const result = spawnSync('launchctl', ['bootstrap', domain, file], { encoding: 'utf8' });
  if (result.status !== 0) fail(`macOSのAgent自動起動を登録できませんでした: ${(result.stderr || '').trim()}`);
  return { type: 'launchagent', file, label: 'jp.griefguard.mobile-manager' };
}
function createWindowsScheduledTask(workspace, agentData, bootstrapFile = '', port = 3000) {
  const script = path.join(workspace, 'Start-GriefGuard-Agent-hidden.ps1');
  const logDirectory = agentLogDirectory(workspace);
  const bootstrap = bootstrapFile ? `$env:GRIEFGUARD_INSTALLER_BOOTSTRAP_FILE = '${String(bootstrapFile).replace(/'/g, "''")}'\n` : '';
  const ps = `$ErrorActionPreference = 'Stop'\n$env:GRIEFGUARD_AGENT_DATA_DIR = '${String(agentData).replace(/'/g, "''")}'\n$env:GRIEFGUARD_PORT = '${port}'\n${bootstrap}Set-Location -LiteralPath '${String(agentRoot).replace(/'/g, "''")}'\n& '${String(process.execPath).replace(/'/g, "''")}' '${String(path.join(agentRoot, 'server.js')).replace(/'/g, "''")}' *>> '${String(path.join(logDirectory, 'agent.log')).replace(/'/g, "''")}'\n`;
  fs.writeFileSync(script, ps, { encoding: 'utf8' });
  const taskName = 'GriefGuard Mobile Manager';
  const command = `powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "${script}"`;
  const result = spawnSync('schtasks.exe', ['/Create', '/F', '/SC', 'ONLOGON', '/RL', 'LIMITED', '/TN', taskName, '/TR', command], { windowsHide: true });
  if (result.status === 0) return { type: 'scheduled-task', taskName, script };

  // Some Windows installations prohibit creating logon tasks for a standard
  // user, or contain an older task owned by another account. HKCU Run provides
  // the same per-user logon behaviour and does not require administrator rights.
  const taskError = decodeWindowsCommandOutput(result) || `終了コード ${result.status ?? '不明'}`;
  const registryKey = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
  const valueName = 'GriefGuard Mobile Manager';
  const registry = spawnSync('reg.exe', ['ADD', registryKey, '/V', valueName, '/T', 'REG_SZ', '/D', command, '/F'], { windowsHide: true });
  if (registry.status !== 0) {
    const registryError = decodeWindowsCommandOutput(registry) || `終了コード ${registry.status ?? '不明'}`;
    fail(`WindowsのAgent自動起動を登録できませんでした。タスクスケジューラー: ${taskError} / ユーザー自動起動: ${registryError}`);
  }
  warn(`タスクスケジューラーを使用できないため、Windowsユーザーのログイン時自動起動へ切り替えました。詳細: ${taskError}`);
  return { type: 'registry-run', registryKey, valueName, script, scheduledTaskError: taskError };
}

function decodeWindowsCommandOutput(result) {
  const value = result?.stderr?.length ? result.stderr : result?.stdout;
  if (!value || !value.length) return '';
  const buffer = Buffer.isBuffer(value) ? value : Buffer.from(String(value));
  try { return new TextDecoder('shift_jis').decode(buffer).trim(); }
  catch (_) { return buffer.toString('utf8').trim(); }
}
function registerAgentAutostart(workspace, agentData, bootstrapFile = '', enabled = true, port = 3000) {
  if (!enabled) return { type: 'skipped' };
  if (process.platform === 'win32') return createWindowsScheduledTask(workspace, agentData, bootstrapFile, port);
  if (process.platform === 'darwin') return createMacLaunchAgent(workspace, agentData, bootstrapFile, port);
  warn('このOSではAgentの常駐登録を省略しました。Linux/VPSではsystemdを使用してください。');
  return { type: 'manual' };
}
async function readInstallerSetupCode(token, port = 3000) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/install/bootstrap`, { headers: { 'X-GriefGuard-Installer-Token': token }, signal: AbortSignal.timeout(2000) });
    if (!response.ok) return null;
    return response.json();
  } catch (_) { return null; }
}
async function updateRunningAgentAccess(token, dnsName, port = 3000) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/install/access`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-GriefGuard-Installer-Token': token },
      body: JSON.stringify({ tailscaleDnsName: dnsName }), signal: AbortSignal.timeout(2500)
    });
    return response.ok;
  } catch (_) { return false; }
}
async function waitForFile(file, timeoutMs = 120000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (exists(file)) return true;
    await delay(500);
  }
  return false;
}
function readPaperLogState(log) {
  let text = '';
  try { text = fs.readFileSync(log, 'utf8'); } catch (_) {}
  const ready = /Done \([^\n]+\)! For help, type "help"/i.test(text);
  const stopping = /\bStopping server\b/i.test(text);
  const stopped = /\bAll dimensions are saved\b/i.test(text) && /\bStopping server\b/i.test(text);
  const stopCommandError = /Command exception:\s*\/?stop\b/i.test(text);
  const fatalMatch = text.match(/(?:You need to agree to the EULA|Failed to bind to port|session\.lock: already locked|UnsupportedClassVersionError|Failed to start the minecraft server|Failed to load datapacks|No key dimensions|No key seed)/i);
  return { text, ready, stopping, stopped, stopCommandError, fatal: fatalMatch ? fatalMatch[0] : '' };
}
function paperFirstRunMarkerFile(serverDir) { return path.join(serverDir, '.griefguard', 'paper-first-run.json'); }
function readWorldPaperVersion(serverDir) {
  const file = path.join(serverDir, 'world', 'level.dat');
  if (!exists(file)) return '';
  try {
    const decoded = zlib.gunzipSync(fs.readFileSync(file)).toString('latin1');
    // Paper writes its server version in level.dat. This is intentionally a
    // conservative check: unknown metadata never blocks setup.
    return decoded.match(/Paper\/([0-9]+(?:\.[0-9]+){1,2})/i)?.[1] || '';
  } catch (_) { return ''; }
}
function compareMinecraftVersions(left, right) {
  const a = String(left || '').split('.').map(Number);
  const b = String(right || '').split('.').map(Number);
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const delta = (a[index] || 0) - (b[index] || 0);
    if (delta) return delta;
  }
  return 0;
}
function assertWorldIsNotDowngraded(serverDir, paperVersion) {
  const worldVersion = readWorldPaperVersion(serverDir);
  if (worldVersion && paperVersion && compareMinecraftVersions(worldVersion, paperVersion) > 0) {
    fail(`既存ワールドはMinecraft ${worldVersion}で保存されていますが、選択したPaperは${paperVersion}です。ワールドのダウングレードは破損の原因になります。Paper ${worldVersion}以上を選ぶか、ワールドを別フォルダへ安全に退避してから新規生成してください。`);
  }
}
function hasCompletedPaperFirstRun(serverDir) {
  const latestLog = path.join(serverDir, 'logs', 'latest.log');
  const marker = readJsonObject(paperFirstRunMarkerFile(serverDir));
  if (marker?.status === 'completed') return true;
  try { return /Done \([^\n]+\)! For help, type "help"/i.test(fs.readFileSync(latestLog, 'utf8')); } catch (_) { return false; }
}
async function isPortListening(port) {
  return new Promise(resolve => {
    const net = require('net');
    const socket = net.createConnection({ host: '127.0.0.1', port });
    socket.setTimeout(700);
    socket.once('connect', () => { socket.destroy(); resolve(true); });
    socket.once('error', () => resolve(false));
    socket.once('timeout', () => { socket.destroy(); resolve(false); });
  });
}
function processCommand(pid) {
  if (!Number.isInteger(Number(pid)) || Number(pid) <= 0) return '';
  if (process.platform === 'win32') {
    const script = `(Get-CimInstance Win32_Process -Filter \"ProcessId=${Number(pid)}\").CommandLine`;
    const result = spawnSync('powershell.exe', ['-NoProfile', '-Command', script], { encoding: 'utf8', windowsHide: true });
    return String(result.stdout || '').trim();
  }
  return String(spawnSync('ps', ['-p', String(pid), '-o', 'command='], { encoding: 'utf8' }).stdout || '').trim();
}
function processWorkingDirectory(pid) {
  if (process.platform === 'win32') return '';
  const result = spawnSync('lsof', ['-a', '-p', String(pid), '-d', 'cwd', '-Fn'], { encoding: 'utf8' });
  const line = String(result.stdout || '').split(/\r?\n/).find(value => value.startsWith('n'));
  return line ? line.slice(1) : '';
}
function portListenerPid(port) {
  if (process.platform === 'win32') {
    const script = `(Get-NetTCPConnection -LocalPort ${Number(port)} -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)`;
    const result = spawnSync('powershell.exe', ['-NoProfile', '-Command', script], { encoding: 'utf8', windowsHide: true });
    const pid = Number(String(result.stdout || '').trim());
    return Number.isInteger(pid) && pid > 0 ? pid : 0;
  }
  const result = spawnSync('lsof', ['-nP', `-iTCP:${Number(port)}`, '-sTCP:LISTEN', '-Fp'], { encoding: 'utf8' });
  const line = String(result.stdout || '').split(/\r?\n/).find(value => /^p\d+$/.test(value));
  return line ? Number(line.slice(1)) : 0;
}
function inspectPortListener(port, serverDir) {
  const pid = portListenerPid(port);
  if (!pid) return null;
  const command = processCommand(pid);
  const cwd = processWorkingDirectory(pid);
  const expected = path.resolve(serverDir);
  const resolvedCwd = cwd ? path.resolve(cwd) : '';
  const isPaper = /(?:paper\.jar|paper-|--nogui|minecraft)/i.test(command) || Boolean(resolvedCwd && exists(path.join(resolvedCwd, 'paper.jar')));
  const matchesSelectedServer = Boolean(resolvedCwd && resolvedCwd === expected);
  const orphaned = /(?:^|[\\/])\.Trash(?:[\\/]|$)|\$Recycle\.Bin/i.test(resolvedCwd);
  return { pid, port: Number(port), command, cwd: resolvedCwd, isPaper, matchesSelectedServer, orphaned };
}
async function waitForPortRelease(port, timeoutMs = 60000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (!await isPortListening(port)) return true;
    await delay(500);
  }
  return !await isPortListening(port);
}
async function stopExistingPaper(listener, force = false) {
  if (!listener?.isPaper) return { stopped: false, reason: 'not-paper' };
  const pid = listener.pid;
  try {
    if (process.platform === 'win32') {
      // Without /F Windows asks the process to close before the optional force phase.
      spawnSync('taskkill.exe', ['/PID', String(pid), '/T'], { encoding: 'utf8', windowsHide: true });
    } else {
      process.kill(pid, 'SIGINT');
    }
  } catch (error) { return { stopped: false, reason: error.message }; }
  if (await waitForPortRelease(listener.port, 60000)) return { stopped: true, forced: false };
  if (!force) return { stopped: false, reason: 'graceful-timeout' };
  try {
    if (process.platform === 'win32') {
      spawnSync('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { encoding: 'utf8', windowsHide: true });
    } else {
      process.kill(pid, 'SIGTERM');
      if (!await waitForPortRelease(listener.port, 15000)) process.kill(pid, 'SIGKILL');
    }
  } catch (error) { return { stopped: false, reason: error.message, forced: true }; }
  return { stopped: await waitForPortRelease(listener.port, 10000), forced: true };
}
async function resolveRunningPaper(port, serverDir) {
  const listener = inspectPortListener(port, serverDir);
  if (!listener) return { active: false, action: 'none', listener: null };
  const location = listener.cwd || '作業フォルダを取得できませんでした';
  const identity = listener.orphaned ? 'ゴミ箱内の孤児Paper' : listener.matchesSelectedServer ? '選択したPaperサーバー' : listener.isPaper ? '別のPaperサーバー' : '別のアプリケーション';
  console.log(`\n[WARN] ${port}/TCP は使用中です。`);
  console.log(`  種別: ${identity}`);
  console.log(`  PID: ${listener.pid}`);
  console.log(`  起動場所: ${location}`);
  if (!listener.isPaper) fail(`${port}/TCP はPaperではないプロセスが使用しています。別のポートを選択するか、そのアプリを停止してください。`);
  const requested = String(argv.get('running-paper-action') || '').toLowerCase();
  const action = requested || (nonInteractive ? 'keep' : await choose('起動中のPaperをどうしますか？', [
    ['1', '安全に停止して続行（推奨）'],
    ['2', '強制停止して続行'],
    ['3', '起動したまま設定を続行'],
    ['4', 'インストーラーを終了']
  ], listener.matchesSelectedServer ? '3' : '1'));
  const normalized = action === '1' ? 'stop' : action === '2' ? 'force' : action === '3' ? 'keep' : action === '4' ? 'abort' : action;
  if (normalized === 'abort') fail('起動中Paperを変更せず、インストーラーを終了しました。');
  if (normalized === 'keep') {
    warn('起動中Paperを維持します。初回起動処理は省略し、Plugin設定は次回のPaper再起動後に反映されます。');
    return { active: true, action: 'keep', listener };
  }
  if (!['stop', 'force'].includes(normalized)) fail('running-paper-action は stop / force / keep / abort のいずれかを指定してください。');
  const result = await stopExistingPaper(listener, normalized === 'force');
  if (!result.stopped) fail(`起動中Paperを停止できませんでした（${result.reason || 'ポートが解放されません'}）。安全のため設定を中止しました。`);
  ok(`起動中Paperを${result.forced ? '強制停止' : '安全に停止'}しました。${port}/TCPの解放を確認しました。`);
  return { active: false, action: normalized, listener, stop: result };
}
async function waitForChildExit(exitState, timeoutMs, onProgress = null) {
  const started = Date.now();
  let nextProgress = 60000;
  while (!exitState.value && Date.now() - started < timeoutMs) {
    const elapsed = Date.now() - started;
    if (onProgress && elapsed >= nextProgress) {
      onProgress(Math.floor(elapsed / 1000));
      nextProgress += 60000;
    }
    await delay(500);
  }
  return exitState.value;
}
function requestPaperTermination(child) {
  if (!child || child.exitCode !== null) return false;
  try {
    // SIGINT asks the JVM to run its shutdown hook. It is a safer fallback
    // than killing a Paper process while it may still be saving worlds.
    if (process.platform !== 'win32') return child.kill('SIGINT');
    return child.kill();
  } catch (_) { return false; }
}
function paperRuntimeRecordFile(serverDir) { return path.join(serverDir, '.griefguard', 'paper-runtime.json'); }
function writePaperRuntimeRecord(serverDir, value) {
  const file = paperRuntimeRecordFile(serverDir);
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, JSON.stringify({ managedBy: 'GriefGuard Installer', ...value, updatedAt: new Date().toISOString() }, null, 2) + '\n', { mode: 0o600 });
  return file;
}
async function bootstrapNewPaper(serverDir, port, logDirectory, options = {}) {
  const requirePort = options.requirePort !== false;
  const stabilizationMs = Number.isFinite(options.stabilizationMs) ? options.stabilizationMs : 4000;
  const script = path.join(serverDir, process.platform === 'win32' ? 'start.bat' : 'start.command');
  const log = path.join(logDirectory, 'paper-first-start.log');
  assertWorldIsNotDowngraded(serverDir, options.paperVersion || '');
  if (!exists(script)) fail(`Paper起動ファイルが見つかりません: ${script}`);
  // The installer may be resumed after its terminal was closed while Paper
  // kept running. Do not start a second JVM in that case (the launcher would
  // otherwise return exit code 12 for the occupied port).
  if (requirePort && await isPortListening(port)) {
    warn(`Paperは既にポート ${port} で起動中です。二重起動をスキップします。`);
    return { alreadyRunning: true, log };
  }
  fs.mkdirSync(logDirectory, { recursive: true, mode: 0o700 });
  const logFd = fs.openSync(log, 'w');
  const child = process.platform === 'win32'
    ? spawn('cmd.exe', ['/c', script], { cwd: serverDir, windowsHide: true, stdio: ['pipe', logFd, logFd] })
    : spawn('/bin/sh', [script], { cwd: serverDir, stdio: ['pipe', logFd, logFd] });
  fs.closeSync(logFd);
  const exitState = { value: null };
  const runtimeFile = writePaperRuntimeRecord(serverDir, { pid: child.pid, port, serverDirectory: serverDir, status: 'starting', startedAt: new Date().toISOString() });
  activePaperBootstrap = { child, serverDir, runtimeFile };
  child.once('exit', (code, signal) => {
    exitState.value = { code, signal, at: new Date().toISOString() };
    writePaperRuntimeRecord(serverDir, { pid: child.pid, port, serverDirectory: serverDir, status: 'stopped', exit: exitState.value, startedAt: new Date().toISOString() });
    activePaperBootstrap = null;
  });
  child.once('error', error => { exitState.value = { code: null, signal: null, error: error.message, at: new Date().toISOString() }; });
  ok(`Paper初回起動を開始: PID ${child.pid}`);

  const startupStarted = Date.now();
  let ready = false;
  while (Date.now() - startupStarted < 180000) {
    const state = readPaperLogState(log);
    if (state.fatal) {
      requestPaperTermination(child);
      await waitForChildExit(exitState, 30000);
      fail(`Paperの初回起動に失敗しました: ${state.fatal}\nログを確認してください: ${log}`);
    }
    if (exitState.value) fail(`Paperが起動完了前に終了しました（終了コード: ${exitState.value.code ?? 'なし'} / シグナル: ${exitState.value.signal ?? 'なし'}）。ログを確認してください: ${log}`);
    if (state.ready && (!requirePort || await isPortListening(port))) { ready = true; break; }
    await delay(500);
  }
  if (!ready) {
    requestPaperTermination(child);
    await waitForChildExit(exitState, 30000);
    fail(`Paperの起動完了ログ（Done ... For help）が180秒以内に確認できませんでした。ログを確認してください: ${log}`);
  }
  ok('Paperの起動完了ログと待受ポートを確認しました。安定化を待機します。');
  writePaperRuntimeRecord(serverDir, { pid: child.pid, port, serverDirectory: serverDir, status: 'running', startedAt: new Date().toISOString() });
  await delay(stabilizationMs);
  if (exitState.value) fail(`Paperが起動直後に終了しました（終了コード: ${exitState.value.code ?? 'なし'}）。ログを確認してください: ${log}`);

  let blueMapReady = true;
  let blueMapReason = '';
  let blueMapRender = null;
  if (options.waitForBlueMap) {
    const result = await waitForBlueMapWebServer(log, Number(options.blueMapPort || 8100));
    blueMapReady = result.ready;
    blueMapReason = result.reason || '';
    if (blueMapReady) ok(`BlueMap Webサーバー (${Number(options.blueMapPort || 8100)}) の起動を確認しました。`);
    else warn(`BlueMap Webサーバーを確認できませんでした。${blueMapReason}`);
    if (blueMapReady && options.seedBlueMapRender !== false) {
      const requested = requestBlueMapSeedRender(child, serverDir, Number(options.blueMapRenderRadius || 256));
      if (requested.commands.length) {
        ok(`BlueMap初回描画を要求しました: ${requested.commands.join(' / ')}`);
        blueMapRender = await waitForBlueMapRenderable(serverDir, Number(options.blueMapRenderTimeoutMs || 120000));
        if (blueMapRender.ready) ok(`BlueMapの地形タイル生成を確認しました（${Math.ceil(blueMapRender.elapsedMs / 1000)}秒）。`);
        else warn('BlueMapはWebサーバーを開始しましたが、表示可能な地形タイルを確認できませんでした。Paper停止後も描画タスクは保存されます。');
      } else {
        blueMapRender = { ready: false, reason: 'BlueMapのmap設定が見つかりません。' };
        warn(blueMapRender.reason);
      }
    }
  }

  try { child.stdin.write('stop\n'); } catch (_) { requestPaperTermination(child); }
  ok('Paperへ正常停止コマンドを送信しました。ワールド保存の完了を待機します。');
  let stopFallbackSent = false;
  const stopStarted = Date.now();
  while (Date.now() - stopStarted < 180000 && !exitState.value) {
    const state = readPaperLogState(log);
    if (!stopFallbackSent && (state.stopCommandError || Date.now() - stopStarted >= 20000) && !state.stopping) {
      warn('Paperのstopコマンド処理を確認できないため、安全な終了シグナルへ切り替えます。');
      requestPaperTermination(child);
      stopFallbackSent = true;
    }
    const elapsed = Date.now() - stopStarted;
    if (elapsed >= 60000 && elapsed < 60500) console.log('[INFO] Paperがワールドを保存しています。初回停止は数分かかる場合があります。');
    if (elapsed >= 120000 && elapsed < 120500) console.log('[INFO] Paperの停止処理を継続して待機しています。強制終了は行いません。');
    await delay(500);
  }
  if (!exitState.value) {
    // One final graceful termination request; do not use SIGKILL because that
    // risks corrupting freshly generated worlds.
    requestPaperTermination(child);
    await waitForChildExit(exitState, 30000);
  }
  if (!exitState.value) fail(`Paperの停止完了を確認できませんでした。プロセスは強制終了していません。ログを確認してください: ${log}`);
  const finalState = readPaperLogState(log);
  if (!finalState.stopping && !stopFallbackSent) warn('Paperの停止ログを確認できませんでしたが、プロセス終了は確認しました。');
  fs.mkdirSync(path.dirname(paperFirstRunMarkerFile(serverDir)), { recursive: true, mode: 0o700 });
  fs.writeFileSync(paperFirstRunMarkerFile(serverDir), JSON.stringify({ status: 'completed', paperVersion: options.paperVersion || '', completedAt: new Date().toISOString(), log }, null, 2) + '\n', { mode: 0o600 });
  ok('Paperの初回起動と正常停止を完了しました。');
  return { log, pid: child.pid, exit: exitState.value, stopFallbackSent, blueMapReady, blueMapReason, blueMapRender };
}
function updateYamlScalar(content, key, value) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`^(\\s*)${escaped}:.*$`, 'm');
  const replacement = `$1${key}: ${value}`;
  return pattern.test(content) ? content.replace(pattern, replacement) : content;
}
function synchronizePluginBridge(serverDir, bridgePort = 25501) {
  const file = path.join(serverDir, 'plugins', 'GriefGuard', 'config.yml');
  if (!exists(file)) return { synchronized: false, reason: 'config.ymlはPaper初回起動後に生成されます。' };
  let content = fs.readFileSync(file, 'utf8');
  content = updateYamlScalar(content, 'bridge-mode', 'true');
  content = updateYamlScalar(content, 'vps-ip', '"127.0.0.1"');
  content = updateYamlScalar(content, 'bridge-port', String(bridgePort));
  fs.writeFileSync(file, content, 'utf8');
  return { synchronized: true, file };
}
function installGriefGuardPlugin(serverDir, sourcePlugin) {
  if (!sourcePlugin || !exists(sourcePlugin)) fail(`配布物内にGriefGuard.jarが見つかりません: ${sourcePlugin || '未指定'}`);
  const plugins = path.join(serverDir, 'plugins');
  fs.mkdirSync(plugins, { recursive: true });
  const targetPlugin = path.join(plugins, 'GriefGuard.jar');
  let backup = '';
  if (exists(targetPlugin)) {
    backup = `${targetPlugin}.installer-backup-${timestamp()}`;
    fs.copyFileSync(targetPlugin, backup);
    warn(`既存GriefGuard.jarをバックアップしました: ${backup}`);
  }
  fs.copyFileSync(sourcePlugin, targetPlugin);
  return { targetPlugin, backup };
}
function configureGeyserConfig(serverDir, connection) {
  if (connection.mode !== 'java-bedrock') return { configured: false, reason: 'java-only' };
  const candidates = [path.join(serverDir, 'plugins', 'Geyser-Spigot', 'config.yml'), path.join(serverDir, 'plugins', 'Geyser', 'config.yml')];
  const file = candidates.find(exists);
  if (!file) return { configured: false, reason: 'Geyserのconfig.ymlはPaperがGeyserを一度有効化した後に生成されます。' };
  const original = fs.readFileSync(file, 'utf8');
  let content = original;
  const nestedPort = /^(\s*bedrock:\s*\n)((?:\s{2,}.*\n?)*)/m;
  if (nestedPort.test(content)) {
    content = content.replace(nestedPort, (all, header, fields) => {
      const portPattern = /^([ \t]+)port:\s*.*$/m;
      return header + (portPattern.test(fields)
        ? fields.replace(portPattern, `$1port: ${connection.bedrockPort}`)
        : `  port: ${connection.bedrockPort}\n${fields}`);
    });
  }
  content = updateYamlScalar(content, 'auth-type', 'floodgate');
  if (content !== original) {
    backup(file);
    fs.writeFileSync(file, content, 'utf8');
    return { configured: true, file };
  }
  return { configured: true, file, unchanged: true };
}
function writeAccessRecord(serverDir, workspace, details = {}) {
  const parent = path.dirname(serverDir);
  const configured = Boolean(details.url);
  const status = details.status || (configured ? 'configured' : 'pending');
  const localUrl = `http://localhost:${details.agentPort || 3000}`;
  const mapLocalUrl = `${localUrl.replace(/\/$/, '')}/map/`;
  const mapTailscaleUrl = details.url ? `${String(details.url).replace(/\/$/, '')}/map/` : '未作成';
  const blueMap = details.blueMap || {};
  const blueMapState = blueMap.verified ? '導入・設定・Webサーバー起動確認済み（Paper停止中はサーバー起動後に表示）' : blueMap.reason || '未確認';
  const text = [
    'GriefGuard 接続情報',
    '',
    `状態: ${configured ? 'Tailscale HTTPS設定済み' : status === 'pending' ? 'Tailscale設定待ち' : `Tailscale設定未完了 (${status})`}`,
    `管理画面（ローカル）: ${localUrl}`,
    `管理画面（Tailscale HTTPS）: ${details.url || '未作成'}`,
    `BlueMap（ローカル）: ${mapLocalUrl}`,
    `BlueMap（Tailscale HTTPS）: ${mapTailscaleUrl}`,
    `BlueMap状態: ${blueMapState}`,
    `BlueMap修復: ${details.blueMapRepair || path.join(workspace, process.platform === 'win32' ? 'Repair-BlueMap.bat' : 'Repair-BlueMap.command')}`,
    `Minecraftサーバー: ${serverDir}`,
    `管理ワークスペース: ${workspace}`,
    `更新日時: ${new Date().toLocaleString('ja-JP')}`,
    '',
    'このファイルに管理パスワード、セットアップコード、Agent制御トークン、Discordトークンは保存されません。',
    configured ? 'スマートフォン・PCを同じTailscaleネットワークへログインしてからHTTPS URLを開いてください。' : `Tailscale設定を再開するには: ${path.join(workspace, process.platform === 'win32' ? 'Continue-Tailscale-Setup.bat' : 'Continue-Tailscale-Setup.command')}`
  ].join('\n') + '\n';
  const textFile = path.join(parent, 'GriefGuard-Access.txt');
  const jsonFile = path.join(workspace, 'connection-info.json');
  fs.writeFileSync(textFile, text, { encoding: 'utf8', mode: 0o600 });
  writeSetupState(jsonFile, { version: 1, status, localUrl, tailscaleUrl: details.url || '', serverDirectory: serverDir, workspace, updatedAt: new Date().toISOString() });
  try { fs.chmodSync(textFile, 0o600); } catch (_) {}
  return { textFile, jsonFile };
}
function configuredTailscaleUrl(config) {
  const dnsName = String(config?.access?.tailscaleDnsName || '').trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
  return dnsName ? `${config?.access?.https === false ? 'http' : 'https'}://${dnsName}` : '';
}
function tailscaleCommand() {
  const candidates = process.platform === 'darwin'
    ? ['tailscale', '/Applications/Tailscale.app/Contents/MacOS/Tailscale']
    : process.platform === 'win32' ? ['tailscale.exe', 'tailscale'] : ['tailscale'];
  for (const candidate of candidates) {
    const result = spawnSync(candidate, ['version'], { encoding: 'utf8', windowsHide: true });
    if (result.status === 0) return candidate;
  }
  return '';
}
async function configureTailscale(config, workspace, serverDir = config.serverDirectory) {
  const enabled = argv.get('tailscale') || (nonInteractive ? 'no' : await choose('Tailscale HTTPSを今すぐ設定しますか？', [['1', '設定する（推奨）'], ['2', 'ローカル利用のみ。後で設定する']], '1'));
  if (!['1', 'yes', 'true'].includes(String(enabled))) return { configured: false, reason: 'later' };
  let command = tailscaleCommand();
  if (!command) {
    warn('Tailscaleが見つかりません。公式ダウンロード画面を開きます。');
    openBrowser('https://tailscale.com/download');
    if (nonInteractive) return { configured: false, reason: 'not-installed' };
    const next = await choose('Tailscaleを導入後に行う操作', [['1', '導入・ログイン後、ここで再確認する'], ['2', '今は保留してセットアップを完了する']], '1');
    if (next !== '1') return { configured: false, reason: 'not-installed' };
    await ask('Tailscaleの導入とログインを完了したらEnterを押してください');
    command = tailscaleCommand();
    if (!command) return { configured: false, reason: 'not-installed' };
  }
  let status = spawnSync(command, ['status', '--json'], { encoding: 'utf8', windowsHide: true });
  let parsed;
  try { parsed = JSON.parse(status.stdout); } catch (_) { parsed = null; }
  if (!parsed?.Self?.Online) {
    warn('Tailscaleへログインしてください。ブラウザーまたはTailscaleアプリの画面が開きます。');
    spawn(command, ['login'], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    const started = Date.now();
    while (Date.now() - started < 300000) {
      await delay(1500); status = spawnSync(command, ['status', '--json'], { encoding: 'utf8', windowsHide: true });
      try { parsed = JSON.parse(status.stdout); } catch (_) { parsed = null; }
      if (parsed?.Self?.Online) break;
    }
  }
  if (!parsed?.Self?.Online) return { configured: false, reason: 'login-pending' };
  const served = spawnSync(command, ['serve', '--bg', '--yes', '3000'], { encoding: 'utf8', windowsHide: true });
  if (served.status !== 0) return { configured: false, reason: 'serve-failed', detail: (served.stderr || served.stdout || '').trim() };
  const dnsName = String(parsed.Self.DNSName || '').replace(/\.$/, '');
  if (!dnsName) return { configured: false, reason: 'dns-name-missing' };
  config.access = { tailscaleDnsName: dnsName, https: true };
  const url = `https://${dnsName}`;
  fs.writeFileSync(path.join(workspace, 'tailscale-access-url.txt'), `${url}\n`, { encoding: 'utf8', mode: 0o600 });
  writeAccessRecord(serverDir, workspace, { url, status: 'configured', agentPort: Number(argv.get('agent-port') || 3000) });
  return { configured: true, dnsName, url, command };
}
function persistTailscaleAccessConfig(configFile, dnsName) {
  // Reload immediately before writing. Password setup is performed by the
  // running Agent in another process, so an installer-held config object may
  // be older than the file on disk.
  const latestConfig = readJsonObject(configFile) || {};
  const mergedConfig = mergeSettings(latestConfig, {
    access: { tailscaleDnsName: dnsName, https: true }
  });
  const temporaryConfig = `${configFile}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  fs.writeFileSync(temporaryConfig, JSON.stringify(mergedConfig, null, 2) + '\n', { mode: 0o600 });
  try { fs.chmodSync(temporaryConfig, 0o600); } catch (_) {}
  fs.renameSync(temporaryConfig, configFile);
  return mergedConfig;
}
async function completeTailscaleSetup({ config, configFile, workspace, serverDir, agentData, agentPort, bootstrap, recoveredSetup, setupStateFile, tailscaleResume }) {
  const tailscale = argv.get('tailscale') === 'no' ? { configured: false, reason: 'skipped' } : await configureTailscale(config, workspace, serverDir);
  if (tailscale.configured) {
    // The Agent may have completed password setup while this installer was
    // waiting for Tailscale. Never write the older in-memory config back over
    // its auth settings: reload it and update the access fields only.
    config = persistTailscaleAccessConfig(configFile, tailscale.dnsName);
    writeSetupState(setupStateFile, { ...readJsonObject(setupStateFile), phase: 'tailscale-configured', tailscale: { status: 'configured', url: tailscale.url, updatedAt: new Date().toISOString() }, updatedAt: new Date().toISOString() });
    if (!recoveredSetup && !await updateRunningAgentAccess(bootstrap.token, tailscale.dnsName, agentPort)) warn('実行中AgentへのTailscale URL反映は次回再起動時に行われます。');
    ok(`Tailscale HTTPS URL: ${tailscale.url}`);
    console.log('スマートフォン・PCを同じTailscaleアカウントへログインしてから、上のURLを開いてください。');
  } else if (tailscale.reason === 'not-installed' || tailscale.reason === 'login-pending') {
    writeSetupState(setupStateFile, { ...readJsonObject(setupStateFile), phase: 'tailscale-pending', tailscale: { status: tailscale.reason, updatedAt: new Date().toISOString() }, updatedAt: new Date().toISOString() });
    warn(`Tailscale設定を再開するには、最初からやり直さず次のファイルを実行してください: ${tailscaleResume}`);
  } else {
    console.log('Tailscaleは後で設定できます。ローカル管理画面は利用可能です。');
  }
  if (!tailscale.configured) {
    const preservedUrl = configuredTailscaleUrl(config);
    writeAccessRecord(serverDir, workspace, preservedUrl
      ? { url: preservedUrl, status: 'configured', agentPort }
      : { status: tailscale.reason || 'pending', agentPort });
  }
  return tailscale;
}
async function configureLaunchers(serverDir, jar, min, max, port, javaExecutable, managedUpdater = null) {
  step(8, '起動ファイル診断');
  // Do not create an irrelevant launcher on the host OS. If an alternate
  // launcher already exists (for example, a server disk prepared on Windows
  // and moved to macOS), diagnose and preserve it, but only create the
  // platform-native default.
  const nativeKind = nativeLauncherKind();
  const removedOppositeLaunchers = removeGeneratedOppositeLaunchers(serverDir, nativeKind);
  removedOppositeLaunchers.forEach(file => ok(`不要な別OS用起動ファイルを削除: ${file}`));
  const candidates = [{ kind: 'bat', file: path.join(serverDir, 'start.bat') }, { kind: 'command', file: path.join(serverDir, 'start.command') }];
  const files = candidates.filter(item => item.kind === nativeKind || exists(item.file));
  const results = files.map(item => ({ ...item, ...diagnoseLauncher(item.file, item.kind) }));
  for (const result of results) {
    result.needsManagedPluginIntegration = Boolean(managedUpdater?.enabled && result.exists && !fs.readFileSync(result.file, 'utf8').includes('Managed-Plugin-Updater.js'));
    if (result.needsManagedPluginIntegration) result.issues.push({ message: 'GeyserMC・Floodgateの起動前自動更新が未設定', level: 'attention' });
  }
  for (const result of results) {
    if (!result.exists) console.log(`[INFO] ${path.basename(result.file)}: 作成されていません`);
    else if (result.level === 'compatible' && !result.needsManagedPluginIntegration) ok(`${path.basename(result.file)}: Agent運用に対応`);
    else { warn(`${path.basename(result.file)}: ${result.level === 'incompatible' ? '推奨設定への書き換えが必要です' : '確認を推奨します'}`); result.issues.forEach(issue => console.log(`  - ${issue.message}`)); }
  }
  const needsMigration = results.some(result => result.level === 'attention' || result.level === 'incompatible' || result.needsManagedPluginIntegration);
  const replaceSetting = argv.get('replace-launchers');
  const requiresManagedIntegration = results.some(result => result.needsManagedPluginIntegration);
  const migration = replaceSetting === 'yes' || replaceSetting === 'recommended' ? 'yes' : replaceSetting === 'no' ? 'no' : needsMigration ? (nonInteractive ? (requiresManagedIntegration ? 'yes' : 'no') : await choose(requiresManagedIntegration ? '統合版接続の自動更新を有効にするため、既存起動ファイルへ推奨設定を適用しますか？' : '既存起動ファイルにはAgent運用を妨げる可能性があります。推奨設定へ書き換えますか？', [['1', '推奨設定へ書き換える（元ファイルは日時付き.bakへ退避）'], ['2', '既存ファイルを保持する']], '1')) : 'no';
  const content = launcherContent(jar, min, max, port, javaExecutable, managedUpdater);
  step(9, '推奨起動ファイルの設定');
  for (const result of results) {
    const recommended = result.kind === 'bat' ? content.bat : content.command;
    const manual = result.kind === 'bat' ? content.manualBat : content.manualCommand;
    if (!result.exists) { fs.writeFileSync(result.file, recommended, 'utf8'); ok(`作成: ${result.file}`); }
    else if ((migration === '1' || migration === 'yes') && (result.level !== 'compatible' || result.needsManagedPluginIntegration)) { backup(result.file); fs.writeFileSync(result.file, recommended, 'utf8'); ok(`推奨設定へ書き換え: ${result.file}`); }
    else warn(`既存の起動ファイルを保持: ${result.file}`);
    const manualName = result.kind === 'bat' ? 'start-manual.bat' : 'start-manual.command';
    const manualFile = path.join(serverDir, manualName);
    if (!exists(manualFile)) { fs.writeFileSync(manualFile, manual, 'utf8'); ok(`手動確認用を作成: ${manualFile}`); }
    try { fs.chmodSync(result.file, 0o755); fs.chmodSync(manualFile, 0o755); } catch (_) {}
  }
  return migration === '1' || migration === 'yes';
}
async function resumeTailscaleSetup(stateFile) {
  const state = readJsonObject(stateFile);
  if (!state?.workspace || !state?.agentConfigFile || !exists(state.agentConfigFile)) fail(`再開情報が見つからないか壊れています: ${stateFile}`);
  const config = readJsonObject(state.agentConfigFile);
  if (!config) fail(`Agent設定を読み取れません: ${state.agentConfigFile}`);
  console.log('GriefGuard Tailscale設定を再開します。Paper・Plugin・メモリー設定は変更しません。');
  const result = await configureTailscale(config, state.workspace, state.serverDir || config.serverDirectory);
  if (result.configured) {
    persistTailscaleAccessConfig(state.agentConfigFile, result.dnsName);
    writeSetupState(stateFile, { ...state, phase: 'completed', tailscale: { status: 'configured', url: result.url, updatedAt: new Date().toISOString() } });
    ok(`Tailscale HTTPS URL: ${result.url}`);
    console.log('Agentが起動中の場合は、次回の自動再起動時にURL設定が反映されます。');
  } else {
    writeSetupState(stateFile, { ...state, phase: 'tailscale-pending', tailscale: { status: result.reason, updatedAt: new Date().toISOString() } });
    writeAccessRecord(state.serverDir || config.serverDirectory, state.workspace, { status: result.reason, agentPort: Number(argv.get('agent-port') || 3000) });
    warn('Tailscale設定は未完了です。Tailscale導入・ログイン後に、同じContinue-Tailscale-Setupファイルを実行してください。');
  }
}
async function resumePaperSetup(stateFile) {
  const state = readJsonObject(stateFile);
  if (!state?.serverDir || !state?.workspace) fail(`Paper再開情報が見つからないか壊れています: ${stateFile}`);
  const config = readJsonObject(state.agentConfigFile || path.join(state.workspace, 'AgentData', 'agent-config.json'));
  const port = Number(config?.local?.serverPort || state?.connection?.javaPort || 25565);
  if (!exists(path.join(state.serverDir, process.platform === 'win32' ? 'start.bat' : 'start.command'))) {
    fail(`Paper起動ファイルが見つかりません: ${state.serverDir}`);
  }
  const running = await resolveRunningPaper(port, state.serverDir);
  if (running.active) {
    writeSetupState(stateFile, { ...state, phase: 'paper-bootstrap-pending', runningPaper: running, updatedAt: new Date().toISOString() });
    warn('起動中Paperを維持したため、Paper初回起動は保留しました。');
    return;
  }
  fs.writeFileSync(path.join(state.serverDir, 'eula.txt'), 'eula=true\n');
  const logDirectory = path.join(state.workspace, 'installer-log');
  try {
    const bootstrap = await bootstrapNewPaper(state.serverDir, port, logDirectory, { paperVersion: state.paper?.version || '' });
    const pluginSync = synchronizePluginBridge(state.serverDir, Number(config?.bridge?.port || 25501));
    const highVersion = applyHighVersionSettings(state.serverDir, state.highVersionSettings || null);
    const geyserConfig = configureGeyserConfig(state.serverDir, state.connection || { mode: 'java' });
    writeSetupState(stateFile, { ...state, phase: 'completed', paperBootstrap: bootstrap, pluginSync, highVersion, geyserConfig, updatedAt: new Date().toISOString() });
    ok('Paper初回起動の再開処理を完了しました。');
  } catch (error) {
    writeSetupState(stateFile, { ...state, phase: 'paper-bootstrap-pending', paperBootstrap: { failed: true, reason: error.message }, updatedAt: new Date().toISOString() });
    fail(`Paper初回起動を完了できませんでした。${error.message}`);
  }
}
async function choosePaperServer() {
  step(2, 'Paperサーバーの準備');
  const mode = argv.get('mode') || await choose('Paperサーバーの準備方法', [['1', '既存Paperサーバーを使用（新規作成をスキップ）'], ['2', '新しいPaperサーバーを作成']], '1');
  if (mode === '1' || mode === 'existing') {
    const { serverDir, inspection } = await chooseExistingPaperServer();
    ok(`既存Paperサーバー: ${serverDir}`);
    return { serverDir, newServer: !inspection.initialized, version: argv.get('minecraft-version') || '' };
  }
  const { parent, serverDir } = await chooseNewPaperDirectory();
  const distributionRoot = path.resolve(agentRoot, '..');
  if (isInside(serverDir, distributionRoot)) fail('配布フォルダの中にはPaperサーバーを作成できません。Documents/GriefGuardServersなど、配布フォルダの外を指定してください。');
  if (exists(serverDir) && fs.readdirSync(serverDir).length) fail(`作成先フォルダが既に存在します: ${serverDir}`);
  fs.mkdirSync(serverDir, { recursive: true });
  ok(`新規Paperサーバー作成先: ${serverDir}`);
  step(3, 'Paperバージョン取得');
  let versions;
  try { versions = await stablePaperVersions(); } catch (error) { fail(`${error.message}\n既存Paperサーバーを選ぶか、ネットワークを確認して再試行してください。`); }
  const display = versions.slice(0, 15);
  if (!display.length) fail('公式APIで利用可能な安定版Paperビルドを取得できませんでした。ネットワークを確認して再試行してください。');
  console.log('公式で安定版と確認できた候補:'); display.forEach((build, index) => console.log(`  ${index + 1}. Minecraft ${build.version}（Paper build ${build.id}）`));
  const requested = argv.get('minecraft-version');
  let build;
  if (requested) {
    if (!/^\d+(?:\.\d+){1,2}$/.test(requested)) fail(`正式版ではないMinecraftバージョンは選べません: ${requested}`);
    build = await stableBuild(requested);
  } else {
    const choice = await choose('Minecraftバージョンを選択', display.map((candidate, index) => [String(index + 1), `Minecraft ${candidate.version}（Paper build ${candidate.id}）`]), '1');
    build = display[Number(choice) - 1] || display[0];
  }
  console.log(`選択: Paper ${build.version} build ${build.id}${build.size ? ` (${Math.round(build.size / 1024 / 1024)}MB)` : ''}`);
  await downloadPaper(build, path.join(serverDir, 'paper.jar'));
  return { serverDir, newServer: true, version: build.version };
}
async function chooseConnection(serverDir) {
  step(6, '接続方式とポート');
  const requested = argv.get('connection-mode');
  const selected = requested || await choose('接続するMinecraftエディション', [
    ['1', 'Java版のみ（Paperの標準構成）'],
    ['2', 'Java版＋統合版（GeyserMCを利用）'],
  ], '1');
  const mode = selected === '1' ? 'java' : selected === '2' ? 'java-bedrock' : selected;
  if (!['java', 'java-bedrock'].includes(mode)) fail('接続方式は java または java-bedrock を指定してください。');
  const javaPort = validatePort(argv.get('server-port') || await ask('Java版ポート（TCP / server.propertiesへ保存）', '25565'), 'Java版ポート');
  const connection = { mode, javaPort, bedrockPort: null, geyserDetected: false, floodgateDetected: false };
  writeServerPort(serverDir, javaPort);
  console.log(`Java版: ${javaPort}/TCP`);
  if (mode === 'java-bedrock') {
    const bedrockPort = validatePort(argv.get('bedrock-port') || await ask('統合版ポート（UDP / GeyserMC用）', '19132'), '統合版ポート');
    if (bedrockPort === javaPort) fail('Java版ポートと統合版ポートは同じ番号にできません。Java版は通常25565、統合版は通常19132です。');
    const geyser = findPluginByPrefix(serverDir, 'geyser');
    const floodgate = findPluginByPrefix(serverDir, 'floodgate');
    connection.bedrockPort = bedrockPort;
    connection.geyserDetected = Boolean(geyser);
    connection.floodgateDetected = Boolean(floodgate);
    console.log(`統合版: ${bedrockPort}/UDP（GeyserMC）`);
    if (geyser) ok(`GeyserMCを検出: ${geyser}`);
    else console.log('[INFO] GeyserMCは未導入です。次の工程で公式配布元から自動導入します。');
    if (floodgate) ok(`Floodgateを検出: ${floodgate}`);
    else console.log('[INFO] Floodgateは未導入です。次の工程で公式配布元から自動導入します。');
  }
  return connection;
}
async function repairBlueMapSetup(stateFile) {
  const state = readJsonObject(stateFile);
  if (!state?.serverDir || !state?.paper?.version) fail('BlueMap修復用のインストール情報が見つかりません。通常のインストーラーを既存Paperモードで実行してください。');
  const serverDir = path.resolve(state.serverDir);
  if (!exists(path.join(serverDir, 'server.properties'))) fail(`Paperサーバーフォルダーを確認できません: ${serverDir}`);
  const javaMajor = Number(state.java?.major || requiredJava(state.paper.version));
  step(1, 'BlueMap修復');
  const blueMap = await installBlueMap(serverDir, state.paper.version, { major: javaMajor });
  if (!blueMap.enabled) {
    warn('BlueMap導入をスキップしました。修復は行いませんでした。');
    return;
  }
  const config = readJsonObject(state.agentConfigFile || path.join(state.workspace, 'AgentData', 'agent-config.json')) || {};
  const port = Number(config.local?.serverPort || state.connection?.javaPort || 25565);
  const running = await resolveRunningPaper(port, serverDir);
  const result = await completeBlueMapSetup(serverDir, state.workspace, port, blueMap, { paperVersion: state.paper.version, paperRunning: running.active, forceBlueMapRenderReset: true });
  writeSetupState(stateFile, { ...state, blueMap, blueMapConfig: result.configuration || null, blueMapVerification: result, updatedAt: new Date().toISOString() });
  if (result.verified) ok('BlueMapの設定・地形タイル・Webサーバー起動を確認しました。通常どおりPaperを起動すると、アプリのマップタブで表示できます。');
  else warn(`BlueMapの自動修復は未完了です。${result.reason || 'ログを確認してください。'}`);
}
async function main() {
  if (argv.has('resume-tailscale')) return resumeTailscaleSetup(path.resolve(argv.get('resume-tailscale')));
  if (argv.has('resume-paper')) return resumePaperSetup(path.resolve(argv.get('resume-paper')));
  if (argv.has('repair-bluemap')) return repairBlueMapSetup(path.resolve(argv.get('repair-bluemap')));
  if (argv.has('help') || argv.has('h')) {
    console.log(`GriefGuard Manager Setup Wizard

既存Paperサーバー:
  node scripts/setup-wizard.js --mode existing --server-dir "<Paperサーバーフォルダ>" --workspace "<管理フォルダ>"

新規Paperサーバー:
  node scripts/setup-wizard.js --mode create --create-parent "<親フォルダ>" --server-name "MinecraftServer" --minecraft-version "1.21.11" --workspace "<管理フォルダ>"

主な任意指定: --min-memory 2G --max-memory 4G --server-port 25565
統合版も受け入れる場合: --connection-mode java-bedrock --bedrock-port 19132
Java不足時は公式Temurin JDKをワークスペース内へ自動導入します。導入しない場合のみ: --skip-java-download yes
（PaperのJava版TCPポートと、GeyserMCの統合版UDPポートは別です）
既存起動ファイルを推奨設定へ変更する場合のみ: --replace-launchers yes
（変更前のstart.bat/start.commandは日時付き.bakへ退避します）
新規Paperの初回起動・正常停止まで自動化する場合: --accept-eula yes
AgentのOSログイン時自動起動を無効にする場合のみ: --agent-autostart no
TestLab専用（通常は不要）: --agent-port 31000 --agent-start-policy testlab --testlab-session <ID>
Tailscale HTTPSを自動設定する場合: --tailscale yes
（Tailscale未導入時やスマートフォン側のログインは、本人の認証操作が必要です）`);
    return;
  }
  console.log(`GriefGuard Manager セットアップウィザード（ビルド ${INSTALLER_RELEASE}）`);
  console.log('既存のワールドは移動・削除しません。Paperを停止してから進めてください。');
  step(1, '事前確認');
  const total = os.totalmem(), defaults = recommendedMemory(total);
  ok(`搭載メモリー: ${formatGiB(total)} / 現在利用可能: ${formatGiB(os.freemem())}`);
  const paper = await choosePaperServer();
  const serverDir = paper.serverDir;
  // The workspace is known as soon as Paper is selected. Create a portable
  // Java runtime there before launchers are generated, so no administrator
  // permission or system-wide PATH edit is required.
  const workspace = path.resolve(argv.get('workspace') || defaultWorkspace(serverDir));
  step(4, 'Paper JARとJava確認');
  const jar = argv.get('paper-jar') || findPaperJar(serverDir);
  if (!jar || !exists(path.join(serverDir, jar))) fail(`Paper JARが見つかりません: ${jar || '(未選択)'}`);
  const required = requiredJava(paper.version || '');
  ok(`Paper JAR: ${jar}`);
  console.log(`必要Java: ${required}以上`);
  const java = await ensureJava(required, workspace);
  step(5, 'メモリー設定');
  const memory = await chooseMemorySettings(serverDir, paper, defaults);
  const min = memory.min;
  const max = memory.max;
  const assessment = assessMemory(min, max, { preserveExisting: memory.preserved });
  console.log(`搭載: ${formatGiB(assessment.total)} / 現在利用可能: ${formatGiB(assessment.available)} / OS・Agent予約: ${formatGiB(assessment.reserve)}`);
  console.log(`サーバーへ安定して使える上限: ${formatGiB(assessment.stableLimit)} / 今すぐの目安: ${formatGiB(assessment.recommendedLimit)}`);
  console.log(`人数とメモリーの目安: ${playerGuide(max)}（CPU、Plugin、描画距離、回線で大きく変動）`);
  if (assessment.level === 'warning') warn('最大メモリーが大きめです。推奨上限を超える場合はOSやAgentが不安定になる可能性があります。');
  const connection = await chooseConnection(serverDir);
  const runningPaper = await resolveRunningPaper(connection.javaPort, serverDir);
  step(7, '統合版接続プラグインの準備', connection.mode === 'java-bedrock' ? 'RUN' : 'SKIP');
  const managedPluginUpdater = installManagedPluginUpdater(serverDir, connection);
  if (managedPluginUpdater.enabled) {
    const bedrockPlugins = await installBedrockPlugins(managedPluginUpdater);
    connection.geyserDetected = Boolean(findPluginByPrefix(serverDir, 'geyser'));
    connection.floodgateDetected = Boolean(findPluginByPrefix(serverDir, 'floodgate'));
    const viaVersionDetected = Boolean(findPluginByPrefix(serverDir, 'viaversion'));
    if (connection.geyserDetected && connection.floodgateDetected && viaVersionDetected) {
      ok(`GeyserMC・Floodgate・ViaVersionを確認: ${path.join(serverDir, 'plugins')}`);
    } else {
      warn(`統合版接続Pluginの導入が未完了です（Geyser: ${connection.geyserDetected ? 'OK' : '不足'} / Floodgate: ${connection.floodgateDetected ? 'OK' : '不足'} / ViaVersion: ${viaVersionDetected ? 'OK' : '不足'}）。`);
    }
    if (!bedrockPlugins.ok && !bedrockPlugins.skipped) warn('統合版接続Pluginの導入状態を確認してください。ネットワーク接続後に起動ファイルから再試行されます。');
  } else {
    ok('Java版のみを選択したため、GeyserMC・Floodgateは導入しません。');
  }
  const geyserConfigBeforeStart = configureGeyserConfig(serverDir, connection);
  if (geyserConfigBeforeStart.configured) ok(`GeyserMC設定を同期: ${geyserConfigBeforeStart.file}`);
  else if (connection.mode === 'java-bedrock') warn(`GeyserMC設定は初回Paper起動後に同期します: ${geyserConfigBeforeStart.reason}`);
  const migrated = await configureLaunchers(serverDir, jar, min, max, connection.javaPort, java.executable, managedPluginUpdater);
  step(10, 'Paperアップデーターの配置');
  const paperUpdater = installPaperUpdater(serverDir, workspace, java, min, max, connection.javaPort);
  ok(`Paper更新ツールを配置: ${path.join(serverDir, process.platform === 'win32' ? 'Update-Paper.bat' : 'Update-Paper.command')}`);
  step(11, 'GriefGuard Plugin配置');
  const sourcePlugin = argv.get('plugin-jar') || pluginJar();
  const pluginInstall = installGriefGuardPlugin(serverDir, sourcePlugin);
  ok(`Pluginを配置: ${pluginInstall.targetPlugin}`);
  const pluginEdition = detectPluginEdition(sourcePlugin);
  ok(`GriefGuardエディション: ${pluginEdition === 'high' ? 'HighVersion' : 'Standard'}`);
  const highVersionSettings = await chooseHighVersionSettings(serverDir, pluginEdition);
  const highSettingsBeforeStart = applyHighVersionSettings(serverDir, highVersionSettings);
  if (highSettingsBeforeStart.applied) ok(`HighVersion専用設定を保存: ${highSettingsBeforeStart.file}`);
  else if (highSettingsBeforeStart.pending) warn(`HighVersion専用設定はPaper初回起動後に適用します: ${highSettingsBeforeStart.reason}`);
  step(11, 'BlueMapの準備');
  const blueMap = await installBlueMap(serverDir, paper.version, java);
  if (blueMap.enabled) ok('BlueMapを配置しました。Paper初回起動後に同梱リソースのダウンロード確認が必要です。');
  step(12, 'Agentとワークスペース設定');
  ok(`管理ワークスペース: ${workspace}`);
  const agentData = path.join(workspace, 'AgentData'), logDir = path.join(workspace, 'installer-log');
  fs.mkdirSync(agentData, { recursive: true, mode: 0o700 }); fs.mkdirSync(logDir, { recursive: true, mode: 0o700 });
  const configFile = path.join(agentData, 'agent-config.json');
  const bridgePort = Number(argv.get('bridge-port') || 25501);
  if (!Number.isInteger(bridgePort) || bridgePort < 1024 || bridgePort > 65535) fail('Bridgeポートは1024〜65535の整数で指定してください。');
  const provisioned = provisionAgentConfig(readJsonObject(configFile), { workspace, serverDir, java, connection, bridgePort, minMemory: min, maxMemory: max });
  const config = provisioned.config;
  fs.writeFileSync(configFile, JSON.stringify(config, null, 2) + '\n', { mode: 0o600 });
  ok(`AgentData: ${agentData}`);
  if (provisioned.preserved) ok('既存の管理パスワード・Tailscale設定・パネル設定を引き継ぎました。');
  const setupStateFile = path.join(agentData, 'installer-state.json');
  const tailscaleResume = createTailscaleResumeLauncher(workspace, setupStateFile);
  const paperResume = createPaperResumeLauncher(workspace, setupStateFile);
  writeSetupState(setupStateFile, {
    version: 1, installerRelease: INSTALLER_RELEASE, phase: 'tailscale-pending', workspace, serverDir,
    agentConfigFile: configFile, paper: { jar, version: paper.version, newServer: paper.newServer },
    java: { executable: java.executable, downloaded: java.downloaded, major: java.major }, minMemory: min, maxMemory: max,
    connection, paperUpdater, paperResume, blueMap, pluginEdition, highVersionSettings,
    tailscale: { status: 'pending' }, updatedAt: new Date().toISOString()
  });
  const blueMapRepair = createBlueMapRepairLauncher(workspace, setupStateFile);
  ok(`Tailscale再開用ファイルを作成: ${tailscaleResume}`);
  ok(`Paper再開用ファイルを作成: ${paperResume}`);
  ok(`BlueMap修復用ファイルを作成: ${blueMapRepair}`);
  const agentPort = Number(argv.get('agent-port') || 3000);
  if (!Number.isInteger(agentPort) || agentPort < 1024 || agentPort > 65535) fail('Agentポートは1024〜65535の整数で指定してください。');
  const testLabSession = String(argv.get('testlab-session') || '').trim();
  const testLabToken = String(process.env.GRIEFGUARD_TESTLAB_CLEANUP_TOKEN || '').trim();
  const testLabMode = argv.get('agent-start-policy') === 'testlab';
  if (testLabMode && (!testLabSession || !testLabToken)) fail('TestLab AgentにはセッションIDと安全な削除トークンが必要です。');
  // TestLab owns this process itself. Do not leave a generic manual launcher
  // behind, because it would omit the TestLab ownership token and could start
  // a second Agent on the normal port.
  const agentLauncher = testLabMode ? null : createAgentLauncher(workspace, agentData, agentPort);
  const agentControls = testLabMode ? null : createAgentControlLaunchers(workspace, agentData);
  const agentMaintenance = testLabMode ? null : createAgentMaintenanceLaunchers(workspace, agentData, agentLauncher);
  step(13, 'Agent常駐化と初回起動');
  const bootstrap = installerBootstrap(agentData);
  const alreadyRunning = await agentHealth(agentPort, 1200);
  let autostart, agentStart;
  let recoveredSetup = null;
  if (isGriefGuardHealth(alreadyRunning)) {
    const expectedDataId = agentDataId(agentData);
    if (alreadyRunning.agentDataId && alreadyRunning.agentDataId !== expectedDataId) {
      fail(`別の管理ワークスペースのGriefGuard Agentがポート ${agentPort} で起動中です。\n今回のAgentData: ${agentData}\n安全のため停止・上書きはしません。先に既存ワークスペースのStop-GriefGuard-Agentを実行するか、Agentポートを変更してください。`);
    }
    // Older Agents did not expose agentDataId. A matching runtime marker and
    // control token are still sufficient ownership proof for an in-place
    // reinstall, including the case where /Applications was deleted first.
    const stopResult = await requestLocalAgentControl(agentData, 'stop', alreadyRunning);
    let stopped = stopResult.ok && await waitForAgentOffline(agentPort);
    if (!stopped && process.platform === 'darwin' && unloadMacLaunchAgent()) {
      stopped = await waitForAgentOffline(agentPort);
    }
    if (stopped) {
      ok('既存のGriefGuard Agentを正常停止しました。最新版で起動し直します。');
      autostart = registerAgentAutostart(workspace, agentData, bootstrap.file, argv.get('agent-autostart') !== 'no' && !testLabMode, agentPort);
      ok(`Agent自動起動: ${autostart.type}`);
      agentStart = await startAgentBackground(workspace, agentData, bootstrap, { port: agentPort, testLabSession, testLabToken });
    } else if (alreadyRunning.setupRequired && (!alreadyRunning.agentDataId || alreadyRunning.agentDataId === expectedDataId)) {
      const codeResult = await requestLocalAgentControl(agentData, 'setup-code', alreadyRunning);
      if (!codeResult.ok || !codeResult.code) {
        fail(`既存Agentは初期設定前ですが、セットアップコードを再発行できませんでした。${codeResult.reason || stopResult.reason || ''}\nAgentを安全に停止できないため処理を続行しません。既存ワークスペースのStop-GriefGuard-Agentを実行してから、もう一度インストーラーを起動してください。`);
      }
      recoveredSetup = codeResult;
      autostart = { type: 'preserved-existing-agent' };
      agentStart = { reused: true, health: alreadyRunning, log: null };
      warn('既存Agentを停止できなかったため、現在のAgentを維持して初回コードのみ再発行しました。次回ログイン時の自動起動設定は既存設定を使用します。');
    } else {
      fail(`既存のGriefGuard Agentを安全に停止できませんでした。${stopResult.reason ? ` ${stopResult.reason}` : ''}\n別のAgentを重複起動しないため処理を中止しました。既存ワークスペースのStop-GriefGuard-Agentを実行してから、もう一度インストーラーを起動してください。`);
    }
  } else {
    autostart = registerAgentAutostart(workspace, agentData, bootstrap.file, argv.get('agent-autostart') !== 'no' && !testLabMode, agentPort);
    ok(`Agent自動起動: ${autostart.type}`);
    agentStart = await startAgentBackground(workspace, agentData, bootstrap, { port: agentPort, testLabSession, testLabToken });
  }
  const localUrl = `http://localhost:${agentPort}`;
  if (argv.get('open-browser') !== 'no') {
    openBrowser(localUrl);
    ok(`管理画面を既定ブラウザーで開きました: ${localUrl}`);
  } else ok(`管理画面URL: ${localUrl}`);
  const setup = recoveredSetup || await readInstallerSetupCode(bootstrap.token, agentPort);
  if (setup?.code) {
    console.log('\n==================================================');
    console.log(` 初回セットアップコード: ${setup.code}`);
    console.log(' ブラウザーで管理パスワードを設定してください。コードは10分・1回限りです。');
    console.log('==================================================');
  } else if (agentStart.health?.setupRequired) {
    fail('Agentは初期設定前ですが、初回セットアップコードを取得できませんでした。安全のため設定を続行しません。Agentログを確認してから、インストーラーをもう一度実行してください。');
  } else {
    ok('既存の管理パスワード設定を引き継ぎました。初回セットアップコードは不要です。');
  }
  // HTTPS belongs to the Agent, not Paper. Finish it before the optional Paper
  // first-run so a Paper bootstrap failure never hides the mobile access URL.
  step(14, 'Tailscale HTTPS設定');
  const tailscale = await completeTailscaleSetup({ config, configFile, workspace, serverDir, agentData, agentPort, bootstrap, recoveredSetup, setupStateFile, tailscaleResume });
  const needsPaperBootstrap = paper.newServer && !hasCompletedPaperFirstRun(serverDir);
  step(15, 'Paper初回起動とBridge同期', needsPaperBootstrap && !runningPaper.active ? 'WAIT' : 'SKIP');
  let paperBootstrap = null;
  if (needsPaperBootstrap && !runningPaper.active) {
    const accept = argv.get('accept-eula') === 'yes' || (!nonInteractive && (await choose('Minecraft EULAを確認し、同意しますか？', [['1', '同意してPaperの初回起動・停止を自動実行'], ['2', '今は同意しない']], '2')) === '1');
    if (accept) {
      fs.writeFileSync(path.join(serverDir, 'eula.txt'), 'eula=true\n'); ok('eula.txtを作成しました。');
      try {
        paperBootstrap = await bootstrapNewPaper(serverDir, connection.javaPort, logDir, { paperVersion: paper.version || '' });
        await waitForFile(path.join(serverDir, 'plugins', 'GriefGuard', 'config.yml'), 20000);
      } catch (error) {
        paperBootstrap = { failed: true, reason: error.message, log: path.join(logDir, 'paper-first-start.log') };
        warn(`Paper初回起動は未完了です。AgentとTailscale HTTPSは利用できます。\n${error.message}`);
        writeSetupState(setupStateFile, { ...readJsonObject(setupStateFile), phase: 'paper-bootstrap-pending', paperBootstrap, paperResume, updatedAt: new Date().toISOString() });
      }
    } else warn('EULA未同意のため、Paper初回起動は保留しました。後でstart.bat/start.commandから起動してください。');
  } else if (needsPaperBootstrap && runningPaper.active) {
    warn('起動中Paperを維持したため、Paper初回起動は実行しません。Paper停止後にContinue-Paper-Setupから再開できます。');
    writeSetupState(setupStateFile, { ...readJsonObject(setupStateFile), phase: 'paper-bootstrap-pending', runningPaper, paperResume, updatedAt: new Date().toISOString() });
  } else if (paper.newServer) {
    ok('既にPaperの初回起動済みデータを検出したため、初回起動・停止は繰り返しません。');
  }
  const pluginSync = synchronizePluginBridge(serverDir, bridgePort);
  if (pluginSync.synchronized) ok(`Plugin Bridge設定を同期: ${pluginSync.file}`);
  else warn(`Plugin Bridge設定の同期は保留: ${pluginSync.reason}`);
  const highSettingsAfterStart = applyHighVersionSettings(serverDir, highVersionSettings);
  if (highSettingsAfterStart.applied) ok(`HighVersion専用設定を確認: ${highSettingsAfterStart.file}`);
  else if (highSettingsAfterStart.pending) warn(`HighVersion専用設定は適用待ちです: ${highSettingsAfterStart.reason}`);
  const geyserConfigAfterStart = configureGeyserConfig(serverDir, connection);
  if (geyserConfigAfterStart.configured && !geyserConfigBeforeStart.configured) ok(`GeyserMC設定を同期: ${geyserConfigAfterStart.file}`);
  else if (connection.mode === 'java-bedrock' && !geyserConfigAfterStart.configured) warn(`GeyserMC設定は次のPaper起動後に同期が必要です: ${geyserConfigAfterStart.reason}`);
  let blueMapVerification = { state: 'skipped', verified: false };
  if (blueMap.enabled) {
    try {
      blueMapVerification = await completeBlueMapSetup(serverDir, workspace, connection.javaPort, blueMap, { paperVersion: paper.version, paperRunning: runningPaper.active });
      if (blueMapVerification.verified) ok('BlueMapの設定・地形タイル・Webサーバー起動を確認しました。通常どおりPaperを起動すると、アプリのマップタブで表示できます。');
      else warn(`BlueMapの自動確認は未完了: ${blueMapVerification.reason || blueMapVerification.state} 修復用: ${blueMapRepair}`);
    } catch (error) {
      blueMapVerification = { state: 'verification-error', verified: false, reason: error.message };
      warn(`BlueMapの自動確認でエラー: ${error.message} 修復用: ${blueMapRepair}`);
    }
  }
  writeAccessRecord(serverDir, workspace, { url: tailscale.url || configuredTailscaleUrl(config), status: tailscale.configured ? 'configured' : 'pending', agentPort, blueMap: blueMapVerification, blueMapRepair });
  step(16, 'インストール結果と初回認証');
  if (!paperBootstrap?.failed && !runningPaper.active) {
    writeSetupState(setupStateFile, { ...readJsonObject(setupStateFile), phase: 'completed', tailscale: tailscale.configured ? { status: 'configured', url: tailscale.url, updatedAt: new Date().toISOString() } : readJsonObject(setupStateFile)?.tailscale, updatedAt: new Date().toISOString() });
  }
  if (paper.newServer) {
    console.log(`  ✓ Paper初回起動: ${paperBootstrap ? '完了（正常停止済み）' : 'EULA同意待ち'}`);
  }
  const logFile = path.join(logDir, `setup-${Date.now()}.json`);
  fs.writeFileSync(logFile, JSON.stringify({ serverDir, workspace, jar, java, min, max, connection, runningPaper, paperVersion: paper.version, createdServer: paper.newServer, launcherMigrated: migrated, paperUpdater, managedPluginUpdater, pluginEdition, highVersionSettings, highSettingsBeforeStart, highSettingsAfterStart, blueMap, blueMapVerification, blueMapRepair, tailscaleResume, paperResume, agentLauncher, agentControls, agentMaintenance, agentPort, testLabSession: testLabSession || null, autostart, agentStart, paperBootstrap, pluginSync, geyserConfig: geyserConfigAfterStart, tailscale, createdAt: new Date().toISOString(), installId: crypto.randomUUID() }, null, 2));
  ok(`ログ: ${logFile}`);
  console.log('自動設定済み: Agent起動、Agent自動起動登録、ブラウザー起動、Bridge設定同期。');
  console.log(agentStart.health?.setupRequired
    ? `次に行うこと: ${localUrl} でセットアップコードと管理パスワードを登録してください。`
    : `次に行うこと: ${localUrl} を開き、登録済みの管理パスワードでログインしてください。`);
  console.log(`Paperを通常運用で起動する時: ${path.join(serverDir, process.platform === 'win32' ? 'start.bat' : 'start.command')}`);
  console.log(`  接続ポート: Java版 ${connection.javaPort}/TCP${connection.bedrockPort ? ` / 統合版 ${connection.bedrockPort}/UDP（GeyserMC）` : ''}`);
  console.log(`AgentData: ${agentData}`);
  if (agentControls?.stop) console.log(`Agentを停止する時: ${agentControls.stop}`);
  if (agentControls?.setupCode) console.log(`初回コードが分からない時: ${agentControls.setupCode}`);
  if (agentControls?.passwordReset) console.log(`管理パスワードを忘れた時: ${agentControls.passwordReset}`);
  if (agentMaintenance?.guide) console.log(`Agentの手動管理一覧: ${agentMaintenance.guide}`);
  console.log(`BlueMapを修復する時: ${blueMapRepair}`);
}
if (require.main === module) {
  main().catch(error => { console.error(`\n[ERROR] ${error.message}`); process.exitCode = 1; });
} else {
  module.exports = {
    normalizePastedPath, normalizeSearchRoots, requiredJava, launcherContent,
    updateYamlScalar, synchronizePluginBridge, readPaperLogState, configuredTailscaleUrl,
    hasCompletedPaperFirstRun, provisionAgentConfig, bootstrapNewPaper,
    installPaperUpdater, installManagedPluginUpdater, installBlueMap, configureBlueMapConfig, refreshBlueMapWebAppIfRequired, completeBlueMapSetup, configureGeyserConfig, installGriefGuardPlugin,
    blueMapRenderSummary, archiveProblemBlueMapMaps, waitForBlueMapRenderable, blueMapResourceFingerprint,
    writeAccessRecord, detectExistingMemory, chooseMemorySettings,
    isGriefGuardHealth, createAgentControlLaunchers, createAgentMaintenanceLaunchers,
    agentDataId, requestLocalAgentControl, inspectPortListener, stopExistingPaper,
    createPaperResumeLauncher, createBlueMapRepairLauncher, findCachedPortableJava, persistTailscaleAccessConfig,
    nativeLauncherKind, removeGeneratedOppositeLaunchers, decodeWindowsCommandOutput,
    ensureJava, stableBuild, downloadPaper, readZipEntry, detectPluginEdition,
    readHighVersionSettings, applyHighVersionSettings
  };
}
