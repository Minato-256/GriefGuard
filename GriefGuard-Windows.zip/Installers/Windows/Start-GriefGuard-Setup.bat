@echo off
setlocal EnableExtensions DisableDelayedExpansion
title GriefGuard Manager Setup
chcp 65001 >nul 2>&1
cd /d "%~dp0"

rem This launcher must remain ASCII-only and CRLF-normalized for cmd.exe.
set "INSTALLER_RELEASE=2026.07.26.3"
set "LOG_ROOT=%LOCALAPPDATA%\GriefGuard\logs"
if "%LOCALAPPDATA%"=="" set "LOG_ROOT=%TEMP%\GriefGuard\logs"
if not exist "%LOG_ROOT%" mkdir "%LOG_ROOT%" >nul 2>&1
set "LOG_FILE=%LOG_ROOT%\setup-bootstrap-%RANDOM%-%RANDOM%.log"

echo GriefGuard Manager Setup Wizard (build %INSTALLER_RELEASE%)
echo Log: %LOG_FILE%
echo [%date% %time%] Setup launcher started.>"%LOG_FILE%"
echo Build: %INSTALLER_RELEASE%>>"%LOG_FILE%"
echo Working directory: %CD%>>"%LOG_FILE%"

set "SETUP_FILE=%~dp0GriefGuard-Setup.ps1"
if not exist "%SETUP_FILE%" (
  echo [ERROR] GriefGuard-Setup.ps1 was not found.
  echo Extract the ZIP completely, then run this file again.
  echo [ERROR] GriefGuard-Setup.ps1 was not found.>>"%LOG_FILE%"
  set "SETUP_RESULT=1"
  goto finish
)

if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" (
  echo Starting Windows PowerShell setup...>>"%LOG_FILE%"
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%SETUP_FILE%" -LogPath "%LOG_FILE%"
  if errorlevel 1 (set "SETUP_RESULT=1") else (set "SETUP_RESULT=0")
  goto finish
)

where pwsh.exe >nul 2>&1
if not errorlevel 1 (
  echo Starting PowerShell 7 setup...>>"%LOG_FILE%"
  pwsh.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%SETUP_FILE%" -LogPath "%LOG_FILE%"
  if errorlevel 1 (set "SETUP_RESULT=1") else (set "SETUP_RESULT=0")
  goto finish
)

echo [ERROR] PowerShell was not found on this PC.
echo Windows PowerShell or PowerShell 7 is required.
set "SETUP_RESULT=1"

:finish
if not defined SETUP_RESULT set "SETUP_RESULT=1"
echo [%date% %time%] Setup exit code: %SETUP_RESULT%>>"%LOG_FILE%"
echo.
if "%SETUP_RESULT%"=="0" (
  echo [OK] Setup completed.
) else (
  echo.
  echo [ERROR] Setup failed. Error code: %SETUP_RESULT%
)
echo Log file: %LOG_FILE%
echo.
echo Press any key to close this window.
pause >nul
endlocal & exit /b %SETUP_RESULT%
