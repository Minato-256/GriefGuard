﻿<#
  GriefGuard Windows setup launcher.
  This is intentionally a readable PowerShell installer for the preview release.
  The signed EXE is built from GriefGuard-Setup.iss on a Windows release machine.
#>
[CmdletBinding()]
param(
  [string]$ServerDirectory,
  [string]$Workspace,
  [string]$PaperJar,
  [string]$MinMemory,
  [string]$MaxMemory,
  [ValidateSet('java', 'java-bedrock')]
  [string]$ConnectionMode,
  [ValidateRange(1, 65535)]
  [int]$ServerPort,
  [ValidateRange(1, 65535)]
  [int]$BedrockPort,
  [string]$LogPath
)

$ErrorActionPreference = 'Stop'
$OutputEncoding = [System.Text.UTF8Encoding]::new()
$installerRelease = '2026.07.28.1'
$transcriptStarted = $false

if (-not $LogPath) {
  $logBase = $env:LOCALAPPDATA
  if (-not $logBase) { $logBase = $env:TEMP }
  $logRoot = Join-Path $logBase 'GriefGuard\logs'
  New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
  $LogPath = Join-Path $logRoot ("setup-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

try {
  Start-Transcript -Path $LogPath -Append -ErrorAction Stop | Out-Null
  $transcriptStarted = $true
} catch {
  Write-Warning "ログ記録を開始できませんでした: $LogPath"
}

try {
$installerRoot = Split-Path -Parent $PSScriptRoot
$distributionRoot = Split-Path -Parent $installerRoot
$agentRoot = Join-Path $distributionRoot 'Mobile-Manager-Agent'
$pluginJar = Join-Path $distributionRoot 'GriefGuard.jar'
$wizardScript = Join-Path $agentRoot 'scripts\setup-wizard.js'

Write-Host "GriefGuard Manager セットアップウィザード（ビルド $installerRelease）" -ForegroundColor Cyan
Write-Host '既存ワールドは移動・削除しません。Paperを停止してから進めてください。' -ForegroundColor Yellow
Write-Host "ログ: $LogPath" -ForegroundColor DarkGray
Write-Host "PowerShell: $($PSVersionTable.PSVersion) / OS: $([Environment]::OSVersion.VersionString)" -ForegroundColor DarkGray

foreach ($requiredPath in @($agentRoot, $pluginJar, $wizardScript)) {
  if (-not (Test-Path -LiteralPath $requiredPath)) { throw "配布物に必要なファイルがありません: $requiredPath" }
}
try {
  $zone = Get-Item -LiteralPath $distributionRoot -Stream Zone.Identifier -ErrorAction Stop
  if ($zone) { Write-Warning 'この配布フォルダにはインターネット由来のブロック情報があります。ZIPを完全展開した後、プロパティの「ブロックの解除」を試してください。' }
} catch { }

$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$nodePath = if ($nodeCommand) { $nodeCommand.Source } else { $null }
if (-not $nodePath) {
  $nodeCandidates = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
  ) | Where-Object { $_ -and (Test-Path $_) }
  if ($nodeCandidates.Count -gt 0) { $nodePath = $nodeCandidates[0] }
}

if (-not $nodePath) {
  throw 'Node.js 18 or later was not found. Install Node.js LTS, sign out and sign in to Windows, then run Start-GriefGuard-Setup.bat again.'
}
$nodeVersion = (& $nodePath --version).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Node.js could not be started. Reinstall Node.js LTS.' }
if ($nodeVersion -notmatch '^v(\d+)\.') { throw "Unsupported Node.js version output: $nodeVersion" }
if ([int]$Matches[1] -lt 18) { throw "Node.js 18 or later is required. Detected: $nodeVersion" }
Write-Host "Node.jsを検出: $nodeVersion" -ForegroundColor DarkGray
if (-not (Test-Path (Join-Path $agentRoot 'node_modules'))) {
  $npmPath = Join-Path (Split-Path -Parent $nodePath) 'npm.cmd'
  if (-not (Test-Path $npmPath)) {
    $npmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if ($npmCommand) { $npmPath = $npmCommand.Source }
  }
  if (-not (Test-Path $npmPath)) { throw 'npm.cmd was not found next to Node.js. Reinstall Node.js LTS.' }
  Write-Host 'Preparing Agent dependencies...' -ForegroundColor Cyan
  Push-Location $agentRoot
  try { & $npmPath ci --omit=dev } finally { Pop-Location }
}

$arguments = @($wizardScript, '--plugin-jar', $pluginJar)
if ($ServerDirectory) { $arguments += @('--server-dir', $ServerDirectory) }
if ($Workspace) { $arguments += @('--workspace', $Workspace) }
if ($PaperJar) { $arguments += @('--paper-jar', $PaperJar) }
if ($MinMemory) { $arguments += @('--min-memory', $MinMemory) }
if ($MaxMemory) { $arguments += @('--max-memory', $MaxMemory) }
if ($ConnectionMode) { $arguments += @('--connection-mode', $ConnectionMode) }
if ($PSBoundParameters.ContainsKey('ServerPort')) { $arguments += @('--server-port', "$ServerPort") }
if ($PSBoundParameters.ContainsKey('BedrockPort')) { $arguments += @('--bedrock-port', "$BedrockPort") }
& $nodePath @arguments
if ($LASTEXITCODE -ne 0) { throw "セットアップ本体が終了コード $LASTEXITCODE で停止しました。" }
Write-Host "`nセットアップが完了しました。作成されたAgent起動ファイルを開き、http://localhost:3000 で初回認証を行ってください。" -ForegroundColor Green
} catch {
  Write-Host "`n[ERROR] セットアップを完了できませんでした。" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host "詳細ログ: $LogPath" -ForegroundColor Yellow
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    [System.Windows.Forms.MessageBox]::Show("セットアップを完了できませんでした。`n`n$($_.Exception.Message)`n`n詳細ログ: $LogPath", 'GriefGuard Setup Error', 'OK', 'Error') | Out-Null
  } catch { }
  exit 1
} finally {
  if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
}
