﻿<#
  GriefGuard Windows setup launcher.
  This is intentionally a readable PowerShell installer for the preview release.
  The signed EXE is built from GriefGuard-Setup.iss on a Windows release machine.
#>
[CmdletBinding()]
param(
  [string]$ServerDirectory,
  [string]$Workspace,
  [string]$PaperJar,
  [string]$MinMemory,
  [string]$MaxMemory,
  [ValidateSet('java', 'java-bedrock')]
  [string]$ConnectionMode,
  [ValidateRange(1, 65535)]
  [int]$ServerPort,
  [ValidateRange(1, 65535)]
  [int]$BedrockPort,
  [string]$LogPath
)

$ErrorActionPreference = 'Stop'
$OutputEncoding = [System.Text.UTF8Encoding]::new()
$installerRelease = '2026.07.28.2'
$transcriptStarted = $false

if (-not $LogPath) {
  $logBase = $env:LOCALAPPDATA
  if (-not $logBase) { $logBase = $env:TEMP }
  $logRoot = Join-Path $logBase 'GriefGuard\logs'
  New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
  $LogPath = Join-Path $logRoot ("setup-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

try {
  Start-Transcript -Path $LogPath -Append -ErrorAction Stop | Out-Null
  $transcriptStarted = $true
} catch {
  Write-Warning "ログ記録を開始できませんでした: $LogPath"
}

try {
$installerRoot = Split-Path -Parent $PSScriptRoot
$distributionRoot = Split-Path -Parent $installerRoot
$agentRoot = Join-Path $distributionRoot 'Mobile-Manager-Agent'
$pluginJar = Join-Path $distributionRoot 'GriefGuard.jar'
$wizardScript = Join-Path $agentRoot 'scripts\setup-wizard.js'

Write-Host "GriefGuard Manager セットアップウィザード（ビルド $installerRelease）" -ForegroundColor Cyan
Write-Host '既存ワールドは移動・削除しません。Paperを停止してから進めてください。' -ForegroundColor Yellow
Write-Host "ログ: $LogPath" -ForegroundColor DarkGray
Write-Host "PowerShell: $($PSVersionTable.PSVersion) / OS: $([Environment]::OSVersion.VersionString)" -ForegroundColor DarkGray

foreach ($requiredPath in @($agentRoot, $pluginJar, $wizardScript)) {
  if (-not (Test-Path -LiteralPath $requiredPath)) { throw "配布物に必要なファイルがありません: $requiredPath" }
}
try {
  $zone = Get-Item -LiteralPath $distributionRoot -Stream Zone.Identifier -ErrorAction Stop
  if ($zone) { Write-Warning 'この配布フォルダにはインターネット由来のブロック情報があります。ZIPを完全展開した後、プロパティの「ブロックの解除」を試してください。' }
} catch { }

$runtimeManifest = Join-Path $installerRoot 'runtime-manifest.json'
if (-not (Test-Path -LiteralPath $runtimeManifest)) { throw "実行環境マニフェストがありません: $runtimeManifest" }
try { $runtime = Get-Content -Raw -LiteralPath $runtimeManifest | ConvertFrom-Json } catch { throw "実行環境マニフェストを読み取れません: $($_.Exception.Message)" }
$minimumNodeMajor = [int]$runtime.node.minimumMajor
if ($minimumNodeMajor -lt 1) { throw 'Node.jsの必要バージョン情報が不正です。' }

function Test-GriefGuardNode([string]$Candidate) {
  if (-not $Candidate -or -not (Test-Path -LiteralPath $Candidate)) { return $null }
  try {
    $version = (& $Candidate -p 'process.versions.node' 2>$null).Trim()
    if ($LASTEXITCODE -ne 0 -or $version -notmatch '^(\d+)\.') { return $null }
    if ([int]$Matches[1] -lt $minimumNodeMajor) { return $null }
    return [pscustomobject]@{ Path = $Candidate; Version = "v$version" }
  } catch { return $null }
}

function Get-GriefGuardNodeCandidate {
  $candidates = [System.Collections.Generic.List[string]]::new()
  $command = Get-Command node.exe -ErrorAction SilentlyContinue
  if (-not $command) { $command = Get-Command node -ErrorAction SilentlyContinue }
  if ($command) { $candidates.Add($command.Source) }
  foreach ($candidate in @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Volta\bin\node.exe'),
    (Join-Path $env:APPDATA 'nvm\node.exe')
  )) { if ($candidate) { $candidates.Add($candidate) } }
  $runtimeBase = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'GriefGuard\runtimes\node' } else { Join-Path $env:TEMP 'GriefGuard\runtimes\node' }
  if (Test-Path -LiteralPath $runtimeBase) {
    Get-ChildItem -LiteralPath $runtimeBase -Filter node.exe -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object { $candidates.Add($_.FullName) }
  }
  foreach ($candidate in $candidates | Select-Object -Unique) {
    $tested = Test-GriefGuardNode $candidate
    if ($tested) { return $tested }
  }
  return $null
}

function Install-GriefGuardNode {
  $architecture = if (("$env:PROCESSOR_ARCHITEW6432 $env:PROCESSOR_ARCHITECTURE") -match 'ARM64') { 'arm64' } else { 'x64' }
  $assetKey = "win-$architecture"
  $asset = $runtime.node.assets.PSObject.Properties[$assetKey].Value
  if (-not $asset -or -not $asset.file -or -not $asset.sha256) { throw "このWindows CPU用のNode.js配布情報がありません: $assetKey" }
  $runtimeBase = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'GriefGuard\runtimes' } else { Join-Path $env:TEMP 'GriefGuard\runtimes' }
  $target = Join-Path $runtimeBase (Join-Path 'node' ("{0}-{1}" -f $runtime.node.version, $assetKey))
  $cached = Get-ChildItem -LiteralPath $target -Filter node.exe -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cached) {
    $tested = Test-GriefGuardNode $cached.FullName
    if ($tested) { Write-Host "GriefGuard共有キャッシュのNode.jsを再利用: $($tested.Version)" -ForegroundColor DarkGray; return $tested }
  }
  $downloads = Join-Path $runtimeBase 'downloads'
  New-Item -ItemType Directory -Path $downloads -Force | Out-Null
  $archive = Join-Path $downloads ("{0}.partial" -f $asset.file)
  $stage = "${target}.partial-$PID"
  Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
  try {
    Write-Host "Node.js $($runtime.node.version) が見つかりません。公式配布元からダウンロードします…" -ForegroundColor Cyan
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri ("{0}{1}" -f $runtime.node.source, $asset.file) -OutFile $archive
    $actual = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne ([string]$asset.sha256).ToLowerInvariant()) { throw 'Node.jsのSHA-256検証に失敗しました。ダウンロードしたファイルは使用しません。' }
    Write-Host 'Node.jsのSHA-256を確認しました。' -ForegroundColor DarkGray
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    Expand-Archive -LiteralPath $archive -DestinationPath $stage -Force
    $nodeFile = Get-ChildItem -LiteralPath $stage -Filter node.exe -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $nodeFile) { throw '展開したNode.jsにnode.exeが見つかりません。' }
    $tested = Test-GriefGuardNode $nodeFile.FullName
    if (-not $tested) { throw '展開したNode.jsを実行できません。' }
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue
    Move-Item -LiteralPath $stage -Destination $target
    Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    $installed = Get-ChildItem -LiteralPath $target -Filter node.exe -File -Recurse | Select-Object -First 1
    $result = Test-GriefGuardNode $installed.FullName
    Write-Host "Node.js $($result.Version) をGriefGuard共有キャッシュへ準備しました。" -ForegroundColor Green
    return $result
  } catch {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    throw
  }
}

$node = Get-GriefGuardNodeCandidate
if (-not $node) { $node = Install-GriefGuardNode }
$nodePath = $node.Path
$nodeVersion = $node.Version
Write-Host "Node.jsを検出して再利用: $nodeVersion" -ForegroundColor DarkGray
if (-not (Test-Path (Join-Path $agentRoot 'node_modules'))) {
  $npmPath = Join-Path (Split-Path -Parent $nodePath) 'npm.cmd'
  if (-not (Test-Path $npmPath)) {
    $npmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if ($npmCommand) { $npmPath = $npmCommand.Source }
  }
  if (-not (Test-Path $npmPath)) { throw 'npm.cmd was not found next to Node.js. Reinstall Node.js LTS.' }
  Write-Host 'Preparing Agent dependencies...' -ForegroundColor Cyan
  Push-Location $agentRoot
  try { & $npmPath ci --omit=dev } finally { Pop-Location }
}

$arguments = @($wizardScript, '--plugin-jar', $pluginJar)
if ($ServerDirectory) { $arguments += @('--server-dir', $ServerDirectory) }
if ($Workspace) { $arguments += @('--workspace', $Workspace) }
if ($PaperJar) { $arguments += @('--paper-jar', $PaperJar) }
if ($MinMemory) { $arguments += @('--min-memory', $MinMemory) }
if ($MaxMemory) { $arguments += @('--max-memory', $MaxMemory) }
if ($ConnectionMode) { $arguments += @('--connection-mode', $ConnectionMode) }
if ($PSBoundParameters.ContainsKey('ServerPort')) { $arguments += @('--server-port', "$ServerPort") }
if ($PSBoundParameters.ContainsKey('BedrockPort')) { $arguments += @('--bedrock-port', "$BedrockPort") }
& $nodePath @arguments
if ($LASTEXITCODE -ne 0) { throw "セットアップ本体が終了コード $LASTEXITCODE で停止しました。" }
Write-Host "`nセットアップが完了しました。作成されたAgent起動ファイルを開き、http://localhost:3000 で初回認証を行ってください。" -ForegroundColor Green
} catch {
  Write-Host "`n[ERROR] セットアップを完了できませんでした。" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host "詳細ログ: $LogPath" -ForegroundColor Yellow
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    [System.Windows.Forms.MessageBox]::Show("セットアップを完了できませんでした。`n`n$($_.Exception.Message)`n`n詳細ログ: $LogPath", 'GriefGuard Setup Error', 'OK', 'Error') | Out-Null
  } catch { }
  exit 1
} finally {
  if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
}
