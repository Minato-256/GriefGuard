#!/bin/sh
# Public macOS entry point. It deliberately does not assume that the .pkg has
# already been installed, so a first-time user receives a recovery path rather
# than a misleading missing-Node.js error.
set -u
INSTALLER_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
INSTALL_ROOT="${GRIEFGUARD_INSTALL_ROOT:-/Applications/GriefGuard Manager}"
SETUP_COMMAND="$INSTALL_ROOT/GriefGuard Setup.command"
RELEASE_FILE="$INSTALL_ROOT/.griefguard-installer-release"
PACKAGE_FILE="$INSTALLER_DIR/GriefGuard-Installer.pkg"
EXPECTED_RELEASE="2026.07.28.2"
AGENT_EXPRESS="$INSTALL_ROOT/agent/node_modules/express/index.js"
AGENT_WS="$INSTALL_ROOT/agent/node_modules/ws/index.js"

installed_release=""
if [ -r "$RELEASE_FILE" ]; then
  installed_release="$(tr -d '\r\n' < "$RELEASE_FILE")"
fi

if [ -x "$SETUP_COMMAND" ] && [ "$installed_release" = "$EXPECTED_RELEASE" ] && [ -f "$AGENT_EXPRESS" ] && [ -f "$AGENT_WS" ]; then
  exec "$SETUP_COMMAND"
fi

if [ -x "$SETUP_COMMAND" ]; then
  if [ ! -f "$AGENT_EXPRESS" ] || [ ! -f "$AGENT_WS" ]; then
    echo "GriefGuard ManagerのAgent必要ファイルが不足しています。"
    echo "最新のPKGで修復インストールを行います。"
  else
    echo "古いGriefGuard Managerがインストールされています。"
  fi
  echo "インストール済み: ${installed_release:-バージョン情報なし}"
  echo "必要な更新: $EXPECTED_RELEASE"
else
  echo "GriefGuard Managerはまだインストールされていません。"
fi
echo
echo "最新版のPKGを実行してからセットアップを開始します。"
echo

if [ -f "$PACKAGE_FILE" ]; then
  printf "今すぐPKGを開きますか？ [Y/n]: "
  read -r answer
  case "${answer:-Y}" in
    Y|y|Yes|yes)
      open "$PACKAGE_FILE"
      echo
      echo "PKGの画面でインストールを完了してください。完了を検出すると、この画面から自動でセットアップを開始します。"
      count=0
      while [ "$count" -lt 180 ]; do
        installed_release=""
        if [ -r "$RELEASE_FILE" ]; then installed_release="$(tr -d '\r\n' < "$RELEASE_FILE")"; fi
        if [ -x "$SETUP_COMMAND" ] && [ "$installed_release" = "$EXPECTED_RELEASE" ] && [ -f "$AGENT_EXPRESS" ] && [ -f "$AGENT_WS" ]; then
          exec "$SETUP_COMMAND"
        fi
        sleep 2
        count=$((count + 1))
      done
      echo "3分待ってもインストールを検出できませんでした。PKG完了後にもう一度このファイルを開いてください。"
      ;;
    *) echo "PKGのインストール後、もう一度このファイルを開いてください。" ;;
  esac
else
  echo "[ERROR] インストール用PKGが同じフォルダに見つかりません。"
  echo "GriefGuard_Distribution/Installers/macOS を丸ごと保持してください。"
fi

echo
echo "終了するにはEnterを押してください。"
read -r _
